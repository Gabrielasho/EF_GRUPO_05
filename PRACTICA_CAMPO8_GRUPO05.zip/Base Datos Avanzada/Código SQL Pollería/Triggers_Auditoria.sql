USE El_Doradito
GO

/*=== AUDITORIA EN LOG ===*/
--Para auditar la tabla Pedido
CREATE TRIGGER tri_auditoria_pedido
ON Pedido 
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
--Si se inserta un nuevo registro
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'Pedido', CAST(i.codigo_pedido AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

--Si se elimina un registro
IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'Pedido', CAST(d.codigo_pedido AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

--Si se modifica uno o varios campos de un mismo registro
--O si se modifican diferentes campos de diferentes registros
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pedido = d.codigo_pedido
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'Pedido', CAST(cambios.codigo_pedido AS NVARCHAR(100)),
--LEFT y LEN ayudaran a eliminar la ultima coma y el espacio
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
--creamos una subconsulta para obtener los campos que cambiaron en cada registro
(
SELECT i.codigo_pedido,
(
--No es necesario auditar codigo_cliente ya que no se podrá modificar (trigger)
--No es necesario auditar codigo_tipoestado ya que HistorialEstadoPedido se encargará de ello

--Si el codigo del tipo de pedido se modifica
CASE WHEN i.codigo_tipopedido <> d.codigo_tipopedido THEN 'codigo_tipopedido, ' ELSE '' END +

--Si el codigo de direccion del pedido se modifica
--Validamos adicionalmente si el inserted y deleted son o son distintos de NULL
CASE WHEN (i.codigo_direccion IS NULL AND d.codigo_direccion IS NOT NULL)
OR (i.codigo_direccion IS NOT NULL AND d.codigo_direccion IS NULL)
OR (i.codigo_direccion <> d.codigo_direccion) THEN 'codigo_direccion, ' ELSE '' END +

--Si el codigo del numero de mesa se modifica
CASE WHEN i.codigo_mesa <> d.codigo_mesa THEN 'codigo_mesa, ' ELSE '' END +

--Si la fecha del pedido se modifica
CASE WHEN i.fecha_pedido <> d.fecha_pedido THEN 'fecha_pedido, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pedido = d.codigo_pedido
) AS cambios
WHERE LEN(cambios.campos) > 0;
END;
END;
GO


--Para auditar la tabla Producto
--Mantiene la misma logica que el trigger anterior, pero adaptada a la tabla Producto
CREATE TRIGGER tri_auditoria_producto 
ON Producto 
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'Producto', CAST(i.codigo_producto AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'Producto', CAST(d.codigo_producto AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_producto = d.codigo_producto
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'Producto', CAST(cambios.codigo_producto AS NVARCHAR(100)),
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
(
SELECT
i.codigo_producto,
(CASE WHEN i.nombre_producto <> d.nombre_producto THEN 'nombre_producto, ' ELSE '' END +

CASE WHEN i.descripcion <> d.descripcion THEN 'descripcion, ' ELSE '' END +

CASE WHEN i.precio_producto <> d.precio_producto THEN 'precio_producto, ' ELSE '' END +

CASE WHEN (i.disponibilidad IS NULL AND d.disponibilidad IS NOT NULL)
OR (i.disponibilidad IS NOT NULL AND d.disponibilidad IS NULL)
OR (i.disponibilidad <> d.disponibilidad) THEN 'disponibilidad, ' ELSE '' END +

CASE WHEN i.costo_producto <> d.costo_producto THEN 'costo_producto, ' ELSE '' END +

CASE WHEN i.codigo_categoria <> d.codigo_categoria THEN 'codigo_categoria, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_producto = d.codigo_producto
) AS cambios
WHERE LEN(cambios.campos) > 0;
END;
END;
GO


--Para auditar la tabla Pago
CREATE TRIGGER tri_auditoria_pago 
ON Pago
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'Pago', CAST(i.codigo_pago AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'Pago', CAST(d.codigo_pago AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pago = d.codigo_pago
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'Pago', CAST(cambios.codigo_pago AS NVARCHAR(100)),
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
(
SELECT
i.codigo_pago,
(CASE WHEN i.codigo_pedido <> d.codigo_pedido THEN 'codigo_pedido, ' ELSE '' END +

CASE WHEN i.codigo_empleado <> d.codigo_empleado THEN 'codigo_empleado, ' ELSE '' END +

CASE WHEN i.fecha_pago <> d.fecha_pago THEN 'fecha_pago, ' ELSE '' END +

CASE WHEN i.monto_pago <> d.monto_pago THEN 'monto_pago, ' ELSE '' END +

CASE WHEN i.metodo_pago <> d.metodo_pago THEN 'metodo_pago, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pago = d.codigo_pago
) AS cambios
END;
END;
GO


--Para auditar la tabla CompraProveedor
CREATE TRIGGER tri_auditoria_compraprovee 
ON CompraProveedor
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'CompraProveedor', CAST(i.codigo_compra AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'CompraProveedor', CAST(d.codigo_compra AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_compra = d.codigo_compra
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'CompraProveedor', CAST(cambios.codigo_compra AS NVARCHAR(100)),
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
(
SELECT
i.codigo_compra,
(CASE WHEN i.codigo_proveedor <> d.codigo_proveedor THEN 'codigo_proveedor, ' ELSE '' END +

CASE WHEN i.codigo_empleado <> d.codigo_empleado THEN 'codigo_empleado, ' ELSE '' END +

CASE WHEN i.fecha_compra <> d.fecha_compra THEN 'fecha_compra, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_compra = d.codigo_compra
) AS cambios
WHERE LEN(cambios.campos) > 0;
END;
END;
GO