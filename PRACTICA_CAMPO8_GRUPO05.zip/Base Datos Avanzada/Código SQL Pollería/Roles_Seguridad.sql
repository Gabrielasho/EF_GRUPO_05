--Creamos el Rol Administrador
CREATE USER usuario_admin
WITHOUT LOGIN;
GO
CREATE ROLE rol_administrador
GO
ALTER ROLE rol_administrador
ADD MEMBER usuario_admin;
GO
--asignamos su permiso: Acceso y modificación TOTAL a todas las tablas
GRANT SELECT, INSERT, UPDATE, DELETE
ON SCHEMA::dbo
TO rol_administrador
GO



--Creamos el Rol Operador
CREATE USER usuario_operador
WITHOUT LOGIN;
GO
CREATE ROLE rol_operador
GO
ALTER ROLE rol_operador
ADD MEMBER usuario_operador;
GO
--Asignamos sus permisos:
--Consultar, insertar y actualizar tablas relacionadas al pedido
GRANT SELECT, INSERT, UPDATE
ON dbo.Pedido
TO rol_operador
GRANT SELECT, INSERT, UPDATE
ON dbo.DetallePedido
TO rol_operador
GRANT SELECT, INSERT, UPDATE
ON dbo.Pago
TO rol_operador
GRANT SELECT, INSERT, UPDATE
ON dbo.ParticipacionPedido
TO rol_operador

--Consultar e insertar tablas relacionadas al pedido
--pero que no requieren de actualizar
GRANT SELECT, INSERT
ON dbo.Comprobante
TO rol_operador
GRANT SELECT, INSERT
ON dbo.HistorialEstadoPedido
TO rol_operador

--Solo consultar tablas necesarias para la operación de la pollería
GRANT SELECT
ON dbo.Cliente
TO rol_operador
GRANT SELECT
ON dbo.Direccion
TO rol_operador
GRANT SELECT
ON dbo.Producto
TO rol_operador
GRANT SELECT
ON dbo.TipoPedido
TO rol_operador
GRANT SELECT
ON dbo.TipoEstado
TO rol_operador
GRANT SELECT
ON dbo.Mesa
TO rol_operador
GRANT SELECT
ON dbo.Categoria
TO rol_operador




