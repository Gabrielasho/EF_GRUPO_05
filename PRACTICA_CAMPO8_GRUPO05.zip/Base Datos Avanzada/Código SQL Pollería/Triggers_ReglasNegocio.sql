USE El_Doradito
GO

/*
===================
SECCIÓN DE TRIGGERS
===================
*/
/*=== VALIDACIONES DE PERMISOS DE EMPLEADOS ===*/
--Si el pedido es presencial, deben participar empleados con cargo 'Camarero' en el pedido
--Además, su tipo de participacion debe ser 'Atiende pedido presencial'
CREATE TRIGGER tri_pedido_presencial
ON ParticipacionPedido
AFTER INSERT, UPDATE
AS BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion IN ('Presencial en mesa', 'Presencial para recoger')
AND i.estado_participacion = 'Activo'
AND i.tipo_participacion <> 'Atiende pedido presencial'
)
BEGIN
RAISERROR ('ERROR: Los pedidos presenciales deben tener un tipo de participación válido', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE i.tipo_participacion = 'Atiende pedido presencial'
AND i.estado_participacion = 'Activo'
AND tp.descripcion IN ('Presencial en mesa', 'Presencial para recoger')
AND r.descripcion <> 'Camarero'
)
BEGIN
RAISERROR ('ERROR: Solo los Camareros pueden tener la participación "Atiende pedido presencial"', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--Si el pedido es delivery, deben participar empleados con cargo 'Anfitrión telefónico' y 'Repartidor' en el pedido
--Además, su tipo de participacion debe ser 'Anota pedido delivery' y 'Entrega pedido delivery', respectivamente
CREATE TRIGGER tri_pedido_delivery
ON ParticipacionPedido
AFTER INSERT, UPDATE
AS BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion = 'Delivery'
AND i.tipo_participacion NOT IN ('Anota pedido delivery', 'Entrega pedido delivery')
)
BEGIN
RAISERROR ('ERROR: Los pedidos delivery deben tener un tipo de participación válido', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE i.tipo_participacion = 'Anota pedido delivery'
AND tp.descripcion = 'Delivery'
AND r.descripcion <> 'Anfitrion telefonico'
)
BEGIN
RAISERROR ('ERROR: Solo Anfitriones Telefónicos pueden tener la participación "Anota pedido delivery"', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE i.tipo_participacion = 'Entrega pedido delivery'
AND tp.descripcion = 'Delivery'
AND r.descripcion <> 'Repartidor'
)
BEGIN
RAISERROR ('ERROR: Solo Repartidores pueden tener la participación "Entrega pedido delivery"', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--Los pagos deben tener un empleado asociado:
--Si el pedido es presencial, solo empleados con rol 'Cajero' pueden registrarlos
--Si el pedido es delivery, solo empleados con rol 'Repartidor' pueden cobrarlos
CREATE TRIGGER tri_pago_segun_tipopedido
ON Pago
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
WHERE codigo_empleado IS NULL
)
BEGIN
RAISERROR ('ERROR: Debe existir un empleado asociado al pago', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON r.codigo_rol = e.codigo_rol
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion IN ('Presencial para recoger', 'Presencial en mesa')
AND r.descripcion <> 'Cajero'
)
BEGIN
RAISERROR ('ERROR: Solo Cajeros pueden registrar pagos para pedidos presenciales', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON r.codigo_rol = e.codigo_rol
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion = 'Delivery'
AND r.descripcion <> 'Repartidor'
)
BEGIN
RAISERROR ('ERROR: Solo Repartidores pueden cobrar pagos para pedidos delivery', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--La compra a un proveedor debe tener un Administrador asociado, y solo empleados
--con rol 'Administrador' pueden registrarlas
CREATE TRIGGER tri_compra_admin
ON CompraProveedor
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
WHERE i.codigo_empleado IS NULL
)
BEGIN
RAISERROR('ERROR: Debe existir un empleado asociado a la compra', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE r.descripcion <> 'Administrador'
)
BEGIN
RAISERROR('ERROR: Solo Administradores pueden registrar compras a proveedores', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



/*=== VALIDACIÓN DE REGLAS DE NEGOCIO PARA EL PEDIDO ===*/
--Si el pedido es delivery, se asociará a una mesa virtual de número 99
--Si el pedido es 'Presencial para recoger', se asociará a otra mesa virtual de número 98
--Si el pedido es 'Presencial en mesa', se asociará a una mesa física (10 - 24)
CREATE TRIGGER tri_mesas_tipopedido
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Mesa m
ON i.codigo_mesa = m.codigo_mesa
WHERE tp.descripcion = 'Delivery'
AND m.numero_mesa <> 99
)
BEGIN
RAISERROR('ERROR: Los pedidos Delivery deben usar la mesa virtual (99)', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Mesa m
ON i.codigo_mesa = m.codigo_mesa
WHERE tp.descripcion = 'Presencial para recoger'
AND m.numero_mesa <> 98
)
BEGIN
RAISERROR ('ERROR: Los pedidos de modalidad "Presencial para recoger" deben usar la mesa virtual (98)', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Mesa m
ON i.codigo_mesa = m.codigo_mesa
WHERE tp.descripcion = 'Presencial en mesa'
AND m.numero_mesa IN (98,99)
)
BEGIN
RAISERROR ('ERROR: Los pedidos de modalidad "Presencial en mesa" deben usar números de mesas físicas', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--Si el pedido es delivery, el distrito de la dirección asociada debe atender por ahí
CREATE TRIGGER tri_distrito_delivery
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Direccion d
ON i.codigo_direccion = d.codigo_direccion
INNER JOIN Distrito dt
ON d.codigo_distrito = dt.codigo_distrito
WHERE tp.descripcion = 'Delivery'
AND dt.atiende_delivery <> 'Si'
)
BEGIN
RAISERROR('ERROR: El distrito de la dirección asociada no atiende pedidos delivery', 16, 1);
ROLLBACK TRANSACTION;
END;
END;
GO



--Un pedido presencial NO debe tener código dirección, es decir, que el código sea NULL
--De igual manera, un delivery DEBE tener código de dirección, es decir, que el código sea distinto de NULL
CREATE TRIGGER tri_direccion_pedido
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion = 'Delivery' AND i.codigo_direccion IS NULL
)
BEGIN
RAISERROR('ERROR: Un pedido delivery debe tener una direccion asociada', 16, 1); 
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion IN ('Presencial en mesa', 'Presencial para recoger')
AND i.codigo_direccion IS NOT NULL
)
BEGIN
RAISERROR('ERROR: Un pedido presencial no debe tener direccion asociada', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--El tipo de estado del pedido debe pertenecer al tipo de pedido seleccionado
CREATE TRIGGER tri_tipopedido_estado
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoEstado te
ON i.codigo_tipoestado = te.codigo_tipoestado
WHERE i.codigo_tipopedido <> te.codigo_tipopedido
)
BEGIN
RAISERROR('ERROR: El estado no pertenece al tipo de pedido seleccionado', 16, 1);
ROLLBACK TRANSACTION;
END;
END;
GO



/*=== AUTOMATIZACIONES DE CÁLCULOS ===*/
--Calcular automáticamente el monto total de la compra a un proveedor
--Este trigger actualizará la columna monto_total de la tabla CompraProveedor también
CREATE TRIGGER tri_actualiza_montocompra
ON DetalleCompra
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
UPDATE cp
SET monto_total =
(
SELECT ISNULL(SUM(subtotal),0)
FROM DetalleCompra dc
WHERE dc.codigo_compra = cp.codigo_compra
)
FROM CompraProveedor cp
WHERE cp.codigo_compra IN
(
SELECT codigo_compra FROM inserted
UNION
SELECT codigo_compra FROM deleted
);
END;
GO



--Calcular el total a pagar del pedido
--Funciona de manera similar al trigger anterior
CREATE TRIGGER tri_actualiza_totalpedido
ON DetallePedido
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
UPDATE p
SET total_pagar =
(
SELECT ISNULL(SUM(subtotal),0)
FROM DetallePedido dp
WHERE dp.codigo_pedido = p.codigo_pedido
)
FROM Pedido p
WHERE p.codigo_pedido IN
(
SELECT codigo_pedido FROM inserted
UNION
SELECT codigo_pedido FROM deleted
);
END;
GO



/*=== INTEGRIDAD DEL SISTEMA ===*/
--Para evitar que el codigo del cliente de un pedido sea modificado
CREATE TRIGGER tri_fijo_cliente_pedido
ON Pedido
AFTER UPDATE
AS
BEGIN
IF UPDATE(codigo_cliente)
BEGIN
RAISERROR('ERROR: El código del cliente NO puede ser modificado', 16, 1)
ROLLBACK TRANSACTION
RETURN
END;
END;
GO



/*=== EVOLUCION DE ESTADO DEL PEDIDO ===*/
--Cada vez que se cambie el estado de un pedido, se registrará en la tabla de historial
CREATE TRIGGER tri_historial_estado_pedido
ON Pedido
AFTER UPDATE
AS
BEGIN
IF UPDATE(codigo_tipoestado)
BEGIN
INSERT INTO HistorialEstadoPedido (codigo_pedido, codigo_tipoestado)
SELECT codigo_pedido, codigo_tipoestado
FROM inserted;
END;
END;
GO