CREATE DATABASE El_Doradito
GO
USE El_Doradito
GO

/*
===============================================
SECCIÓN DE CREATES Y CONSTRAINTS (validaciones)
===============================================
*/
CREATE TABLE Cliente (
	codigo_cliente INT PRIMARY KEY IDENTITY(1,1),
	primer_nombre NVARCHAR(20) NOT NULL,
    segundo_nombre NVARCHAR(20),
    apellido_paterno NVARCHAR(20),
    apellido_materno NVARCHAR(20),
	telefono NVARCHAR(15),
    correo_electronico NVARCHAR(150),
	fecha_registro DATETIME NOT NULL DEFAULT GETDATE()
);
--validaciones para la tabla Cliente
ALTER TABLE Cliente
ADD CONSTRAINT valida_1nombrecliente
CHECK (primer_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_2nombrecliente
CHECK (segundo_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_1apellidocliente
CHECK (apellido_paterno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_2apellidocliente
CHECK (apellido_materno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_clientefono
CHECK (telefono NOT LIKE '%[^0-9+-]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_clientecorreo
CHECK (correo_electronico LIKE '%@%.%');

--Este CHECK valida que, si el telefono NO tiene valor, el correo tampoco deberia tenerlo,
--porque quiere decir que el cliente ya se registro (para lo que se necesita telefono), lo que es inconsistente
ALTER TABLE Cliente
ADD CONSTRAINT valida_correo_sintelefono
CHECK (correo_electronico IS NULL OR telefono IS NOT NULL)

CREATE UNIQUE INDEX uq_cliente_telefono
ON Cliente(telefono)
WHERE telefono IS NOT NULL;

CREATE UNIQUE INDEX uq_cliente_correo
ON Cliente(correo_electronico)
WHERE correo_electronico IS NOT NULL;



CREATE TABLE TipoPedido (
    codigo_tipopedido INT PRIMARY KEY IDENTITY(1,1),
    descripcion NVARCHAR(40) NOT NULL UNIQUE
);
--validaciones para la tabla TipoPedido
ALTER TABLE TipoPedido
ADD CONSTRAINT valida_tipopedido_txt
CHECK (descripcion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');



CREATE TABLE TipoEstado (
    codigo_tipoestado INT PRIMARY KEY IDENTITY(1,1),
    codigo_tipopedido INT NOT NULL,
    descripcion NVARCHAR(50) NOT NULL,
    orden_estado INT NOT NULL,
    FOREIGN KEY (codigo_tipopedido) REFERENCES TipoPedido(codigo_tipopedido)
);
--validaciones para la tabla TipoEstado
ALTER TABLE TipoEstado
ADD CONSTRAINT valida_tipoestado
CHECK (descripcion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE TipoEstado
ADD CONSTRAINT valida_ordenestado
CHECK (orden_estado > 0);

ALTER TABLE TipoEstado
ADD CONSTRAINT unico_tipoestado_orden
UNIQUE (codigo_tipopedido, orden_estado);

ALTER TABLE TipoEstado
ADD CONSTRAINT unico_tipoestado_descripcion
UNIQUE (codigo_tipopedido, descripcion);



CREATE TABLE Mesa (
	codigo_mesa INT PRIMARY KEY IDENTITY(1,1),
	numero_mesa INT NOT NULL UNIQUE,
	cantidad_asientos INT NOT NULL,
	estado_mesa NVARCHAR(20) NOT NULL
);
--validaciones para la tabla Mesa
ALTER TABLE Mesa
ADD CONSTRAINT valida_numeromesa
CHECK (numero_mesa > 0);

ALTER TABLE Mesa
ADD CONSTRAINT valida_cantiasientos
CHECK (cantidad_asientos > 0 OR numero_mesa IN (98,99));

ALTER TABLE Mesa
ADD CONSTRAINT valida_estadomesa
CHECK (estado_mesa IN ('Libre', 'Ocupada'));



CREATE TABLE Rol (
    codigo_rol INT PRIMARY KEY IDENTITY(1,1),
    descripcion NVARCHAR(30) NOT NULL UNIQUE
);
--validaciones para la tabla Rol
ALTER TABLE Rol
ADD CONSTRAINT rol_descripcion_valida
CHECK (descripcion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');



CREATE TABLE Empleado (
	codigo_empleado INT PRIMARY KEY IDENTITY(1,1),
	primer_nombre NVARCHAR(20) NOT NULL,
    segundo_nombre NVARCHAR(20),
    apellido_paterno NVARCHAR(20),
	apellido_materno NVARCHAR(20),
	telefono NVARCHAR(20) NOT NULL UNIQUE,
    tipo_documento NVARCHAR(50) NOT NULL,
	numero_documento NVARCHAR(20) NOT NULL UNIQUE,
	direccion NVARCHAR(200),
	hora_entrada TIME NOT NULL,
	hora_salida TIME NOT NULL,
	fecha_ingreso DATETIME NOT NULL DEFAULT GETDATE(),
    codigo_rol INT NOT NULL,
    FOREIGN KEY (codigo_rol) REFERENCES Rol(codigo_rol)
);
--validaciones para la tabla Empleado
ALTER TABLE Empleado
ADD CONSTRAINT valida_1nombreempleado
CHECK (primer_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_2nombreempleado
CHECK (segundo_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_1apellidoempleado
CHECK (apellido_paterno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_2apellidoempleado
CHECK (apellido_materno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_empleadofono
CHECK (telefono NOT LIKE '%[^0-9+-]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_tipodocempleado
CHECK (tipo_documento IN ('DNI','Carnet de extranjeria','Pasaporte','Otro'));

ALTER TABLE Empleado
ADD CONSTRAINT valida_numdocempleado
CHECK (numero_documento NOT LIKE '%[^A-Za-z0-9]%');



CREATE TABLE Ingrediente (
	codigo_ingrediente INT PRIMARY KEY IDENTITY(1,1),
	nombre_ingrediente NVARCHAR(100) NOT NULL UNIQUE,
	unidad_medida NVARCHAR(20) NOT NULL
);
--validaciones para la tabla Ingrediente
ALTER TABLE Ingrediente
ADD CONSTRAINT nombre_ingrediente_valido
CHECK (nombre_ingrediente NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

ALTER TABLE Ingrediente
ADD CONSTRAINT unimedida_ingrediente
CHECK (unidad_medida IN ('kg','g','litro','ml','unidad'));



CREATE TABLE Proveedor (
	codigo_proveedor INT PRIMARY KEY IDENTITY(1,1),
	nombre NVARCHAR(100) NOT NULL UNIQUE,
	telefono NVARCHAR(20) NOT NULL UNIQUE,
	correo_electronico NVARCHAR(100) NOT NULL UNIQUE,
	direccion NVARCHAR(200)
);
--validaciones para la tabla Proveedor
ALTER TABLE Proveedor
ADD CONSTRAINT nombre_proveedor_valido
CHECK (nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 .-]%');

ALTER TABLE Proveedor
ADD CONSTRAINT telefono_proveedor_valido
CHECK (telefono NOT LIKE '%[^0-9+-]%');

ALTER TABLE Proveedor
ADD CONSTRAINT correo_proveedor_valido
CHECK (correo_electronico LIKE '%@%.%');



CREATE TABLE Distrito (
    codigo_distrito INT PRIMARY KEY IDENTITY(1,1),
    nombre_distrito NVARCHAR(50) NOT NULL UNIQUE,
    atiende_delivery NVARCHAR(10) NOT NULL
);
--validaciones para la tabla Distrito
ALTER TABLE Distrito
ADD CONSTRAINT nombre_distrito_valido
CHECK (nombre_distrito NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

ALTER TABLE Distrito
ADD CONSTRAINT atiende_delivery_valido
CHECK (atiende_delivery IN ('Si','No'));



CREATE TABLE Categoria (
    codigo_categoria INT PRIMARY KEY IDENTITY(1,1),
    nombre_categoria NVARCHAR(30) NOT NULL UNIQUE
);
--validaciones para la tabla Categoria
ALTER TABLE Categoria
ADD CONSTRAINT valida_nombre_categoria
CHECK (nombre_categoria NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');



CREATE TABLE Producto (
	codigo_producto INT PRIMARY KEY IDENTITY(1,1),
	nombre_producto NVARCHAR(100) NOT NULL UNIQUE,
	descripcion NVARCHAR(255),
	precio_producto DECIMAL(10, 2) NOT NULL,
	disponibilidad NVARCHAR(20) NOT NULL,
    costo_producto DECIMAL(10,2) NOT NULL,
    codigo_categoria INT NOT NULL,
    FOREIGN KEY (codigo_categoria) REFERENCES Categoria(codigo_categoria)
);
--validaciones para la tabla Producto
ALTER TABLE Producto
ADD CONSTRAINT valida_nomproducto
CHECK (nombre_producto NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 .+/()-]%');

ALTER TABLE Producto
ADD CONSTRAINT valida_precioproducto
CHECK (precio_producto > 0);

ALTER TABLE Producto
ADD CONSTRAINT valida_productodispo
CHECK (disponibilidad IN ('Disponible', 'No disponible'));

ALTER TABLE Producto
ADD CONSTRAINT valida_costoproducto
CHECK (costo_producto > 0);



CREATE TABLE Direccion (
    codigo_direccion INT PRIMARY KEY IDENTITY(1,1),
    codigo_cliente INT NOT NULL,
    codigo_distrito INT NOT NULL,
    tipo_direccion NVARCHAR(30) NOT NULL,
    direccion NVARCHAR(255) NOT NULL,
    FOREIGN KEY (codigo_cliente) REFERENCES Cliente(codigo_cliente),
    FOREIGN KEY (codigo_distrito) REFERENCES Distrito(codigo_distrito)
);
--validaciones para la tabla Direccion
ALTER TABLE Direccion
ADD CONSTRAINT valida_tipodireccion
CHECK (tipo_direccion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

--Esta validacion es especial ya que ayudará a que en la tabla
--Pedido, el código de dirección colocado realmente sea el que le 
--pertenezca al cliente que hace el pedido
ALTER TABLE Direccion
ADD CONSTRAINT unico_direccion_cliente
UNIQUE (codigo_direccion, codigo_cliente);



CREATE TABLE Pedido (
	codigo_pedido INT PRIMARY KEY IDENTITY(1,1),
	codigo_cliente INT NOT NULL,
    codigo_tipopedido INT NOT NULL,
    codigo_tipoestado INT NOT NULL,
    codigo_direccion INT,
    codigo_mesa INT NOT NULL,
	fecha_pedido DATETIME NOT NULL DEFAULT GETDATE(),
	total_pagar DECIMAL(10, 2) DEFAULT 0 NOT NULL,
	FOREIGN KEY (codigo_cliente) REFERENCES Cliente(codigo_cliente),
    FOREIGN KEY (codigo_tipopedido) REFERENCES TipoPedido(codigo_tipopedido),
    FOREIGN KEY (codigo_tipoestado) REFERENCES TipoEstado(codigo_tipoestado),
    FOREIGN KEY (codigo_direccion, codigo_cliente)
	REFERENCES Direccion(codigo_direccion, codigo_cliente),
    FOREIGN KEY (codigo_mesa) REFERENCES Mesa(codigo_mesa),
);
--validaciones para la tabla Pedido
ALTER TABLE Pedido
ADD CONSTRAINT check_totalpago
CHECK (total_pagar >= 0);



CREATE TABLE Comprobante (
    codigo_comprobante INT PRIMARY KEY IDENTITY(1,1),
    codigo_pedido INT NOT NULL UNIQUE,
	tipo_comprobante NVARCHAR(20) NOT NULL,
    numero_comprobante NVARCHAR(20) NOT NULL UNIQUE,
    fecha_emision DATETIME NOT NULL DEFAULT GETDATE(),
    subtotal DECIMAL(10, 2) NOT NULL,
    IGV DECIMAL(8,2) NOT NULL,
    FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido)
);
--validaciones para la tabla Comprobante
ALTER TABLE Comprobante
ADD CONSTRAINT valida_tipocomprobante
CHECK (tipo_comprobante IN ('Boleta', 'Factura'));

ALTER TABLE Comprobante
ADD CONSTRAINT valida_numerocomprobante
CHECK (numero_comprobante NOT LIKE '%[^A-Za-z0-9 -]%');



CREATE TABLE Pago (
	codigo_pago INT PRIMARY KEY IDENTITY(1,1),
	codigo_pedido INT NOT NULL UNIQUE,
    codigo_empleado INT NOT NULL,
	fecha_pago DATETIME NOT NULL DEFAULT GETDATE(),
	monto_pago DECIMAL(10, 2) NOT NULL,
	metodo_pago NVARCHAR(20) NOT NULL,
	FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
    FOREIGN KEY (codigo_empleado) REFERENCES Empleado(codigo_empleado)
);
--validaciones para la tabla Pago
ALTER TABLE Pago
ADD CONSTRAINT valida_montopago
CHECK (monto_pago > 0);

ALTER TABLE Pago
ADD CONSTRAINT valida_metodopago
CHECK (metodo_pago IN ('Efectivo', 'Yape', 'Tarjeta'));



CREATE TABLE ParticipacionPedido (
codigo_pedido INT NOT NULL,
codigo_empleado INT NOT NULL,
PRIMARY KEY (codigo_pedido, codigo_empleado),
tipo_participacion NVARCHAR(50) NOT NULL,
estado_participacion NVARCHAR(20) NOT NULL,
fecha_participacion DATETIME NOT NULL DEFAULT GETDATE(),
FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
FOREIGN KEY (codigo_empleado) REFERENCES Empleado(codigo_empleado)
);
--validaciones para la tabla ParticipacionPedido
ALTER TABLE ParticipacionPedido
ADD CONSTRAINT valida_tipo_participacion
CHECK (tipo_participacion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

ALTER TABLE ParticipacionPedido
ADD CONSTRAINT valida_estado_participacion
CHECK (estado_participacion IN ('Activo','Cancelado'));

CREATE UNIQUE INDEX unica_participacion_activa
ON ParticipacionPedido(codigo_pedido, tipo_participacion)
WHERE estado_participacion = 'Activo';



CREATE TABLE CompraProveedor (
	codigo_compra INT PRIMARY KEY IDENTITY(1,1),
	codigo_proveedor INT NOT NULL,
	codigo_empleado INT NOT NULL,
	fecha_compra DATETIME NOT NULL DEFAULT GETDATE(),
	monto_total DECIMAL(12, 2) NOT NULL,
	FOREIGN KEY (codigo_proveedor) REFERENCES Proveedor(codigo_proveedor),
	FOREIGN KEY (codigo_empleado) REFERENCES Empleado(codigo_empleado)
);



CREATE TABLE DetallePedido (
	codigo_pedido INT NOT NULL,
	codigo_producto INT NOT NULL,
	cantidad INT NOT NULL,
	precio_unitario DECIMAL(10, 2) NOT NULL,
	subtotal AS (CAST(cantidad * precio_unitario AS DECIMAL(12,2))),
	PRIMARY KEY (codigo_pedido, codigo_producto),
	FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
	FOREIGN KEY (codigo_producto) REFERENCES Producto(codigo_producto)
);
--validaciones para la tabla DetallePedido
ALTER TABLE DetallePedido
ADD CONSTRAINT valida_cantidadDP
CHECK (cantidad > 0);

ALTER TABLE DetallePedido
ADD CONSTRAINT valida_preciouniDP
CHECK (precio_unitario > 0);



CREATE TABLE DetalleCompra (
	codigo_compra INT NOT NULL,
	codigo_ingrediente INT NOT NULL,
	cantidad INT NOT NULL,
	precio_unitario DECIMAL(10, 2) NOT NULL,
	subtotal AS (CAST(cantidad * precio_unitario AS DECIMAL(12,2))),
	PRIMARY KEY (codigo_compra, codigo_ingrediente),
	FOREIGN KEY (codigo_compra) REFERENCES CompraProveedor(codigo_compra),
	FOREIGN KEY (codigo_ingrediente) REFERENCES Ingrediente(codigo_ingrediente)
);
--validaciones para la tabla DetalleCompra
ALTER TABLE DetalleCompra
ADD CONSTRAINT valida_cantidadDC
CHECK (cantidad > 0);

ALTER TABLE DetalleCompra
ADD CONSTRAINT valida_preciouniDC
CHECK (precio_unitario > 0);



--Tabla de Log que servirá como auditoria para guardar los cambios en las tablas más importantes del sistema
CREATE TABLE LogSistema (
    codigo_log INT PRIMARY KEY IDENTITY(1,1),
    fecha_hora DATETIME NOT NULL DEFAULT GETDATE(),
    usuario_sistema NVARCHAR(50) NOT NULL,
    accion NVARCHAR(100) NOT NULL,
    tabla_afectada NVARCHAR(50) NOT NULL,
    registro_afectado NVARCHAR(100) NOT NULL,
    campo_afectado NVARCHAR(500) NOT NULL
);



--Tabla para guardar la evolucion del estado de cada pedido
CREATE TABLE HistorialEstadoPedido (
codigo_historial INT PRIMARY KEY IDENTITY(1,1),
codigo_pedido INT NOT NULL,
codigo_tipoestado INT NOT NULL,
hora_cambio DATETIME NOT NULL DEFAULT GETDATE(),
FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
FOREIGN KEY (codigo_tipoestado) REFERENCES TipoEstado(codigo_tipoestado)
);
GO