USE El_Doradito
GO

/*=== CREACIÓN DE GENERADOR DE DATOS SINTÉTICOS ===*/
--Evaluaremos en la tabla DetallePedido
--Para ello, necesitamos tanto datos en Pedido como en DetallePedido

--Creacion de datos sintéticos de prueba en Pedido
;WITH Numeros AS
(
SELECT TOP (10000)
ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Numero
FROM sys.all_objects AS A
CROSS JOIN sys.all_objects AS B
),
Pedidos AS
(
SELECT Numero,
CASE
WHEN Numero % 3 = 0 THEN 1
WHEN Numero % 3 = 1 THEN 2
ELSE 3
END AS codigo_tipopedido
FROM Numeros
),
Clientes AS
(
SELECT
codigo_cliente,
ROW_NUMBER() OVER (ORDER BY codigo_cliente) AS NroCliente
FROM dbo.Cliente
),
ClientesTelefono AS
(
SELECT codigo_cliente,
ROW_NUMBER() OVER (ORDER BY codigo_cliente) AS NroCliente
FROM dbo.Cliente
WHERE telefono IS NOT NULL
),
PedidosClientes AS
(
SELECT p.Numero, p.codigo_tipopedido,
CASE
WHEN p.codigo_tipopedido = 2 THEN
(
SELECT codigo_cliente
FROM ClientesTelefono
WHERE NroCliente = ((p.Numero - 1) % 24) + 1
)
ELSE
(
SELECT codigo_cliente
FROM Clientes
WHERE NroCliente =
((p.Numero - 1) % (SELECT COUNT(*) FROM Clientes)) + 1
)
END AS codigo_cliente
FROM Pedidos p
)
INSERT INTO dbo.Pedido
(
codigo_cliente,
codigo_tipopedido,
codigo_tipoestado,
codigo_direccion,
codigo_mesa,
total_pagar
)
SELECT
pc.codigo_cliente,
pc.codigo_tipopedido,
CASE
WHEN pc.codigo_tipopedido = 1 THEN 5
WHEN pc.codigo_tipopedido = 2 THEN 11
WHEN pc.codigo_tipopedido = 3 THEN 16
END,
CASE
WHEN pc.codigo_tipopedido = 2 THEN
(
SELECT TOP 1 d.codigo_direccion
FROM Direccion d
WHERE d.codigo_cliente = pc.codigo_cliente
ORDER BY d.codigo_direccion
)
ELSE NULL
END,
CASE
WHEN pc.codigo_tipopedido = 1 THEN
((pc.Numero - 1) % 15) + 1
WHEN pc.codigo_tipopedido = 2 THEN 17
WHEN pc.codigo_tipopedido = 3 THEN 16
END,
0
FROM PedidosClientes pc;

--Verificamos que se hayan ingresado todos
SELECT COUNT(*) AS TotalPedidos
FROM Pedido;



--Creación de datos sintéticos para la tabla DetallePedido
;WITH Numeros AS
(
SELECT TOP (40000)
ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Numero --row number para consecutivos
FROM sys.all_objects AS A
CROSS JOIN sys.all_objects AS B --para multiplicar las filas
),
Detalles AS
(
SELECT Numero,
((Numero - 1) / 4) + 1 AS NroPedido, --esto calcula a que pedido pertenece cada numero
--Si numero = 1 al 4, saldrá 1, pertenece al pedido 1
--Si numero = 5 al 8, saldrá 2, pertenece al pedido 2
--Y continua, saldrá un total de 10000 pedidos, los que creamos antes
((Numero - 1) % 40) + 1 AS codigo_producto --calcula productos del 1 al 40, consecutivamente
--Cuando resulte 40, el siguiente resultado será 1, y seguirá con 2
FROM Numeros
)
INSERT INTO DetallePedido (codigo_pedido, codigo_producto, cantidad,precio_unitario)
SELECT 70 + d.NroPedido AS codigo_pedido, --70 + porque queremos que empiece desde el pedido 71
d.codigo_producto,
((d.Numero * 7) % 5) + 1 AS cantidad, --genera valores de cantidad de 1 a 5
--NO es aleatorio, siguen un patrón (ver resultados)
p.precio_producto AS precio_unitario
FROM Detalles d
JOIN Producto p
ON p.codigo_producto = d.codigo_producto --esto ayuda a que busquemos bien el precio del producto
--haciendo join a Producto
SELECT COUNT(*) AS TotalDetalles
FROM DetallePedido;



/*===PRUEBA DE RENDIMIENTO Y CREACIÓN DEL INDICE===*/
--Activamos estadísticas
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

--Definiremos una consulta para la prueba
--¿En qué pedidos aparece el producto "1/4 Pollo a la brasa", es decir, el producto con código 3?
SELECT *
FROM dbo.DetallePedido
WHERE codigo_producto = 3;

--Ahora crearemos el índice
--Como actualmente DetallePedido tiene clustered index de código_pedido -> código_producto
--Crearemos un nonclustered que busque por código_producto, que incluya el resto de columnas
CREATE NONCLUSTERED INDEX IX_DetallePedido_Producto
ON dbo.DetallePedido(codigo_producto)
INCLUDE (cantidad, precio_unitario, subtotal);
GO

--Ahora volveremos a hacer la misma consulta y veremos el rendimiento
SELECT *
FROM dbo.DetallePedido
WHERE codigo_producto = 3;

--Luego de ver los cambios, desactivamos estadísticas
SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;