CREATE DATABASE El_Doradito
GO
USE El_Doradito
GO

/*
===============================================
SECCIÓN DE CREATES Y CONSTRAINTS (validaciones)
===============================================
*/
CREATE TABLE Cliente (
	codigo_cliente INT PRIMARY KEY IDENTITY(1,1),
	primer_nombre NVARCHAR(20) NOT NULL,
    segundo_nombre NVARCHAR(20),
    apellido_paterno NVARCHAR(20),
    apellido_materno NVARCHAR(20),
	telefono NVARCHAR(15),
    correo_electronico NVARCHAR(150),
	fecha_registro DATETIME NOT NULL DEFAULT GETDATE()
);
--validaciones para la tabla Cliente
ALTER TABLE Cliente
ADD CONSTRAINT valida_1nombrecliente
CHECK (primer_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_2nombrecliente
CHECK (segundo_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_1apellidocliente
CHECK (apellido_paterno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_2apellidocliente
CHECK (apellido_materno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_clientefono
CHECK (telefono NOT LIKE '%[^0-9+-]%');

ALTER TABLE Cliente
ADD CONSTRAINT valida_clientecorreo
CHECK (correo_electronico LIKE '%@%.%');

--Este CHECK valida que, si el telefono NO tiene valor, el correo tampoco deberia tenerlo,
--porque quiere decir que el cliente ya se registro (para lo que se necesita telefono), lo que es inconsistente
ALTER TABLE Cliente
ADD CONSTRAINT valida_correo_sintelefono
CHECK (correo_electronico IS NULL OR telefono IS NOT NULL)

CREATE UNIQUE INDEX uq_cliente_telefono
ON Cliente(telefono)
WHERE telefono IS NOT NULL;

CREATE UNIQUE INDEX uq_cliente_correo
ON Cliente(correo_electronico)
WHERE correo_electronico IS NOT NULL;



CREATE TABLE TipoPedido (
    codigo_tipopedido INT PRIMARY KEY IDENTITY(1,1),
    descripcion NVARCHAR(40) NOT NULL UNIQUE
);
--validaciones para la tabla TipoPedido
ALTER TABLE TipoPedido
ADD CONSTRAINT valida_tipopedido_txt
CHECK (descripcion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');



CREATE TABLE TipoEstado (
    codigo_tipoestado INT PRIMARY KEY IDENTITY(1,1),
    codigo_tipopedido INT NOT NULL,
    descripcion NVARCHAR(50) NOT NULL,
    orden_estado INT NOT NULL,
    FOREIGN KEY (codigo_tipopedido) REFERENCES TipoPedido(codigo_tipopedido)
);
--validaciones para la tabla TipoEstado
ALTER TABLE TipoEstado
ADD CONSTRAINT valida_tipoestado
CHECK (descripcion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE TipoEstado
ADD CONSTRAINT valida_ordenestado
CHECK (orden_estado > 0);

ALTER TABLE TipoEstado
ADD CONSTRAINT unico_tipoestado_orden
UNIQUE (codigo_tipopedido, orden_estado);

ALTER TABLE TipoEstado
ADD CONSTRAINT unico_tipoestado_descripcion
UNIQUE (codigo_tipopedido, descripcion);



CREATE TABLE Mesa (
	codigo_mesa INT PRIMARY KEY IDENTITY(1,1),
	numero_mesa INT NOT NULL UNIQUE,
	cantidad_asientos INT NOT NULL,
	estado_mesa NVARCHAR(20) NOT NULL
);
--validaciones para la tabla Mesa
ALTER TABLE Mesa
ADD CONSTRAINT valida_numeromesa
CHECK (numero_mesa > 0);

ALTER TABLE Mesa
ADD CONSTRAINT valida_cantiasientos
CHECK (cantidad_asientos > 0 OR numero_mesa IN (98,99));

ALTER TABLE Mesa
ADD CONSTRAINT valida_estadomesa
CHECK (estado_mesa IN ('Libre', 'Ocupada'));



CREATE TABLE Rol (
    codigo_rol INT PRIMARY KEY IDENTITY(1,1),
    descripcion NVARCHAR(30) NOT NULL UNIQUE
);
--validaciones para la tabla Rol
ALTER TABLE Rol
ADD CONSTRAINT rol_descripcion_valida
CHECK (descripcion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');



CREATE TABLE Empleado (
	codigo_empleado INT PRIMARY KEY IDENTITY(1,1),
	primer_nombre NVARCHAR(20) NOT NULL,
    segundo_nombre NVARCHAR(20),
    apellido_paterno NVARCHAR(20),
	apellido_materno NVARCHAR(20),
	telefono NVARCHAR(20) NOT NULL UNIQUE,
    tipo_documento NVARCHAR(50) NOT NULL,
	numero_documento NVARCHAR(20) NOT NULL UNIQUE,
	direccion NVARCHAR(200),
	hora_entrada TIME NOT NULL,
	hora_salida TIME NOT NULL,
	fecha_ingreso DATETIME NOT NULL DEFAULT GETDATE(),
    codigo_rol INT NOT NULL,
    FOREIGN KEY (codigo_rol) REFERENCES Rol(codigo_rol)
);
--validaciones para la tabla Empleado
ALTER TABLE Empleado
ADD CONSTRAINT valida_1nombreempleado
CHECK (primer_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_2nombreempleado
CHECK (segundo_nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_1apellidoempleado
CHECK (apellido_paterno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_2apellidoempleado
CHECK (apellido_materno NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_empleadofono
CHECK (telefono NOT LIKE '%[^0-9+-]%');

ALTER TABLE Empleado
ADD CONSTRAINT valida_tipodocempleado
CHECK (tipo_documento IN ('DNI','Carnet de extranjeria','Pasaporte','Otro'));

ALTER TABLE Empleado
ADD CONSTRAINT valida_numdocempleado
CHECK (numero_documento NOT LIKE '%[^A-Za-z0-9]%');



CREATE TABLE Ingrediente (
	codigo_ingrediente INT PRIMARY KEY IDENTITY(1,1),
	nombre_ingrediente NVARCHAR(100) NOT NULL UNIQUE,
	unidad_medida NVARCHAR(20) NOT NULL
);
--validaciones para la tabla Ingrediente
ALTER TABLE Ingrediente
ADD CONSTRAINT nombre_ingrediente_valido
CHECK (nombre_ingrediente NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

ALTER TABLE Ingrediente
ADD CONSTRAINT unimedida_ingrediente
CHECK (unidad_medida IN ('kg','g','litro','ml','unidad'));



CREATE TABLE Proveedor (
	codigo_proveedor INT PRIMARY KEY IDENTITY(1,1),
	nombre NVARCHAR(100) NOT NULL UNIQUE,
	telefono NVARCHAR(20) NOT NULL UNIQUE,
	correo_electronico NVARCHAR(100) NOT NULL UNIQUE,
	direccion NVARCHAR(200)
);
--validaciones para la tabla Proveedor
ALTER TABLE Proveedor
ADD CONSTRAINT nombre_proveedor_valido
CHECK (nombre NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 .-]%');

ALTER TABLE Proveedor
ADD CONSTRAINT telefono_proveedor_valido
CHECK (telefono NOT LIKE '%[^0-9+-]%');

ALTER TABLE Proveedor
ADD CONSTRAINT correo_proveedor_valido
CHECK (correo_electronico LIKE '%@%.%');



CREATE TABLE Distrito (
    codigo_distrito INT PRIMARY KEY IDENTITY(1,1),
    nombre_distrito NVARCHAR(50) NOT NULL UNIQUE,
    atiende_delivery NVARCHAR(10) NOT NULL
);
--validaciones para la tabla Distrito
ALTER TABLE Distrito
ADD CONSTRAINT nombre_distrito_valido
CHECK (nombre_distrito NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

ALTER TABLE Distrito
ADD CONSTRAINT atiende_delivery_valido
CHECK (atiende_delivery IN ('Si','No'));



CREATE TABLE Categoria (
    codigo_categoria INT PRIMARY KEY IDENTITY(1,1),
    nombre_categoria NVARCHAR(30) NOT NULL UNIQUE
);
--validaciones para la tabla Categoria
ALTER TABLE Categoria
ADD CONSTRAINT valida_nombre_categoria
CHECK (nombre_categoria NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ ]%');



CREATE TABLE Producto (
	codigo_producto INT PRIMARY KEY IDENTITY(1,1),
	nombre_producto NVARCHAR(100) NOT NULL UNIQUE,
	descripcion NVARCHAR(255),
	precio_producto DECIMAL(10, 2) NOT NULL,
	disponibilidad NVARCHAR(20) NOT NULL,
    costo_producto DECIMAL(10,2) NOT NULL,
    codigo_categoria INT NOT NULL,
    FOREIGN KEY (codigo_categoria) REFERENCES Categoria(codigo_categoria)
);
--validaciones para la tabla Producto
ALTER TABLE Producto
ADD CONSTRAINT valida_nomproducto
CHECK (nombre_producto NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 .+/()-]%');

ALTER TABLE Producto
ADD CONSTRAINT valida_precioproducto
CHECK (precio_producto > 0);

ALTER TABLE Producto
ADD CONSTRAINT valida_productodispo
CHECK (disponibilidad IN ('Disponible', 'No disponible'));

ALTER TABLE Producto
ADD CONSTRAINT valida_costoproducto
CHECK (costo_producto > 0);



CREATE TABLE Direccion (
    codigo_direccion INT PRIMARY KEY IDENTITY(1,1),
    codigo_cliente INT NOT NULL,
    codigo_distrito INT NOT NULL,
    tipo_direccion NVARCHAR(30) NOT NULL,
    direccion NVARCHAR(255) NOT NULL,
    FOREIGN KEY (codigo_cliente) REFERENCES Cliente(codigo_cliente),
    FOREIGN KEY (codigo_distrito) REFERENCES Distrito(codigo_distrito)
);
--validaciones para la tabla Direccion
ALTER TABLE Direccion
ADD CONSTRAINT valida_tipodireccion
CHECK (tipo_direccion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

--Esta validacion es especial ya que ayudará a que en la tabla
--Pedido, el código de dirección colocado realmente sea el que le 
--pertenezca al cliente que hace el pedido
ALTER TABLE Direccion
ADD CONSTRAINT unico_direccion_cliente
UNIQUE (codigo_direccion, codigo_cliente);



CREATE TABLE Pedido (
	codigo_pedido INT PRIMARY KEY IDENTITY(1,1),
	codigo_cliente INT NOT NULL,
    codigo_tipopedido INT NOT NULL,
    codigo_tipoestado INT NOT NULL,
    codigo_direccion INT,
    codigo_mesa INT NOT NULL,
	fecha_pedido DATETIME NOT NULL DEFAULT GETDATE(),
	total_pagar DECIMAL(10, 2) DEFAULT 0 NOT NULL,
	FOREIGN KEY (codigo_cliente) REFERENCES Cliente(codigo_cliente),
    FOREIGN KEY (codigo_tipopedido) REFERENCES TipoPedido(codigo_tipopedido),
    FOREIGN KEY (codigo_tipoestado) REFERENCES TipoEstado(codigo_tipoestado),
    FOREIGN KEY (codigo_direccion, codigo_cliente)
	REFERENCES Direccion(codigo_direccion, codigo_cliente),
    FOREIGN KEY (codigo_mesa) REFERENCES Mesa(codigo_mesa),
);
--validaciones para la tabla Pedido
ALTER TABLE Pedido
ADD CONSTRAINT check_totalpago
CHECK (total_pagar >= 0);




CREATE TABLE Comprobante (
    codigo_comprobante INT PRIMARY KEY IDENTITY(1,1),
    codigo_pedido INT NOT NULL UNIQUE,
	tipo_comprobante NVARCHAR(20) NOT NULL,
    numero_comprobante NVARCHAR(20) NOT NULL UNIQUE,
    fecha_emision DATETIME NOT NULL DEFAULT GETDATE(),
    subtotal DECIMAL(10, 2) NOT NULL,
    IGV DECIMAL(8,2) NOT NULL,
    FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido)
);
--validaciones para la tabla Comprobante
ALTER TABLE Comprobante
ADD CONSTRAINT valida_tipocomprobante
CHECK (tipo_comprobante IN ('Boleta', 'Factura'));

ALTER TABLE Comprobante
ADD CONSTRAINT valida_numerocomprobante
CHECK (numero_comprobante NOT LIKE '%[^A-Za-z0-9 -]%');



CREATE TABLE Pago (
	codigo_pago INT PRIMARY KEY IDENTITY(1,1),
	codigo_pedido INT NOT NULL UNIQUE,
    codigo_empleado INT NOT NULL,
	fecha_pago DATETIME NOT NULL DEFAULT GETDATE(),
	monto_pago DECIMAL(10, 2) NOT NULL,
	metodo_pago NVARCHAR(20) NOT NULL,
	FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
    FOREIGN KEY (codigo_empleado) REFERENCES Empleado(codigo_empleado)
);
--validaciones para la tabla Pago
ALTER TABLE Pago
ADD CONSTRAINT valida_montopago
CHECK (monto_pago > 0);

ALTER TABLE Pago
ADD CONSTRAINT valida_metodopago
CHECK (metodo_pago IN ('Efectivo', 'Yape', 'Tarjeta'));



CREATE TABLE ParticipacionPedido (
codigo_pedido INT NOT NULL,
codigo_empleado INT NOT NULL,
PRIMARY KEY (codigo_pedido, codigo_empleado),
tipo_participacion NVARCHAR(50) NOT NULL,
estado_participacion NVARCHAR(20) NOT NULL,
fecha_participacion DATETIME NOT NULL DEFAULT GETDATE(),
FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
FOREIGN KEY (codigo_empleado) REFERENCES Empleado(codigo_empleado)
);
--validaciones para la tabla ParticipacionPedido
ALTER TABLE ParticipacionPedido
ADD CONSTRAINT valida_tipo_participacion
CHECK (tipo_participacion NOT LIKE '%[^A-Za-zÁÉÍÓÚáéíóúÑñ0-9 ]%');

ALTER TABLE ParticipacionPedido
ADD CONSTRAINT valida_estado_participacion
CHECK (estado_participacion IN ('Activo','Cancelado'));

CREATE UNIQUE INDEX unica_participacion_activa
ON ParticipacionPedido(codigo_pedido, tipo_participacion)
WHERE estado_participacion = 'Activo';



CREATE TABLE CompraProveedor (
	codigo_compra INT PRIMARY KEY IDENTITY(1,1),
	codigo_proveedor INT NOT NULL,
	codigo_empleado INT NOT NULL,
	fecha_compra DATETIME NOT NULL DEFAULT GETDATE(),
	monto_total DECIMAL(12, 2) NOT NULL,
	FOREIGN KEY (codigo_proveedor) REFERENCES Proveedor(codigo_proveedor),
	FOREIGN KEY (codigo_empleado) REFERENCES Empleado(codigo_empleado)
);



CREATE TABLE DetallePedido (
	codigo_pedido INT NOT NULL,
	codigo_producto INT NOT NULL,
	cantidad INT NOT NULL,
	precio_unitario DECIMAL(10, 2) NOT NULL,
	subtotal AS (CAST(cantidad * precio_unitario AS DECIMAL(12,2))),
	PRIMARY KEY (codigo_pedido, codigo_producto),
	FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
	FOREIGN KEY (codigo_producto) REFERENCES Producto(codigo_producto)
);
--validaciones para la tabla DetallePedido
ALTER TABLE DetallePedido
ADD CONSTRAINT valida_cantidadDP
CHECK (cantidad > 0);

ALTER TABLE DetallePedido
ADD CONSTRAINT valida_preciouniDP
CHECK (precio_unitario > 0);



CREATE TABLE DetalleCompra (
	codigo_compra INT NOT NULL,
	codigo_ingrediente INT NOT NULL,
	cantidad INT NOT NULL,
	precio_unitario DECIMAL(10, 2) NOT NULL,
	subtotal AS (CAST(cantidad * precio_unitario AS DECIMAL(12,2))),
	PRIMARY KEY (codigo_compra, codigo_ingrediente),
	FOREIGN KEY (codigo_compra) REFERENCES CompraProveedor(codigo_compra),
	FOREIGN KEY (codigo_ingrediente) REFERENCES Ingrediente(codigo_ingrediente)
);
--validaciones para la tabla DetalleCompra
ALTER TABLE DetalleCompra
ADD CONSTRAINT valida_cantidadDC
CHECK (cantidad > 0);

ALTER TABLE DetalleCompra
ADD CONSTRAINT valida_preciouniDC
CHECK (precio_unitario > 0);



--Tabla de Log que servirá como auditoria para guardar los cambios en las tablas más importantes del sistema
CREATE TABLE LogSistema (
    codigo_log INT PRIMARY KEY IDENTITY(1,1),
    fecha_hora DATETIME NOT NULL DEFAULT GETDATE(),
    usuario_sistema NVARCHAR(50) NOT NULL,
    accion NVARCHAR(100) NOT NULL,
    tabla_afectada NVARCHAR(50) NOT NULL,
    registro_afectado NVARCHAR(100) NOT NULL,
    campo_afectado NVARCHAR(500) NOT NULL
);



--Tabla para guardar la evolucion del estado de cada pedido
CREATE TABLE HistorialEstadoPedido (
codigo_historial INT PRIMARY KEY IDENTITY(1,1),
codigo_pedido INT NOT NULL,
codigo_tipoestado INT NOT NULL,
hora_cambio DATETIME NOT NULL DEFAULT GETDATE(),
FOREIGN KEY (codigo_pedido) REFERENCES Pedido(codigo_pedido),
FOREIGN KEY (codigo_tipoestado) REFERENCES TipoEstado(codigo_tipoestado)
);
GO

/*
===================
SECCIÓN DE TRIGGERS
===================
*/
/*=== VALIDACIONES DE PERMISOS DE EMPLEADOS ===*/
--Si el pedido es presencial, deben participar empleados con cargo 'Camarero' en el pedido
--Además, su tipo de participacion debe ser 'Atiende pedido presencial'
CREATE TRIGGER tri_pedido_presencial
ON ParticipacionPedido
AFTER INSERT, UPDATE
AS BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion IN ('Presencial en mesa', 'Presencial para recoger')
AND i.estado_participacion = 'Activo'
AND i.tipo_participacion <> 'Atiende pedido presencial'
)
BEGIN
RAISERROR ('ERROR: Los pedidos presenciales deben tener un tipo de participación válido', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE i.tipo_participacion = 'Atiende pedido presencial'
AND i.estado_participacion = 'Activo'
AND tp.descripcion IN ('Presencial en mesa', 'Presencial para recoger')
AND r.descripcion <> 'Camarero'
)
BEGIN
RAISERROR ('ERROR: Solo los Camareros pueden tener la participación "Atiende pedido presencial"', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO


--Si el pedido es delivery, deben participar empleados con cargo 'Anfitrión telefónico' y 'Repartidor' en el pedido
--Además, su tipo de participacion debe ser 'Anota pedido delivery' y 'Entrega pedido delivery', respectivamente
CREATE TRIGGER tri_pedido_delivery
ON ParticipacionPedido
AFTER INSERT, UPDATE
AS BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion = 'Delivery'
AND i.tipo_participacion NOT IN ('Anota pedido delivery', 'Entrega pedido delivery')
)
BEGIN
RAISERROR ('ERROR: Los pedidos delivery deben tener un tipo de participación válido', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE i.tipo_participacion = 'Anota pedido delivery'
AND tp.descripcion = 'Delivery'
AND r.descripcion <> 'Anfitrion telefonico'
)
BEGIN
RAISERROR ('ERROR: Solo Anfitriones Telefónicos pueden tener la participación "Anota pedido delivery"', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE i.tipo_participacion = 'Entrega pedido delivery'
AND tp.descripcion = 'Delivery'
AND r.descripcion <> 'Repartidor'
)
BEGIN
RAISERROR ('ERROR: Solo Repartidores pueden tener la participación "Entrega pedido delivery"', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO

--Los pagos deben tener un empleado asociado:
--Si el pedido es presencial, solo empleados con rol 'Cajero' pueden registrarlos
--Si el pedido es delivery, solo empleados con rol 'Repartidor' pueden cobrarlos
CREATE TRIGGER tri_pago_segun_tipopedido
ON Pago
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
WHERE codigo_empleado IS NULL
)
BEGIN
RAISERROR ('ERROR: Debe existir un empleado asociado al pago', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON r.codigo_rol = e.codigo_rol
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion IN ('Presencial para recoger', 'Presencial en mesa')
AND r.descripcion <> 'Cajero'
)
BEGIN
RAISERROR ('ERROR: Solo Cajeros pueden registrar pagos para pedidos presenciales', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Pedido p
ON i.codigo_pedido = p.codigo_pedido
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON r.codigo_rol = e.codigo_rol
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion = 'Delivery'
AND r.descripcion <> 'Repartidor'
)
BEGIN
RAISERROR ('ERROR: Solo Repartidores pueden cobrar pagos para pedidos delivery', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--La compra a un proveedor debe tener un Administrador asociado, y solo empleados
--con rol 'Administrador' pueden registrarlas
CREATE TRIGGER tri_compra_admin
ON CompraProveedor
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
WHERE i.codigo_empleado IS NULL
)
BEGIN
RAISERROR('ERROR: Debe existir un empleado asociado a la compra', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN Empleado e
ON i.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE r.descripcion <> 'Administrador'
)
BEGIN
RAISERROR('ERROR: Solo Administradores pueden registrar compras a proveedores', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



/*=== VALIDACIÓN DE REGLAS DE NEGOCIO PARA EL PEDIDO ===*/
--Si el pedido es delivery, se asociará a una mesa virtual de número 99
--Si el pedido es 'Presencial para recoger', se asociará a otra mesa virtual de número 98
--Si el pedido es 'Presencial en mesa', se asociará a una mesa física (10 - 24)
CREATE TRIGGER tri_mesas_tipopedido
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Mesa m
ON i.codigo_mesa = m.codigo_mesa
WHERE tp.descripcion = 'Delivery'
AND m.numero_mesa <> 99
)
BEGIN
RAISERROR('ERROR: Los pedidos Delivery deben usar la mesa virtual (99)', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Mesa m
ON i.codigo_mesa = m.codigo_mesa
WHERE tp.descripcion = 'Presencial para recoger'
AND m.numero_mesa <> 98
)
BEGIN
RAISERROR ('ERROR: Los pedidos de modalidad "Presencial para recoger" deben usar la mesa virtual (98)', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;


IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Mesa m
ON i.codigo_mesa = m.codigo_mesa
WHERE tp.descripcion = 'Presencial en mesa'
AND m.numero_mesa IN (98,99)
)
BEGIN
RAISERROR ('ERROR: Los pedidos de modalidad "Presencial en mesa" deben usar números de mesas físicas', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO


--Si el pedido es delivery, el distrito de la dirección asociada debe atender por ahí
CREATE TRIGGER tri_distrito_delivery
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN Direccion d
ON i.codigo_direccion = d.codigo_direccion
INNER JOIN Distrito dt
ON d.codigo_distrito = dt.codigo_distrito
WHERE tp.descripcion = 'Delivery'
AND dt.atiende_delivery <> 'Si'
)
BEGIN
RAISERROR('ERROR: El distrito de la dirección asociada no atiende pedidos delivery', 16, 1);
ROLLBACK TRANSACTION;
END;
END;
GO


--Un pedido presencial NO debe tener código dirección, es decir, que el código sea NULL
--De igual manera, un delivery DEBE tener código de dirección, es decir, que el código sea distinto de NULL
CREATE TRIGGER tri_direccion_pedido
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion = 'Delivery' AND i.codigo_direccion IS NULL
)
BEGIN
RAISERROR('ERROR: Un pedido delivery debe tener una direccion asociada', 16, 1); 
ROLLBACK TRANSACTION;
RETURN;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoPedido tp
ON i.codigo_tipopedido = tp.codigo_tipopedido
WHERE tp.descripcion IN ('Presencial en mesa', 'Presencial para recoger')
AND i.codigo_direccion IS NOT NULL
)
BEGIN
RAISERROR('ERROR: Un pedido presencial no debe tener direccion asociada', 16, 1);
ROLLBACK TRANSACTION;
RETURN;
END;
END;
GO



--El tipo de estado del pedido debe pertenecer al tipo de pedido seleccionado
CREATE TRIGGER tri_tipopedido_estado
ON Pedido
AFTER INSERT, UPDATE
AS
BEGIN
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN TipoEstado te
ON i.codigo_tipoestado = te.codigo_tipoestado
WHERE i.codigo_tipopedido <> te.codigo_tipopedido
)
BEGIN
RAISERROR('ERROR: El estado no pertenece al tipo de pedido seleccionado', 16, 1);
ROLLBACK TRANSACTION;
END;
END;
GO



/*=== AUTOMATIZACIONES DE CÁLCULOS ===*/
--Calcular automáticamente el monto total de la compra a un proveedor
--Este trigger actualizará la columna monto_total de la tabla CompraProveedor también
CREATE TRIGGER tri_actualiza_montocompra
ON DetalleCompra
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
UPDATE cp
SET monto_total =
(
SELECT ISNULL(SUM(subtotal),0)
FROM DetalleCompra dc
WHERE dc.codigo_compra = cp.codigo_compra
)
FROM CompraProveedor cp
WHERE cp.codigo_compra IN
(
SELECT codigo_compra FROM inserted
UNION
SELECT codigo_compra FROM deleted
);
END;
GO



--Calcular el total a pagar del pedido
--Funciona de manera similar al trigger anterior
CREATE TRIGGER tri_actualiza_totalpedido
ON DetallePedido
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
UPDATE p
SET total_pagar =
(
SELECT ISNULL(SUM(subtotal),0)
FROM DetallePedido dp
WHERE dp.codigo_pedido = p.codigo_pedido
)
FROM Pedido p
WHERE p.codigo_pedido IN
(
SELECT codigo_pedido FROM inserted
UNION
SELECT codigo_pedido FROM deleted
);
END;
GO



/*=== INTEGRIDAD DEL SISTEMA ===*/
--Para evitar que el codigo del cliente de un pedido sea modificado
CREATE TRIGGER tri_fijo_cliente_pedido
ON Pedido
AFTER UPDATE
AS
BEGIN
IF UPDATE(codigo_cliente)
BEGIN
RAISERROR('ERROR: El código del cliente NO puede ser modificado', 16, 1)
ROLLBACK TRANSACTION
RETURN
END;
END;
GO



/*=== EVOLUCION DE ESTADO DEL PEDIDO ===*/
--Cada vez que se cambie el estado de un pedido, se registrará en la tabla de historial
CREATE TRIGGER tri_historial_estado_pedido
ON Pedido
AFTER UPDATE
AS
BEGIN
IF UPDATE(codigo_tipoestado)
BEGIN
INSERT INTO HistorialEstadoPedido (codigo_pedido, codigo_tipoestado)
SELECT codigo_pedido, codigo_tipoestado
FROM inserted;
END;
END;
GO



/*=== AUDITORIA EN LOG ===*/
--Para auditar la tabla Pedido
CREATE TRIGGER tri_auditoria_pedido
ON Pedido 
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
--Si se inserta un nuevo registro
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'Pedido', CAST(i.codigo_pedido AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

--Si se elimina un registro
IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'Pedido', CAST(d.codigo_pedido AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

--Si se modifica uno o varios campos de un mismo registro
--O si se modifican diferentes campos de diferentes registros
IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pedido = d.codigo_pedido
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'Pedido', CAST(cambios.codigo_pedido AS NVARCHAR(100)),
--LEFT y LEN ayudaran a eliminar la ultima coma y el espacio
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
--creamos una subconsulta para obtener los campos que cambiaron en cada registro
(
SELECT i.codigo_pedido,
(
--No es necesario auditar codigo_cliente ya que no se podrá modificar (trigger)
--No es necesario auditar codigo_tipoestado ya que HistorialEstadoPedido se encargará de ello

--Si el codigo del tipo de pedido se modifica
CASE WHEN i.codigo_tipopedido <> d.codigo_tipopedido THEN 'codigo_tipopedido, ' ELSE '' END +

--Si el codigo de direccion del pedido se modifica
--Validamos adicionalmente si el inserted y deleted son o son distintos de NULL
CASE WHEN (i.codigo_direccion IS NULL AND d.codigo_direccion IS NOT NULL)
OR (i.codigo_direccion IS NOT NULL AND d.codigo_direccion IS NULL)
OR (i.codigo_direccion <> d.codigo_direccion) THEN 'codigo_direccion, ' ELSE '' END +

--Si el codigo del numero de mesa se modifica
CASE WHEN i.codigo_mesa <> d.codigo_mesa THEN 'codigo_mesa, ' ELSE '' END +

--Si la fecha del pedido se modifica
CASE WHEN i.fecha_pedido <> d.fecha_pedido THEN 'fecha_pedido, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pedido = d.codigo_pedido
) AS cambios
WHERE LEN(cambios.campos) > 0;
END;
END;
GO


--Para auditar la tabla Producto
--Mantiene la misma logica que el trigger anterior, pero adaptada a la tabla Producto
CREATE TRIGGER tri_auditoria_producto 
ON Producto 
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'Producto', CAST(i.codigo_producto AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'Producto', CAST(d.codigo_producto AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_producto = d.codigo_producto
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'Producto', CAST(cambios.codigo_producto AS NVARCHAR(100)),
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
(
SELECT
i.codigo_producto,
(CASE WHEN i.nombre_producto <> d.nombre_producto THEN 'nombre_producto, ' ELSE '' END +

CASE WHEN i.descripcion <> d.descripcion THEN 'descripcion, ' ELSE '' END +

CASE WHEN i.precio_producto <> d.precio_producto THEN 'precio_producto, ' ELSE '' END +

CASE WHEN (i.disponibilidad IS NULL AND d.disponibilidad IS NOT NULL)
OR (i.disponibilidad IS NOT NULL AND d.disponibilidad IS NULL)
OR (i.disponibilidad <> d.disponibilidad) THEN 'disponibilidad, ' ELSE '' END +

CASE WHEN i.costo_producto <> d.costo_producto THEN 'costo_producto, ' ELSE '' END +

CASE WHEN i.codigo_categoria <> d.codigo_categoria THEN 'codigo_categoria, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_producto = d.codigo_producto
) AS cambios
WHERE LEN(cambios.campos) > 0;
END;
END;
GO


--Para auditar la tabla Pago
CREATE TRIGGER tri_auditoria_pago 
ON Pago
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'Pago', CAST(i.codigo_pago AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'Pago', CAST(d.codigo_pago AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pago = d.codigo_pago
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'Pago', CAST(cambios.codigo_pago AS NVARCHAR(100)),
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
(
SELECT
i.codigo_pago,
(CASE WHEN i.codigo_pedido <> d.codigo_pedido THEN 'codigo_pedido, ' ELSE '' END +

CASE WHEN i.codigo_empleado <> d.codigo_empleado THEN 'codigo_empleado, ' ELSE '' END +

CASE WHEN i.fecha_pago <> d.fecha_pago THEN 'fecha_pago, ' ELSE '' END +

CASE WHEN i.monto_pago <> d.monto_pago THEN 'monto_pago, ' ELSE '' END +

CASE WHEN i.metodo_pago <> d.metodo_pago THEN 'metodo_pago, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_pago = d.codigo_pago
) AS cambios
END;
END;
GO


--Para auditar la tabla CompraProveedor
CREATE TRIGGER tri_auditoria_compraprovee 
ON CompraProveedor
AFTER INSERT, UPDATE, DELETE 
AS 
BEGIN
IF EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'INSERT', 'CompraProveedor', CAST(i.codigo_compra AS NVARCHAR(100)), 'Todos los campos'
FROM inserted i;
END;

IF EXISTS (SELECT 1 FROM deleted) AND NOT EXISTS (SELECT 1 FROM inserted)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'DELETE', 'CompraProveedor', CAST(d.codigo_compra AS NVARCHAR(100)), 'Todos los campos'
FROM deleted d;
END;

IF EXISTS
(
SELECT 1
FROM inserted i
INNER JOIN deleted d
ON i.codigo_compra = d.codigo_compra
)
BEGIN
INSERT INTO LogSistema (usuario_sistema, accion, tabla_afectada, registro_afectado, campo_afectado)
SELECT SYSTEM_USER, 'UPDATE', 'CompraProveedor', CAST(cambios.codigo_compra AS NVARCHAR(100)),
LEFT(cambios.campos,LEN(cambios.campos) - 2) FROM
(
SELECT
i.codigo_compra,
(CASE WHEN i.codigo_proveedor <> d.codigo_proveedor THEN 'codigo_proveedor, ' ELSE '' END +

CASE WHEN i.codigo_empleado <> d.codigo_empleado THEN 'codigo_empleado, ' ELSE '' END +

CASE WHEN i.fecha_compra <> d.fecha_compra THEN 'fecha_compra, ' ELSE '' END) AS campos
FROM inserted i
INNER JOIN deleted d
ON i.codigo_compra = d.codigo_compra
) AS cambios
WHERE LEN(cambios.campos) > 0;
END;
END;
GO



/*=== INSERTS ====*/
--Insert para la tabla CLIENTE
INSERT INTO Cliente (primer_nombre, segundo_nombre, apellido_paterno, apellido_materno, telefono, correo_electronico, fecha_registro) VALUES
('Pedro', NULL, 'Rojas', 'Farfan', '+51923191366', NULL, '2025-10-19'),
('Elizabeth', NULL, 'Paucar', 'Sulca', '+51932601884', 'elizabeth.paucar@gmail.com', '2024-05-12'),
('Jose', NULL, 'Ramos', 'Rojas', '+51956583265', 'jose.ramos@gmail.com', '2025-03-29'),
('Sofia', NULL, 'Gonzales', NULL, '+51923191224', NULL, '2026-04-14'),
('Anthony', NULL, 'Chavez', 'Yovera', '+51966780239', NULL, '2025-01-17'),
('Christian', NULL, 'Condori', NULL, NULL, NULL, '2026-05-21'),
('Maria', 'Miguel', 'Mendoza', NULL, '+51942114586', NULL, '2025-10-30'),
('Karen', NULL, 'Farfan', 'Sulca', NULL, NULL, '2024-03-18'),
('Christian', NULL, 'Flores', 'Mendoza', '+51937651355', NULL, '2025-12-17'),
('Daniel', 'Diana', 'Mamani', 'Lopez', '+51972831244', NULL, '2024-05-20'),
('Diego', 'Carmen', 'Chavez', 'Garcia', '+51926794938', NULL, '2024-04-07'),
('Luis', NULL, 'Sanchez', NULL, '+51954754098', NULL, '2026-05-08'),
('Luz', 'Diego', 'Gonzales', NULL, NULL, NULL, '2024-09-02'),
('Milagros', NULL, 'Quispe', NULL, NULL, NULL, '2025-02-22'),
('Miguel', 'Ana', 'Farfan', NULL, NULL, NULL, '2025-10-16'),
('Luis', 'Flor', 'Villanueva', NULL, NULL, NULL, '2026-06-26'),
('Carmen', NULL, 'Paucar', NULL, '+51998850403', NULL, '2024-11-26'),
('Pedro', NULL, 'Castillo', NULL, '+51919241322', 'pedro.castillo@gmail.com', '2024-10-02'),
('David', 'Diana', 'Ramos', NULL, NULL, NULL, '2024-09-09'),
('Alejandro', 'Sofia', 'Condori', 'Quispe', NULL, NULL, '2024-11-29'),
('Rosa', 'Carmen', 'Lopez', NULL, NULL, NULL, '2026-04-29'),
('Rosa', NULL, 'Solano', 'Condori', NULL, NULL, '2026-10-13'),
('Andrea', 'Daniel', 'Condori', 'Huaman', NULL, NULL, '2025-08-10'),
('Elena', 'Pedro', 'Mamani', 'Quispe', NULL, NULL, '2025-03-03'),
('Christian', NULL, 'Rojas', 'Chavez', NULL, NULL, '2024-02-23'),
('Elena', NULL, 'Mamani', 'Lopez', NULL, NULL, '2025-11-22'),
('Diego', 'Pedro', 'Paucar', NULL, '+51974324732', NULL, '2024-01-27'),
('Pedro', 'Diego', 'Mamani', NULL, '+51973493110', NULL, '2026-06-01'),
('Andrea', NULL, 'Rodriguez', NULL, '+51952261741', NULL, '2026-08-24'),
('Diana', NULL, 'Chavez', NULL, NULL, NULL, '2024-06-12'),
('Camila', 'Sofia', 'Lopez', NULL, NULL, NULL, '2024-04-17'),
('Milagros', NULL, 'Sanchez', 'Yovera', '+51933136316', NULL, '2024-02-26'),
('Carlos', NULL, 'Rodriguez', NULL, '+51930931194', NULL, '2025-12-20'),
('Luz', NULL, 'Chavez', 'Yovera', '+51954544545', 'luz.chavez@gmail.com', '2025-03-23'),
('Diego', NULL, 'Ramos', 'Garcia', NULL, NULL, '2026-05-29'),
('Angel', NULL, 'Paucar', NULL, '+51918971490', NULL, '2024-11-19'),
('Elena', 'Rosa', 'Chavez', NULL, '+51982341954', NULL, '2025-04-17'),
('Maria', 'Carlos', 'Yovera', NULL, NULL, NULL, '2026-08-16'),
('Alejandro', NULL, 'Flores', NULL, '+51970988427', NULL, '2026-08-10'),
('Andrea', 'Rosa', 'Garcia', 'Chavez', '+51933363319', NULL, '2025-01-07'),
('Anthony', 'Stephanie', 'Villanueva', NULL, NULL, NULL, '2025-07-26'),
('Elena', NULL, 'Diaz', 'Sulca', '+51955644096', 'elena.diaz@gmail.com', '2026-09-27'),
('Jose', 'Elena', 'Castillo', NULL, NULL, NULL, '2024-03-27'),
('Pedro', 'Manuel', 'Flores', 'Paucar', NULL, NULL, '2026-09-16'),
('Carlos', NULL, 'Sulca', NULL, NULL, NULL, '2024-09-29'),
('Carlos', NULL, 'Farfan', NULL, '+51976733775', NULL, '2025-05-22'),
('Alejandro', NULL, 'Gonzales', NULL, NULL, NULL, '2025-03-24'),
('Stephanie', 'Elizabeth', 'Huaman', NULL, NULL, NULL, '2025-12-12'),
('Pedro', NULL, 'Rojas', NULL, NULL, NULL, '2024-12-24'),
('Christian', NULL, 'Mendoza', NULL, NULL, NULL, '2026-09-03');



--Insert para la tabla TIPOPEDIDO
--Al ser de tipo catalogo no necesita muchos registros
INSERT INTO TipoPedido (descripcion) VALUES
('Presencial en mesa'),
('Delivery'),
('Presencial para recoger');



--Insert para la tabla TIPOESTADO
--Al igual que la anterior no necesita muchos registros
INSERT INTO TipoEstado (codigo_tipopedido, descripcion, orden_estado) VALUES
(1, 'Pedido tomado', 1),
(1, 'En preparacion', 2),
(1, 'Listo para servir', 3),
(1, 'Servido', 4),
(1, 'Pagado', 5),
(2, 'Pedido tomado', 1),
(2, 'En preparacion', 2),
(2, 'Listo para despacho', 3),
(2, 'En camino', 4),
(2, 'Entregado', 5),
(2, 'Pagado', 6),
(3, 'Pedido tomado', 1),
(3, 'En preparacion', 2),
(3, 'Listo para recoger', 3),
(3, 'Recogido', 4),
(3, 'Pagado', 5);


--Insert para la tabla MESA
--Como el restaurante solo tiene 15 mesas físicas documentadas, se colocarán esas
INSERT INTO Mesa (numero_mesa, cantidad_asientos, estado_mesa) VALUES
(10, 4, 'Ocupada'),
(11, 4, 'Ocupada'),
(12, 4, 'Ocupada'),
(13, 4, 'Ocupada'),
(14, 4, 'Ocupada'),
(15, 4, 'Ocupada'),
(16, 4, 'Ocupada'),
(17, 4, 'Ocupada'),
(18, 6, 'Ocupada'),
(19, 6, 'Ocupada'),
(20, 6, 'Libre'),
(21, 6, 'Libre'),
(22, 8, 'Libre'),
(23, 8, 'Libre'),
(24, 6, 'Libre'),
(98, 0, 'Libre'),
(99, 0, 'Libre');

SELECT COUNT(*) FROM Cliente;
SELECT COUNT(*) FROM Pedido;
SELECT COUNT(*) FROM DetallePedido;
SELECT COUNT(*) FROM Producto;
SELECT COUNT(*) FROM Pago;
SELECT COUNT(*) FROM HistorialEstadoPedido;

--Insert para la tabla ROL
--Como es tipo catalogo no necesita muchos registros
INSERT INTO Rol (descripcion) VALUES
('Camarero'), --codigo rol 1
('Cocinero'), --codigo rol 2
('Cajero'), --codigo rol 3
('Anfitrion telefonico'), --codigo rol 4
('Repartidor'), --codigo rol 5
('Administrador'); --codigo rol 6



--Insert para la tabla EMPLEADO
--Se documentaron solo 11 empleados existentes en el restaurante
INSERT INTO Empleado (primer_nombre, segundo_nombre, apellido_paterno, apellido_materno, telefono, tipo_documento, numero_documento, direccion, hora_entrada, hora_salida, fecha_ingreso, codigo_rol) VALUES
('Gustavo', 'Patricia', 'Zamora', 'Alvarez', '+51989589509', 'Pasaporte', '33742716A', 'Av. Antúnez de Mayolo 415 - Los Olivos', '4:48', '12:48:00', '2022-10-05', 1),
('Roxana', 'Monica', 'Herrera', 'Zapata', '+51987842888', 'Pasaporte', '42086982A', 'Av. Grandi 312 - Ate', '11:00', '19:00:00', '2023-02-06', 2),
('Eduardo', 'Walter', 'Delgado', 'Nuñez', '+51983511336', 'Pasaporte', '76332045A', 'Av. Mariano Cornejo 930 - Breña', '11:06', '19:06:00', '2024-05-17', 5),
('Julia', 'Gustavo', 'Castro', 'Vargas', '+51980522337', 'DNI', '59537296', 'Av. Grandi 312 - Ate', '4:43', '12:43:00', '2023-09-29', 3),
('Patricia', 'Santiago', 'Alvarez', 'Medina', '+51981863792', 'Carnet de extranjeria', '86338144A', 'Av. San Luis 2205 - San Borja', '12:29', '20:29:00', '2023-09-25', 6),
('Cesar', 'Hector', 'Nuñez', 'Herrera', '+51981474481', 'Otro', 'X718853', 'Av. San Luis 2205 - San Borja', '22:55', '06:55:00', '2024-01-20', 5),
('Veronica', null, 'Zapata', 'Silva', '+51983054953', 'Pasaporte', '99952923A', 'Av. San Luis 2205 - San Borja', '16:49', '00:49:00', '2023-03-04', 2),
('Gustavo', 'Cesar', 'Herrera', 'Delgado', '+51985546409', 'Pasaporte', '71785414A', 'Av. San Juan 820 - San Juan de Miraflores', '1:33', '09:33:00', '2022-06-11', 2),
('Santiago', null, 'Quintana', 'Nuñez', '+51988891675', 'Otro', 'X387445', 'Av. San Juan 820 - San Juan de Miraflores', '20:37', '04:37:00', '2023-03-12', 1),
('Santiago', 'Ricardo', 'Alvarez', 'Herrera', '+51989804595', 'Otro', 'X939292', 'Av. San Luis 2205 - San Borja', '18:07', '02:07:00', '2021-11-03', 4),
('Monica', 'Cecilia', 'Ibañez', 'Palomino', '+51984629064', 'Otro', 'X944619', 'Av. Grandi 312 - Ate', '5:53', '13:53:00', '2022-11-21', 1);



--Insert para la tabla INGREDIENTE
INSERT INTO Ingrediente (nombre_ingrediente, unidad_medida) VALUES
('Pollo entero', 'kg'),
('Papa canchan', 'kg'),
('Papa huayro', 'kg'),
('Camote', 'kg'),
('Arroz blanco', 'kg'),
('Carne de res', 'kg'),
('Pechuga de pollo', 'kg'),
('Carne de cerdo', 'kg'),
('Col china', 'kg'),
('Cebolla china', 'kg'),
('Pimiento rojo', 'kg'),
('Holantao', 'kg'),
('Brocoli', 'kg'),
('Zanahoria', 'kg'),
('Tamarindo', 'kg'),
('Azucar blanca', 'kg'),
('Sal de cocina', 'kg'),
('Cebolla roja', 'kg'),
('Maiz morado', 'kg'),
('Ajo molido', 'kg'),
('Kion fresco', 'kg'),
('Almidon de chuño', 'kg'),
('Ajinomoto', 'g'),
('Pimienta blanca molida', 'g'),
('Canela china', 'g'),
('Cinco sabores', 'g'),
('Polvo de hornear', 'g'),
('Sazonador para pollo', 'g'),
('Comino molido', 'g'),
('Oregano molido', 'g'),
('Sillao claro', 'litro'),
('Aceite vegetal', 'litro'),
('Vinagre tinto', 'litro'),
('Sillao oscuro', 'litro'),
('Salsa de ostion', 'litro'),
('Aceite de ajonjoli', 'litro'),
('Cerveza negra', 'litro'),
('Pisco vargas', 'litro'),
('Esencia de vainilla', 'litro'),
('Tinte vegetal rojo', 'ml'),
('Salsa inglesa', 'litro'),
('Colorante amarillo', 'ml'),
('Vinagre blanco', 'litro'),
('Bolsa para llevar', 'unidad'),
('Envase de tecnopor', 'unidad'),
('Caja para pollo', 'unidad'),
('Tapers para ensalada', 'unidad'),
('Huevo', 'unidad'),
('Piña', 'unidad');



--Insert para la tabla PROVEEDOR
INSERT INTO Proveedor (nombre, telefono, correo_electronico, direccion) VALUES
('San Fernando', '912345678', 'ventas@sanfernando.com.pe', 'Av. Industrial 1250, Independencia'),
('Redondos', '923456789', 'contacto@redondos.com.pe', 'Av. Alfredo Mendiola 8450, Los Olivos'),
('Avinka', '934567890', 'pedidos@avinka.com.pe', 'Jr. Huallaga 350, Cercado de Lima'),
('Alicorp', '945678901', 'ventas@alicorp.com.pe', 'Av. Nicolás Ayllón 4250, Ate'),
('Costeño', '956789012', 'ventas@costeño.com.pe', 'Av. Universitaria 1250, Los Olivos'),
('Gloria', '967890123', 'pedidos@gloria.com.pe', 'Av. La Marina 2345, Surco'),
('Laive', '978901234', 'pedidos@laive.com.pe', 'Jr. Los Pinos 245, Comas'),
('Molitalia', '989012345', 'pedidos@molitalia.com.pe', 'Av. La Molina 1234, La Molina'),
('Coca-Cola Perú', '990123456', 'ventas@cocacola.com.pe', 'Av. Grau 1234, Barranco'),
('Backus', '901234567', 'ventas@backus.com.pe', 'Av. Javier Prado 567, Surco'),
('Inca Kola Distribuciones', '912345679', 'ventas@incakola.com.pe', 'Av. Tupac Amaru 1234, Ate'),
('Papas Andinas SAC', '923456780', 'ventas@papasandinas.com.pe', 'Av. Brasil 1234, Ate'),
('Distribuidora Santa Anita', '934567891', 'ventas@santaanita.com.pe', 'Av. Santa Anita 1234, Santa Anita'),
('Mercado Mayorista Unicachi', '945678902', 'ventas@unicachi.com.pe', 'Av. Unicachi 1234, Ate'),
('Frutas y Verduras Lima Norte SAC', '956789013', 'ventas@frutasverduras.com.pe', 'Av. Lima Norte 1234, Ate'),
('Pollos del Norte', '967890124', 'ventas@pollosdelnorte.com.pe', 'Av. Del Norte 1234, Ate'),
('Carnes y Aves S.A.', '978901235', 'ventas@carnesyaves.com.pe', 'Av. Carnes 1234, Ate'),
('Distribuidora La Pollería', '989012346', 'ventas@lapolleria.com.pe', 'Av. La Pollería 1234, Ate'),
('Abarrotes y Más S.A.', '990123457', 'ventas@abarrotesymas.com.pe', 'Av. Abarrotes 1234, Ate'),
('Bebidas y Snacks S.A.', '901234568', 'ventas@bebidasySnacks.com.pe', 'Av. Bebidas 1234, Ate');



--Insert para la tabla DISTRITO
--Se registran algunos distritos, los mas relevantes
INSERT INTO Distrito (nombre_distrito, atiende_delivery) VALUES
('Independencia', 'Si'),
('La Molina', 'No'),
('San Martin de Porres', 'Si'),
('Miraflores', 'No'),
('Comas', 'Si'),
('Puente Piedra', 'Si'),
('Rimac', 'Si'),
('San Borja', 'No'),
('Ate', 'No'),
('Cercado de Lima', 'Si'),
('Callao', 'Si'),
('San Isidro', 'No'),
('Santa Anita', 'No');



--Insert para la tabla CATEGORIA
--Como es de tipo catálogo no requiere muchos registros
INSERT INTO Categoria (nombre_categoria) VALUES
('Pollo a la brasa'),
('Sopas y entradas'),
('Arroz chaufa'),
('Aeropuertos y combinados'),
('Platos chifa'),
('Parrillas y carnes'),
('Porciones y acompañamientos'),
('Bebidas');


--Insert para la tabla PRODUCTO
INSERT INTO Producto (nombre_producto, descripcion, precio_producto, disponibilidad, costo_producto, codigo_categoria) VALUES
('1 Pollo a la Brasa entero', 'Con papas familiares y ensalada grande', 55.00, 'Disponible', 22.50, 1),
('1/2 Pollo a la Brasa', 'Con papas y ensalada mediana', 28.00, 'Disponible', 12.00, 1),
('1/4 Pollo a la Brasa', 'Pierna o pechuga, con papas y ensalada personal', 16.00, 'Disponible', 6.80, 1),
('Aguadito de Pollo', 'La clásica sopa espesa de cortes de pollo a la brasa con arroz, culantro y arvejas, servida tradicionalmente como cortesía o entrada', 8.00, 'Disponible', 2.20, 2),
('Sopa Wantán Simple', 'Caldo claro de pollo con col china y wantanes rellenos de pollo', 10.00, 'Disponible', 2.80, 2),
('Sopa Wantán Especial', 'Caldo con wantanes, fideos chinos, cortes de pollo, chancho asado y huevos de codorniz', 18.00, 'Disponible', 6.20, 2),
('Sopa Fu Chi Fu', 'Sopa espesa con huevo hilado, pollo picado y verduras finas', 12.00, 'Disponible', 3.50, 2),
('Porción de Wantán Frito', '12 unidades crujientes acompañadas de un bowl de salsa de tamarindo dulce', 9.00, 'Disponible', 2.00, 2),
('Arroz Chaufa de Pollo', 'La base del chifa peruano salteada al wok con cebolla china, tortilla de huevo y sillao', 11.00, 'Disponible', 3.20, 3),
('Arroz Chaufa de Carne de Res', 'La base del chifa peruano salteada al wok con cebolla china, tortilla de huevo y sillao', 13.00, 'Disponible', 4.50, 3),
('Arroz Chaufa de Chancho Asado (Char siu)', 'La base del chifa peruano salteada al wok con cebolla china, tortilla de huevo y sillao', 14.00, 'Disponible', 4.80, 3),
('Arroz Chaufa Especial', 'Fusión de tres proteínas: pollo, chancho asado y langostinos', 20.00, 'Disponible', 7.50, 3),
('Arroz Chaufa Amazónico', 'Variante popular con cecina y plátano maduro en cubos', 18.00, 'Disponible', 6.80, 3),
('Aeropuerto de Pollo', 'Arroz chaufa y tallarín saltado chino mezclados al wok con frijolito de soya', 14.00, 'Disponible', 4.20, 4),
('Aeropuerto de Carne', 'La versión con tiras de res y frijolito chino', 16.00, 'Disponible', 5.30, 4),
('Aeropuerto Especial', 'Pollo, chancho asado, langostinos, fideo y arroz salteados juntos', 22.00, 'Disponible', 8.00, 4),
('Mostro (1/4 Pollo + Chaufa)', 'La fusión estrella: un cuarto de pollo a la brasa servido sobre una montaña de arroz chaufa de pollo, acompañado de papas fritas', 17.50, 'Disponible', 8.20, 4),
('Mostrito (1/4 Pollo + Aeropuerto)', 'Un cuarto de pollo a la brasa montado sobre un contundente plato de aeropuerto', 19.50, 'Disponible', 9.10, 4),
('Pollo Chijaukay', 'Muslo de pollo deshuesado, empanizado, frito y bañado en salsa de ostión salada', 16.00, 'Disponible', 5.50, 5),
('Pollo Tipakay', 'Pechuga de pollo empanizada, frita y bañada en salsa de tamarindo dulce y piña', 16.00, 'Disponible', 5.30, 5),
('Pollo Enrollado con Verduras', 'Láminas de pollo rellenas salteadas con brócoli, col china y salsa de ostión', 18.00, 'Disponible', 6.40, 5),
('Kamlu Wantán', 'Wantanes fritos cubiertos con un salteado agridulce de pollo, chancho, langostinos, piña y pimentón', 22.00, 'Disponible', 8.50, 5),
('Tallarín Saltado de Pollo al Wok', 'Estilo chifa, jugoso, con col china y cebolla', 13.00, 'Disponible', 4.30, 5),
('Tallarín Saltado de Carne (Res)', 'Tiras de res salteadas con fideo chino, pimentón y verduras', 15.00, 'Disponible', 5.50, 5),
('Chancho con Piña', 'Cortes de chancho asado salteados en salsa de tamarindo con trozos de piña fresca y nabo', 17.00, 'Disponible', 5.80, 5),
('Chancho al Ajo', 'Láminas de chancho crujientes salteadas en una intensa salsa de ajo y sillao', 17.00, 'Disponible', 5.90, 5),
('Lomo Saltado Chifero', 'Cortes de res al wok con cebolla, tomate, sillao y vinagre, acompañado de arroz blanco y papas fritas', 16.00, 'Disponible', 6.00, 5),
('Pollo a la Plancha', 'Filete de pechuga sazonado, servido con papas fritas y ensalada', 15.00, 'Disponible', 5.20, 6),
('Bistec a lo Pobre', 'Corte de res a la plancha acompañado de papas fritas, arroz, plátano frito y huevo frito', 19.00, 'Disponible', 7.80, 6),
('Porción de Anticuchos de Corazón', 'Dos palos de corazón de res marinados en ají panca, acompañados de papa sancochada y choclo', 15.00, 'Disponible', 5.50, 6),
('Chuleta de Chancho a la Parrilla', 'Chuleta de cerdo marinada al estilo criollo, servida con papas y ensalada', 16.00, 'Disponible', 5.80, 6),
('Parrilla Mixta', 'Combinación de 1/4 pollo a la brasa, una chuleta de chancho, un palo de anticucho y chorizo', 28.00, 'Disponible', 11.50, 6),
('Porción de Papas Fritas Familiares', 'Corte grueso, listas para las cremas', 10.00, 'Disponible', 3.50, 7),
('Porción de Arroz Chaufa Familiar', 'Para acompañar el pollo entero solo', 10.00, 'Disponible', 2.80, 7),
('Nabo Encurtido', 'Porción del clásico nabo agridulce chifero', 3.00, 'Disponible', 0.60, 7),
('Porción de Alitas Broaster', 'Crujientes, acompañadas de papas fritas', 14.00, 'Disponible', 5.20, 7),
('Inca Kola de 1.5 Litros / 2 Litros', 'La bebida por excelencia para acompañar el chifa y el pollo', 9.00, 'Disponible', 6.20, 8),
('Coca-Cola de 1.5 Litros / 2 Litros', 'Bebida gaseosa para acompañar', 9.00, 'Disponible', 6.20, 8),
('Jarra de Chicha Morada Natural', 'De 1 Litro, preparada en casa con maíz morado, piña y limón', 10.00, 'Disponible', 2.50, 8),
('Gaseosa Personal (Inca Kola / Coca-Cola)', 'Formato de vidrio o plástico individual', 3.50, 'Disponible', 1.80, 8);

SELECT
    MIN(codigo_cliente) AS ClienteMinimo,
    MAX(codigo_cliente) AS ClienteMaximo,
    COUNT(*) AS TotalClientes
FROM Cliente;

--Insert para la tabla DIRECCION
INSERT INTO Direccion (codigo_cliente, codigo_distrito, tipo_direccion, direccion) VALUES
(1, 1, 'Departamento', 'Av. Alfredo Mendiola 3698, Urb. Industrial Panamericana, Independencia 15311'),
(2, 1, 'Trabajo', 'Av. Carlos Izaguirre 271, Urb. Panamericana Norte, Independencia 15311'),
(3, 1, 'Casa Familiar', 'Av. Gerardo Unger 3935, Urb. Industrial Panamericana, Independencia 15311'),
(4, 1, 'Domicilio', 'Calle Industrial 210, Urb. Las Violetas, Independencia 15312'),
(5, 1, 'Trabajo', 'Av. Túpac Amaru 1402, Urb. Tahuantinsuyo, Independencia 15331'),
(7, 1, 'Departamento', 'Jr. Sinchi Roca 3468, Urb. El Ermitaño, Independencia 15311'),
(9, 3, 'Casa Familiar', 'Av. Perú 2245, Urb. Peru, San Martín de Porres 15103'),
(10, 3, 'Domicilio', 'Av. Tomás Valle 850, Urb. Angélica Gamarra, San Martín de Porres 15102'),
(11, 3, 'Trabajo', 'Av. Los Dominicos Mz. U Lote 1, Urb. Los Cipreses, San Martín de Porres 15112'),
(12, 3, 'Departamento', 'Av. Eduardo de Habich 345, Urb. Ingeniería, San Martín de Porres 15102'),
(17, 3, 'Casa Familiar', 'Jr. Nicaragua 196, Urb. Mesa Redonda, San Martín de Porres 15102'),
(18, 3, 'Domicilio', 'Av. Honorio Delgado 260, Urb. Ingeniería, San Martín de Porres 15102'),
(27, 5, 'Trabajo', 'Av. Túpac Amaru 1611, Urb. Huaquillay, Comas 15312'),
(27, 5, 'Departamento', 'Av. Los Ángeles 602, Urb. El Retablo, Comas 15314'),
(28, 5, 'Casa Familiar', 'Av. Víctor Andrés Belaúnde 570, Urb. El Retablo, Comas 15312'),
(28, 5, 'Domicilio', 'Av. Guillermo de la Fuente 280, Urb. Santa Luzmila, Comas 15314'),
(29, 5, 'Trabajo', 'Av. Universitaria 6340, Urb. Retablo 4ta Etapa, Comas 15314'),
(29, 6, 'Casa Familiar', 'Av. Las Vegas Mz. B Lote 4, Urb. Industrial Shangri-La, Puente Piedra 15121'),
(32, 6, 'Departamento', 'Calle Los Pinos S/N, Urb. Santa Martha, Puente Piedra 15116'),
(32, 6, 'Domicilio', 'Asoc. Los Álamos Mz. I Lote 8, Puente Piedra 15116'),
(33, 6, 'Trabajo', 'Av. Buenos Aires 415, Urb. Cercado Puente Piedra, Puente Piedra 15118'),
(33, 6, 'Casa Familiar', 'Av. Juan Lecaros 210, Urb. Casuarinas, Puente Piedra 15118'),
(34, 7, 'Departamento', 'Av. Samuel Alcázar 620, Urb. Las Calezas, Rímac 15093'),
(34, 7, 'Domicilio', 'Av. Felipe Arancibia 455, Urb. El Manzano, Rímac 15094'),
(36, 7, 'Trabajo', 'Av. Prolongación Tacna 115, Rímac 15093'),
(36, 7, 'Casa Familiar', 'Av. Caquetá 800, Urb. Trébol de Caquetá, Rímac 15094'),
(37, 10, 'Departamento', 'Av. Inca Garcilaso de la Vega 1160, Oficina 402, Lima 15001'),
(37, 10, 'Domicilio', 'Jr. Ocoña 160, Cercado de Lima 15001'),
(39, 10, 'Trabajo', 'Av. Abancay 450, Cercado de Lima 15001'),
(39, 10, 'Casa Familiar', 'Av. Alfonso Ugarte 980, Cercado de Lima 15001'),
(40, 10, 'Departamento', 'Jr. Carabaya 532, Cercado de Lima 15001'),
(40, 11, 'Domicilio', 'Av. Argentina 5138, Zona Industrial, Callao 07006'),
(42, 11, 'Trabajo', 'Av. Elmer Faucett 4766, Urb. Bocanegra, Callao 07031'),
(42, 11, 'Casa Familiar', 'Av. Sáenz Peña 450, Callao 07001'),
(46, 11, 'Departamento', 'Av. Néstor Gambetta Km. 6.5, Zona Industrial, Callao 07041'),
(46, 11, 'Domicilio', 'Av. Enrique Meiggs 2315, Zona Industrial, Callao 07001');



--Insert para la tabla PEDIDO
INSERT INTO Pedido (codigo_cliente, codigo_tipopedido, codigo_tipoestado, codigo_direccion, codigo_mesa, fecha_pedido, total_pagar) VALUES
(1, 2, 11, 1, 17, '2026-07-12 18:45:10', 99.00),
(2, 2, 11, 2, 17, '2026-07-15 19:10:00', 56.00),
(3, 2, 11, 3, 17, '2026-07-18 20:15:30', 145.00),
(4, 2, 11, 4, 17, '2026-07-20 18:05:00', 60.00),
(5, 2, 11, 5, 17, '2026-07-22 13:30:00', 170.00),
(6, 1, 5, null, 1, '2026-07-25 19:40:22', 71.00),
(7, 2, 11, 6, 17, '2026-07-28 20:00:15', 216.00),
(8, 1, 5, null, 2, '2026-07-30 18:15:45', 109.00),
(9, 2, 11, 7, 17, '2026-08-01 19:25:00', 93.00),
(10, 2, 11, 8, 17, '2026-08-02 20:20:10', 137.00),
(11, 2, 11, 9, 17, '2026-08-03 14:15:00', 170.50),
(12, 2, 11, 10, 17, '2026-08-05 18:50:30', 169.00),
(13, 1, 5, null, 3, '2026-08-06 19:05:00', 150.00),
(14, 1, 5, null, 4, '2026-08-08 20:10:00', 34.00),
(15, 1, 5, null, 5, '2026-08-09 18:35:20', 173.00),
(16, 1, 5, null, 6, '2026-08-11 19:15:00', 103.00),
(17, 2, 11, 11, 17, '2026-08-12 21:40:00', 118.00),
(18, 2, 11, 12, 17, '2026-08-14 18:20:10', 188.00),
(19, 1, 5, null, 7, '2026-08-15 19:55:00', 143.00),
(20, 1, 5, null, 8, '2026-08-17 20:05:40', 81.00),
(21, 1, 5, null, 9, '2026-08-18 18:10:00', 274.00),
(22, 1, 5, null, 10, '2026-08-20 12:45:00', 195.50),
(23, 1, 5, null, 11, '2026-08-21 19:30:15', 66.00),
(24, 1, 5, null, 12, '2026-08-22 18:40:00', 179.00),
(25, 1, 5, null, 13, '2026-08-24 20:15:00', 77.00),
(26, 1, 5, null, 14, '2026-08-25 19:00:50', 130.00),
(27, 2, 11, 13, 17, '2026-08-26 18:25:00', 190.00),
(28, 2, 11, 16, 17, '2026-08-27 15:20:00', 84.00),
(29, 2, 11, 17, 17, '2026-08-28 20:25:30', 139.00),
(30, 1, 5, null, 15, '2026-08-29 18:55:00', 301.00),
(31, 1, 5, null, 1, '2026-08-30 19:10:40', 113.50),
(32, 2, 11, 19, 17, '2026-08-31 18:05:00', 126.00),
(33, 2, 11, 21, 17, '2026-09-01 20:10:00', 156.00),
(34, 2, 11, 23, 17, '2026-09-02 22:15:00', 167.50),
(35, 3, 16, null, 16, '2026-09-03 19:20:10', 92.00),
(36, 2, 11, 25, 17, '2026-09-04 18:45:00', 130.00),
(37, 2, 11, 27, 17, '2026-09-05 19:35:00', 177.00),
(38, 1, 5, null, 2, '2026-09-06 20:00:00', 75.00),
(39, 2, 11, 29, 17, '2026-09-07 18:15:25', 314.00),
(40, 2, 11, 31, 17, '2026-09-08 19:50:00', 141.00),
(41, 1, 5, null, 3, '2026-09-09 13:10:00', 74.00),
(42, 2, 11, 33, 17, '2026-09-10 18:30:00', 236.00),
(43, 1, 5, null, 4, '2026-09-11 20:10:15', 77.50),
(44, 1, 5, null, 5, '2026-09-12 19:05:00', 122.00),
(45, 1, 5, null, 6, '2026-09-13 18:40:00', 163.00),
(46, 2, 11, 35, 17, '2026-09-14 17:30:00', 107.00),
(47, 1, 5, null, 7, '2026-09-14 19:45:30', 178.00),
(48, 1, 5, null, 8, '2026-09-15 18:20:00', 256.50),
(49, 1, 5, null, 9, '2026-09-15 20:25:00', 81.00),
(50, 3, 16, null, 16, '2026-09-16 19:15:00', 160.50),
(1, 2, 11, 1, 17, '2026-09-16 18:50:00', 104.00),
(2, 2, 11, 2, 17, '2026-09-17 20:05:10', 115.00),
(3, 2, 11, 3, 17, '2026-09-17 19:30:00', 153.50),
(4, 2, 11, 4, 17, '2026-09-18 16:45:00', 98.00),
(5, 2, 11, 5, 17, '2026-09-18 18:10:00', 128.00),
(6, 1, 5, null, 10, '2026-09-18 19:40:00', 94.00),
(7, 2, 11, 6, 17, '2026-09-19 20:15:20', 227.00),
(8, 1, 5, null, 11, '2026-09-19 18:25:00', 87.00),
(9, 2, 11, 7, 17, '2026-09-19 19:10:00', 118.50),
(10, 2, 11, 8, 17, '2026-09-20 18:05:30', 28.00),
(13, 1, 5, null, 12, '2026-09-20 19:50:00', 126.00),
(14, 1, 5, null, 13, '2026-09-20 20:20:00', 118.00),
(15, 1, 5, null, 14, '2026-09-20 18:35:00', 150.00),
(16, 1, 5, null, 15, '2026-09-20 19:00:45', 128.00),
(19, 1, 5, null, 1, '2026-09-20 21:10:00', 116.00),
(20, 1, 5, null, 2, '2026-09-20 18:15:00', 88.00),
(21, 1, 5, null, 3, '2026-09-20 19:25:00', 277.50),
(22, 1, 5, null, 4, '2026-09-20 20:10:00', 131.00),
(23, 3, 16, null, 16, '2026-09-20 18:45:00', 160.00),
(24, 1, 5, null, 5, '2026-09-20 19:35:15', 92.00);



--Insert para la tabla PARTICIPACIONPEDIDO
INSERT INTO ParticipacionPedido (codigo_pedido, codigo_empleado, tipo_participacion, estado_participacion, fecha_participacion) VALUES
(1, 10, 'Anota pedido delivery', 'Activo', '2026-07-12 18:46:10'),
(1, 3, 'Entrega pedido delivery', 'Activo', '2026-07-12 18:49:10'),
(2, 10, 'Anota pedido delivery', 'Activo', '2026-07-15 19:12:00'),
(2, 6, 'Entrega pedido delivery', 'Activo', '2026-07-15 19:14:00'),
(3, 10, 'Anota pedido delivery', 'Activo', '2026-07-18 20:16:30'),
(3, 3, 'Entrega pedido delivery', 'Activo', '2026-07-18 20:19:30'),
(4, 10, 'Anota pedido delivery', 'Activo', '2026-07-20 18:07:00'),
(4, 6, 'Entrega pedido delivery', 'Activo', '2026-07-20 18:10:00'),
(5, 10, 'Anota pedido delivery', 'Activo', '2026-07-22 13:31:00'),
(5, 3, 'Entrega pedido delivery', 'Activo', '2026-07-22 13:35:00'),
(6, 9, 'Atiende pedido presencial', 'Activo', '2026-07-25 19:42:22'),
(7, 10, 'Anota pedido delivery', 'Activo', '2026-07-28 20:02:15'),
(7, 6, 'Entrega pedido delivery', 'Activo', '2026-07-28 20:05:15'),
(8, 1, 'Atiende pedido presencial', 'Activo', '2026-07-30 18:16:45'),
(9, 10, 'Anota pedido delivery', 'Activo', '2026-08-01 19:26:00'),
(9, 3, 'Entrega pedido delivery', 'Activo', '2026-08-01 19:28:00'),
(10, 10, 'Anota pedido delivery', 'Activo', '2026-08-02 20:23:10'),
(10, 6, 'Entrega pedido delivery', 'Activo', '2026-08-02 20:25:10'),
(11, 10, 'Anota pedido delivery', 'Activo', '2026-08-03 14:16:00'),
(11, 3, 'Entrega pedido delivery', 'Activo', '2026-08-03 14:19:00'),
(12, 10, 'Anota pedido delivery', 'Activo', '2026-08-05 18:52:30'),
(12, 6, 'Entrega pedido delivery', 'Activo', '2026-08-05 18:54:30'),
(13, 11, 'Atiende pedido presencial', 'Activo', '2026-08-06 19:08:00'),
(14, 1, 'Atiende pedido presencial', 'Activo', '2026-08-08 20:11:00'),
(15, 9, 'Atiende pedido presencial', 'Activo', '2026-08-09 18:37:20'),
(16, 11, 'Atiende pedido presencial', 'Activo', '2026-08-11 19:16:00'),
(17, 10, 'Anota pedido delivery', 'Activo', '2026-08-12 21:41:00'),
(17, 3, 'Entrega pedido delivery', 'Activo', '2026-08-12 21:44:00'),
(18, 10, 'Anota pedido delivery', 'Activo', '2026-08-14 18:22:10'),
(18, 6, 'Entrega pedido delivery', 'Activo', '2026-08-14 18:25:10'),
(19, 1, 'Atiende pedido presencial', 'Activo', '2026-08-15 19:57:00'),
(20, 9, 'Atiende pedido presencial', 'Activo', '2026-08-17 20:06:40'),
(21, 11, 'Atiende pedido presencial', 'Activo', '2026-08-18 18:13:00'),
(22, 1, 'Atiende pedido presencial', 'Activo', '2026-08-20 12:46:00'),
(23, 9, 'Atiende pedido presencial', 'Activo', '2026-08-21 19:32:15'),
(24, 11, 'Atiende pedido presencial', 'Activo', '2026-08-22 18:43:00'),
(25, 1, 'Atiende pedido presencial', 'Activo', '2026-08-24 20:16:00'),
(26, 9, 'Atiende pedido presencial', 'Activo', '2026-08-25 19:02:50'),
(27, 10, 'Anota pedido delivery', 'Activo', '2026-08-26 18:26:00'),
(27, 3, 'Entrega pedido delivery', 'Activo', '2026-08-26 18:29:00'),
(28, 10, 'Anota pedido delivery', 'Activo', '2026-08-27 15:22:00'),
(28, 6, 'Entrega pedido delivery', 'Activo', '2026-08-27 15:25:00'),
(29, 10, 'Anota pedido delivery', 'Activo', '2026-08-28 20:26:30'),
(29, 3, 'Entrega pedido delivery', 'Activo', '2026-08-28 20:30:30'),
(30, 11, 'Atiende pedido presencial', 'Activo', '2026-08-29 18:57:00'),
(31, 1, 'Atiende pedido presencial', 'Activo', '2026-08-30 19:11:40'),
(32, 10, 'Anota pedido delivery', 'Activo', '2026-08-31 18:06:00'),
(32, 6, 'Entrega pedido delivery', 'Activo', '2026-08-31 18:09:00'),
(33, 10, 'Anota pedido delivery', 'Activo', '2026-09-01 20:12:00'),
(33, 3, 'Entrega pedido delivery', 'Activo', '2026-09-01 20:15:00'),
(34, 10, 'Anota pedido delivery', 'Activo', '2026-09-02 22:16:00'),
(34, 6, 'Entrega pedido delivery', 'Activo', '2026-09-02 22:19:00'),
(35, 10, 'Anota pedido delivery', 'Cancelado', '2026-09-03 19:21:10'),
(35, 3, 'Entrega pedido delivery', 'Cancelado', '2026-09-03 19:23:10'),
(35, 9, 'Atiende pedido presencial', 'Activo', '2026-09-03 19:31:10'),
(36, 10, 'Anota pedido delivery', 'Activo', '2026-09-04 18:47:00'),
(36, 6, 'Entrega pedido delivery', 'Activo', '2026-09-04 18:49:00'),
(37, 10, 'Anota pedido delivery', 'Activo', '2026-09-05 19:37:00'),
(37, 3, 'Entrega pedido delivery', 'Activo', '2026-09-05 19:40:00'),
(38, 11, 'Atiende pedido presencial', 'Activo', '2026-09-06 20:02:00'),
(39, 10, 'Anota pedido delivery', 'Activo', '2026-09-07 18:16:25'),
(39, 6, 'Entrega pedido delivery', 'Activo', '2026-09-07 18:19:25'),
(40, 10, 'Anota pedido delivery', 'Activo', '2026-09-08 19:52:00'),
(40, 3, 'Entrega pedido delivery', 'Activo', '2026-09-08 19:55:00'),
(41, 1, 'Atiende pedido presencial', 'Activo', '2026-09-09 13:11:00'),
(42, 10, 'Anota pedido delivery', 'Activo', '2026-09-10 18:31:00'),
(42, 6, 'Entrega pedido delivery', 'Activo', '2026-09-10 18:34:00'),
(43, 9, 'Atiende pedido presencial', 'Activo', '2026-09-11 20:13:15'),
(44, 11, 'Atiende pedido presencial', 'Activo', '2026-09-12 19:07:00'),
(45, 1, 'Atiende pedido presencial', 'Activo', '2026-09-13 18:42:00'),
(46, 10, 'Anota pedido delivery', 'Activo', '2026-09-14 17:31:00'),
(46, 3, 'Entrega pedido delivery', 'Activo', '2026-09-14 17:34:00'),
(47, 9, 'Atiende pedido presencial', 'Activo', '2026-09-14 19:48:30'),
(48, 11, 'Atiende pedido presencial', 'Activo', '2026-09-15 18:21:00'),
(49, 1, 'Atiende pedido presencial', 'Activo', '2026-09-15 20:28:00'),
(50, 10, 'Anota pedido delivery', 'Cancelado', '2026-09-16 19:17:00'),
(50, 6, 'Entrega pedido delivery', 'Cancelado', '2026-09-16 19:19:00'),
(50, 9, 'Atiende pedido presencial', 'Activo', '2026-09-16 19:28:00'),
(51, 10, 'Anota pedido delivery', 'Activo', '2026-09-16 18:51:00'),
(51, 3, 'Entrega pedido delivery', 'Activo', '2026-09-16 18:55:00'),
(52, 10, 'Anota pedido delivery', 'Activo', '2026-09-17 20:07:10'),
(52, 6, 'Entrega pedido delivery', 'Activo', '2026-09-17 20:10:10'),
(53, 10, 'Anota pedido delivery', 'Activo', '2026-09-17 19:32:00'),
(53, 3, 'Entrega pedido delivery', 'Activo', '2026-09-17 19:35:00'),
(54, 10, 'Anota pedido delivery', 'Activo', '2026-09-18 16:46:00'),
(54, 6, 'Entrega pedido delivery', 'Activo', '2026-09-18 16:49:00'),
(55, 10, 'Anota pedido delivery', 'Activo', '2026-09-18 18:12:00'),
(55, 3, 'Entrega pedido delivery', 'Activo', '2026-09-18 18:15:00'),
(56, 11, 'Atiende pedido presencial', 'Activo', '2026-09-18 19:41:00'),
(57, 10, 'Anota pedido delivery', 'Activo', '2026-09-19 20:17:20'),
(57, 6, 'Entrega pedido delivery', 'Activo', '2026-09-19 20:20:20'),
(58, 1, 'Atiende pedido presencial', 'Activo', '2026-09-19 18:27:00'),
(59, 10, 'Anota pedido delivery', 'Activo', '2026-09-19 19:11:00'),
(59, 3, 'Entrega pedido delivery', 'Activo', '2026-09-19 19:14:00'),
(60, 10, 'Anota pedido delivery', 'Activo', '2026-09-20 18:07:30'),
(60, 6, 'Entrega pedido delivery', 'Activo', '2026-09-20 18:10:30'),
(61, 9, 'Atiende pedido presencial', 'Activo', '2026-09-20 19:51:00'),
(62, 11, 'Atiende pedido presencial', 'Activo', '2026-09-20 20:23:00'),
(63, 1, 'Atiende pedido presencial', 'Activo', '2026-09-20 18:37:00'),
(64, 9, 'Atiende pedido presencial', 'Activo', '2026-09-20 19:01:45'),
(65, 11, 'Atiende pedido presencial', 'Activo', '2026-09-20 21:12:00'),
(66, 1, 'Atiende pedido presencial', 'Activo', '2026-09-20 18:18:00'),
(67, 9, 'Atiende pedido presencial', 'Activo', '2026-09-20 19:27:00'),
(68, 11, 'Atiende pedido presencial', 'Activo', '2026-09-20 20:11:00'),
(69, 10, 'Anota pedido delivery', 'Cancelado', '2026-09-20 18:46:00'),
(69, 3, 'Entrega pedido delivery', 'Cancelado', '2026-09-20 18:49:00'),
(69, 1, 'Atiende pedido presencial', 'Activo', '2026-09-20 18:57:00'),
(70, 9, 'Atiende pedido presencial', 'Activo', '2026-09-20 19:37:15');



--Insert para la tabla DETALLEPEDIDO
INSERT INTO DetallePedido (codigo_pedido, codigo_producto, cantidad, precio_unitario) VALUES
(1, 14, 2, 14.00),
(1, 3, 1, 16.00),
(1, 28, 3, 15.00),
(1, 39, 1, 10.00),
(2, 7, 1, 12.00),
(2, 22, 2, 22.00),
(3, 11, 4, 14.00),
(3, 35, 1, 3.00),
(3, 2, 2, 28.00),
(3, 18, 1, 19.50),
(3, 40, 3, 3.50),
(4, 9, 2, 11.00),
(4, 31, 1, 16.00),
(4, 16, 1, 22.00),
(5, 5, 3, 10.00),
(5, 27, 2, 16.00),
(5, 12, 1, 20.00),
(5, 38, 4, 9.00),
(5, 1, 1, 55.00),
(5, 20, 2, 16.00),
(6, 33, 1, 10.00),
(6, 8, 3, 9.00),
(6, 25, 2, 17.00),
(7, 17, 4, 17.50),
(7, 4, 1, 8.00),
(7, 29, 2, 19.00),
(7, 13, 1, 18.00),
(7, 36, 3, 14.00),
(7, 21, 1, 18.00),
(7, 10, 2, 13.00),
(8, 6, 2, 18.00),
(8, 34, 1, 10.00),
(8, 19, 3, 16.00),
(8, 30, 1, 15.00),
(9, 15, 2, 16.00),
(9, 37, 1, 9.00),
(9, 23, 4, 13.00),
(10, 2, 1, 28.00),
(10, 26, 3, 17.00),
(10, 11, 2, 14.00),
(10, 39, 1, 10.00),
(10, 5, 2, 10.00),
(11, 18, 3, 19.50),
(11, 32, 1, 28.00),
(11, 7, 2, 12.00),
(11, 24, 4, 15.00),
(12, 1, 2, 55.00),
(12, 14, 1, 14.00),
(12, 28, 3, 15.00),
(13, 9, 1, 11.00),
(13, 40, 2, 3.50),
(13, 16, 1, 22.00),
(13, 22, 3, 22.00),
(13, 3, 1, 16.00),
(13, 33, 4, 10.00),
(14, 8, 2, 9.00),
(14, 27, 1, 16.00),
(15, 12, 3, 20.00),
(15, 35, 1, 3.00),
(15, 20, 2, 16.00),
(15, 6, 1, 18.00),
(15, 30, 4, 15.00),
(16, 17, 2, 17.50),
(16, 4, 1, 8.00),
(16, 25, 3, 17.00),
(16, 38, 1, 9.00),
(17, 13, 2, 18.00),
(17, 31, 4, 16.00),
(17, 21, 1, 18.00),
(18, 10, 3, 13.00),
(18, 29, 1, 19.00),
(18, 15, 2, 16.00),
(18, 36, 1, 14.00),
(18, 2, 3, 28.00),
(19, 23, 1, 13.00),
(19, 37, 2, 9.00),
(19, 7, 4, 12.00),
(19, 19, 1, 16.00),
(19, 34, 3, 10.00),
(19, 11, 2, 14.00),
(20, 26, 1, 17.00),
(20, 5, 3, 10.00),
(20, 39, 2, 10.00),
(20, 14, 1, 14.00),
(21, 1, 4, 55.00),
(21, 28, 1, 15.00),
(21, 18, 2, 19.50),
(22, 32, 3, 28.00),
(22, 9, 1, 11.00),
(22, 24, 2, 15.00),
(22, 40, 1, 3.50),
(22, 16, 3, 22.00),
(23, 3, 2, 16.00),
(23, 22, 1, 22.00),
(23, 35, 4, 3.00),
(24, 8, 1, 9.00),
(24, 27, 3, 16.00),
(24, 12, 2, 20.00),
(24, 33, 1, 10.00),
(24, 20, 2, 16.00),
(24, 6, 4, 18.00),
(25, 30, 1, 15.00),
(25, 17, 2, 17.50),
(25, 38, 3, 9.00),
(26, 4, 1, 8.00),
(26, 25, 2, 17.00),
(26, 13, 4, 18.00),
(26, 31, 1, 16.00),
(27, 21, 3, 18.00),
(27, 36, 1, 14.00),
(27, 10, 2, 13.00),
(27, 29, 1, 19.00),
(27, 15, 3, 16.00),
(27, 37, 2, 9.00),
(27, 2, 1, 28.00),
(28, 23, 4, 13.00),
(28, 7, 1, 12.00),
(28, 34, 2, 10.00),
(29, 19, 3, 16.00),
(29, 11, 1, 14.00),
(29, 39, 2, 10.00),
(29, 26, 1, 17.00),
(29, 5, 4, 10.00),
(30, 18, 2, 19.50),
(30, 32, 1, 28.00),
(30, 1, 3, 55.00),
(30, 28, 2, 15.00),
(30, 14, 1, 14.00),
(30, 24, 3, 15.00),
(31, 9, 2, 11.00),
(31, 40, 1, 3.50),
(31, 16, 4, 22.00),
(32, 3, 1, 16.00),
(32, 22, 3, 22.00),
(32, 35, 2, 3.00),
(32, 8, 1, 9.00),
(32, 27, 2, 16.00),
(33, 12, 4, 20.00),
(33, 33, 1, 10.00),
(33, 20, 3, 16.00),
(33, 6, 1, 18.00),
(34, 30, 2, 15.00),
(34, 17, 1, 17.50),
(34, 38, 3, 9.00),
(34, 4, 2, 8.00),
(34, 25, 1, 17.00),
(34, 13, 4, 18.00),
(35, 31, 2, 16.00),
(35, 21, 1, 18.00),
(35, 36, 3, 14.00),
(36, 10, 1, 13.00),
(36, 29, 4, 19.00),
(36, 15, 2, 16.00),
(36, 37, 1, 9.00),
(37, 2, 3, 28.00),
(37, 23, 1, 13.00),
(37, 7, 2, 12.00),
(37, 34, 4, 10.00),
(37, 19, 1, 16.00),
(38, 11, 2, 14.00),
(38, 39, 3, 10.00),
(38, 26, 1, 17.00),
(39, 5, 2, 10.00),
(39, 18, 4, 19.50),
(39, 32, 1, 28.00),
(39, 1, 3, 55.00),
(39, 28, 1, 15.00),
(39, 14, 2, 14.00),
(40, 24, 1, 15.00),
(40, 9, 3, 11.00),
(40, 40, 2, 3.50),
(40, 16, 1, 22.00),
(40, 3, 4, 16.00),
(41, 22, 2, 22.00),
(41, 35, 1, 3.00),
(41, 8, 3, 9.00),
(42, 27, 1, 16.00),
(42, 12, 2, 20.00),
(42, 33, 4, 10.00),
(42, 20, 1, 16.00),
(42, 6, 3, 18.00),
(42, 30, 2, 15.00),
(43, 17, 1, 17.50),
(43, 38, 3, 9.00),
(43, 4, 2, 8.00),
(43, 25, 1, 17.00),
(44, 13, 4, 18.00),
(44, 31, 2, 16.00),
(44, 21, 1, 18.00),
(45, 36, 3, 14.00),
(45, 10, 1, 13.00),
(45, 29, 2, 19.00),
(45, 15, 4, 16.00),
(45, 37, 1, 9.00),
(46, 2, 2, 28.00),
(46, 23, 3, 13.00),
(46, 7, 1, 12.00),
(47, 34, 2, 10.00),
(47, 19, 4, 16.00),
(47, 11, 1, 14.00),
(47, 39, 3, 10.00),
(47, 26, 2, 17.00),
(47, 5, 1, 10.00),
(48, 18, 3, 19.50),
(48, 32, 1, 28.00),
(48, 1, 2, 55.00),
(48, 28, 4, 15.00),
(49, 14, 1, 14.00),
(49, 24, 3, 15.00),
(49, 9, 2, 11.00),
(50, 40, 1, 3.50),
(50, 16, 4, 22.00),
(50, 3, 2, 16.00),
(50, 22, 1, 22.00),
(50, 35, 3, 3.00),
(51, 8, 2, 9.00),
(51, 27, 1, 16.00),
(51, 12, 3, 20.00),
(51, 33, 1, 10.00),
(52, 20, 4, 16.00),
(52, 6, 2, 18.00),
(52, 30, 1, 15.00),
(53, 17, 3, 17.50),
(53, 38, 1, 9.00),
(53, 4, 2, 8.00),
(53, 25, 4, 17.00),
(53, 13, 1, 18.00),
(53, 31, 2, 16.00),
(54, 21, 3, 18.00),
(54, 36, 1, 14.00),
(54, 10, 2, 13.00),
(55, 29, 4, 19.00),
(55, 15, 1, 16.00),
(55, 37, 3, 9.00),
(55, 2, 2, 28.00),
(55, 23, 1, 13.00),
(56, 7, 3, 12.00),
(56, 34, 1, 10.00),
(56, 19, 2, 16.00),
(56, 11, 4, 14.00),
(57, 39, 1, 10.00),
(57, 26, 3, 17.00),
(57, 5, 2, 10.00),
(57, 18, 1, 19.50),
(57, 32, 4, 28.00),
(57, 1, 2, 55.00),
(58, 28, 1, 15.00),
(58, 14, 3, 14.00),
(58, 24, 2, 15.00),
(59, 9, 4, 11.00),
(59, 40, 1, 3.50),
(59, 16, 2, 22.00),
(59, 3, 3, 16.00),
(59, 22, 1, 22.00),
(60, 35, 2, 3.00),
(60, 8, 4, 9.00),
(60, 27, 1, 16.00),
(61, 12, 3, 20.00),
(61, 33, 1, 10.00),
(61, 20, 2, 16.00),
(61, 6, 4, 18.00),
(61, 30, 1, 15.00),
(62, 17, 2, 17.50),
(62, 38, 3, 9.00),
(62, 4, 1, 8.00),
(63, 25, 4, 17.00),
(63, 13, 2, 18.00),
(63, 31, 1, 16.00),
(63, 21, 3, 18.00),
(64, 36, 2, 14.00),
(64, 10, 1, 13.00),
(64, 29, 4, 19.00),
(64, 15, 3, 16.00),
(64, 37, 1, 9.00),
(64, 2, 2, 28.00),
(65, 23, 3, 13.00),
(65, 7, 1, 12.00),
(65, 34, 4, 10.00),
(66, 19, 2, 16.00),
(66, 11, 1, 14.00),
(66, 39, 3, 10.00),
(67, 26, 1, 17.00),
(67, 5, 4, 10.00),
(67, 18, 2, 19.50),
(67, 32, 1, 28.00),
(67, 1, 3, 55.00),
(68, 28, 2, 15.00),
(68, 14, 4, 14.00),
(68, 24, 1, 15.00),
(68, 9, 3, 11.00),
(69, 40, 2, 3.50),
(69, 16, 1, 22.00),
(69, 3, 4, 16.00),
(69, 22, 2, 22.00),
(69, 35, 1, 3.00),
(69, 8, 3, 9.00),
(70, 27, 2, 16.00),
(70, 12, 1, 20.00),
(70, 33, 4, 10.00),
(70, 20, 2, 16.00);



--Insert para la tabla COMPROBANTE
INSERT INTO Comprobante (codigo_pedido, tipo_comprobante, numero_comprobante, fecha_emision, subtotal, IGV) VALUES
(1, 'Factura', 'F001-000001', '2026-07-12 19:32:10', 83.90, 15.10),
(2, 'Boleta', 'B001-000001', '2026-07-15 19:58:20', 47.46, 8.54),
(3, 'Boleta', 'B001-000002', '2026-07-18 21:03:15', 122.88, 22.12),
(4, 'Factura', 'F001-000002', '2026-07-20 18:52:40', 50.85, 9.15),
(5, 'Boleta', 'B001-000003', '2026-07-22 14:18:05', 144.07, 25.93),
(6, 'Factura', 'F001-000003', '2026-07-25 20:13:50', 60.17, 10.83),
(7, 'Factura', 'F001-000004', '2026-07-28 20:48:30', 183.05, 32.95),
(8, 'Boleta', 'B001-000004', '2026-07-30 19:18:15', 92.37, 16.63),
(9, 'Boleta', 'B001-000005', '2026-08-01 19:57:25', 78.81, 14.19),
(10, 'Factura', 'F001-000005', '2026-08-02 21:08:40', 116.10, 20.90),
(11, 'Boleta', 'B001-000006', '2026-08-03 15:03:10', 144.49, 26.01),
(12, 'Factura', 'F001-000006', '2026-08-05 19:38:00', 143.22, 25.78),
(13, 'Boleta', 'B001-000007', '2026-08-06 19:53:45', 127.12, 22.88),
(14, 'Factura', 'F001-000007', '2026-08-08 20:42:15', 28.81, 5.19),
(15, 'Boleta', 'B001-000008', '2026-08-09 19:24:30', 146.61, 26.39),
(16, 'Boleta', 'B001-000009', '2026-08-11 20:17:50', 87.29, 15.71),
(17, 'Factura', 'F001-000008', '2026-08-12 22:28:10', 100.00, 18.00),
(18, 'Boleta', 'B001-000010', '2026-08-14 19:08:25', 159.32, 28.68),
(19, 'Factura', 'F001-000009', '2026-08-15 20:43:00', 121.19, 21.81),
(20, 'Boleta', 'B001-000011', '2026-08-17 20:38:15', 68.64, 12.36),
(21, 'Boleta', 'B001-000012', '2026-08-18 19:12:40', 232.20, 41.80),
(22, 'Factura', 'F001-000010', '2026-08-20 13:34:10', 165.68, 29.82),
(23, 'Boleta', 'B001-000013', '2026-08-21 20:03:50', 55.93, 10.07),
(24, 'Factura', 'F001-000011', '2026-08-22 19:28:00', 151.69, 27.31),
(25, 'Boleta', 'B001-000014', '2026-08-24 21:02:15', 65.25, 11.75),
(26, 'Factura', 'F001-000012', '2026-08-25 19:48:30', 110.17, 19.83),
(27, 'Factura', 'F001-000013', '2026-08-26 19:13:20', 161.02, 28.98),
(28, 'Boleta', 'B001-000015', '2026-08-27 16:08:45', 71.19, 12.81),
(29, 'Boleta', 'B001-000016', '2026-08-28 21:13:10', 117.80, 21.20),
(30, 'Factura', 'F001-000014', '2026-08-29 19:43:00', 255.08, 45.92),
(31, 'Boleta', 'B001-000017', '2026-08-30 20:14:20', 96.19, 17.31),
(32, 'Factura', 'F001-000015', '2026-08-31 18:37:50', 106.78, 19.22),
(33, 'Boleta', 'B001-000018', '2026-09-01 20:58:10', 132.20, 23.80),
(34, 'Factura', 'F001-000016', '2026-09-02 23:04:30', 141.95, 25.55),
(35, 'Boleta', 'B001-000019', '2026-09-03 20:07:45', 77.97, 14.03),
(36, 'Factura', 'F001-000017', '2026-09-04 19:33:15', 110.17, 19.83),
(37, 'Boleta', 'B001-000020', '2026-09-05 20:23:00', 150.00, 27.00),
(38, 'Factura', 'F001-000018', '2026-09-06 20:48:25', 63.56, 11.44),
(39, 'Boleta', 'B001-000021', '2026-09-07 19:03:50', 266.10, 47.90),
(40, 'Factura', 'F001-000019', '2026-09-08 20:37:10', 119.49, 21.51),
(41, 'Boleta', 'B001-000022', '2026-09-09 13:58:00', 62.71, 11.29),
(42, 'Factura', 'F001-000020', '2026-09-10 19:32:45', 200.00, 36.00),
(43, 'Boleta', 'B001-000023', '2026-09-11 20:43:30', 65.68, 11.82),
(44, 'Factura', 'F001-000021', '2026-09-12 20:08:10', 103.39, 18.61),
(45, 'Boleta', 'B001-000024', '2026-09-13 19:29:15', 138.14, 24.86),
(46, 'Boleta', 'B001-000025', '2026-09-14 18:18:40', 90.68, 16.32),
(47, 'Factura', 'F001-000022', '2026-09-14 20:33:10', 150.85, 27.15),
(48, 'Boleta', 'B001-000026', '2026-09-15 19:09:25', 217.37, 39.13),
(49, 'Factura', 'F001-000023', '2026-09-15 21:13:00', 68.64, 12.36),
(50, 'Boleta', 'B001-000027', '2026-09-16 20:04:15', 136.02, 24.48),
(51, 'Factura', 'F001-000024', '2026-09-16 19:37:50', 88.14, 15.86),
(52, 'Boleta', 'B001-000028', '2026-09-17 20:53:00', 97.46, 17.54),
(53, 'Factura', 'F001-000025', '2026-09-17 20:18:45', 130.08, 23.42),
(54, 'Boleta', 'B001-000029', '2026-09-18 17:33:10', 83.05, 14.95),
(55, 'Factura', 'F001-000026', '2026-09-18 18:58:30', 108.47, 19.53),
(56, 'Boleta', 'B001-000030', '2026-09-18 20:28:15', 79.66, 14.34),
(57, 'Factura', 'F001-000027', '2026-09-19 21:04:00', 192.37, 34.63),
(58, 'Boleta', 'B001-000031', '2026-09-19 19:13:50', 73.73, 13.27),
(59, 'Factura', 'F001-000028', '2026-09-19 19:59:10', 100.42, 18.08),
(60, 'Boleta', 'B001-000032', '2026-09-20 18:53:40', 23.73, 4.27),
(61, 'Factura', 'F001-000029', '2026-09-20 20:38:15', 106.78, 19.22),
(62, 'Boleta', 'B001-000033', '2026-09-20 21:08:30', 100.00, 18.00),
(63, 'Factura', 'F001-000030', '2026-09-20 19:23:00', 127.12, 22.88),
(64, 'Boleta', 'B001-000034', '2026-09-20 19:49:15', 108.47, 19.53),
(65, 'Factura', 'F001-000031', '2026-09-20 21:58:40', 98.31, 17.69),
(66, 'Boleta', 'B001-000035', '2026-09-20 19:03:10', 74.58, 13.42),
(67, 'Factura', 'F001-000032', '2026-09-20 20:12:45', 235.17, 42.33),
(68, 'Boleta', 'B001-000036', '2026-09-20 20:58:20', 111.02, 19.98),
(69, 'Factura', 'F001-000033', '2026-09-20 19:34:00', 135.59, 24.41),
(70, 'Boleta', 'B001-000037', '2026-09-20 20:23:50', 77.97, 14.03);



--Insert para la tabla PAGO
INSERT INTO Pago (codigo_pedido, codigo_empleado,fecha_pago,monto_pago,metodo_pago) VALUES
(1, 3, '2026-07-12 19:30:10', 100.00, 'Efectivo'),
(2, 6, '2026-07-15 19:55:00', 60.00, 'Tarjeta'),
(3, 3, '2026-07-18 21:00:30', 145.00, 'Yape'),
(4, 6, '2026-07-20 18:50:00', 100.00, 'Efectivo'),
(5, 3, '2026-07-22 14:15:00', 200.00, 'Efectivo'),
(6, 4, '2026-07-25 20:10:22', 71.00, 'Tarjeta'),
(7, 6, '2026-07-28 20:45:15', 216.00, 'Yape'),
(8, 4, '2026-07-30 19:15:45', 110.00, 'Efectivo'),
(9, 3, '2026-08-01 19:55:00', 93.00, 'Tarjeta'),
(10, 6, '2026-08-02 21:05:10', 140.00, 'Efectivo'),
(11, 3, '2026-08-03 15:00:00', 170.50, 'Yape'),
(12, 6, '2026-08-05 19:35:30', 200.00, 'Efectivo'),
(13, 4, '2026-08-06 19:50:00', 150.00, 'Tarjeta'),
(14, 4, '2026-08-08 20:40:00', 50.00, 'Efectivo'),
(15, 4, '2026-08-09 19:20:20', 173.00, 'Yape'),
(16, 4, '2026-08-11 20:15:00', 110.00, 'Efectivo'),
(17, 3, '2026-08-12 22:25:00', 118.00, 'Tarjeta'),
(18, 6, '2026-08-14 19:05:10', 200.00, 'Efectivo'),
(19, 4, '2026-08-15 20:40:00', 143.00, 'Yape'),
(20, 4, '2026-08-17 20:35:40', 100.00, 'Efectivo'),
(21, 4, '2026-08-18 19:10:00', 274.00, 'Tarjeta'),
(22, 4, '2026-08-20 13:30:00', 200.00, 'Efectivo'),
(23, 4, '2026-08-21 20:00:15', 66.00, 'Yape'),
(24, 4, '2026-08-22 19:25:00', 180.00, 'Efectivo'),
(25, 4, '2026-08-24 21:00:00', 77.00, 'Tarjeta'),
(26, 4, '2026-08-25 19:45:50', 150.00, 'Efectivo'),
(27, 3, '2026-08-26 19:10:00', 190.00, 'Yape'),
(28, 6, '2026-08-27 16:05:00', 100.00, 'Efectivo'),
(29, 3, '2026-08-28 21:10:30', 139.00, 'Tarjeta'),
(30, 4, '2026-08-29 19:40:00', 350.00, 'Efectivo'),
(31, 4, '2026-08-30 20:10:40', 113.50, 'Yape'),
(32, 6, '2026-08-31 18:35:00', 130.00, 'Efectivo'),
(33, 3, '2026-09-01 20:55:00', 156.00, 'Tarjeta'),
(34, 6, '2026-09-02 23:00:00', 170.00, 'Efectivo'),
(35, 4, '2026-09-03 20:05:10', 92.00, 'Yape'),
(36, 3, '2026-09-04 19:30:00', 150.00, 'Efectivo'),
(37, 6, '2026-09-05 20:20:00', 177.00, 'Tarjeta'),
(38, 4, '2026-09-06 20:45:00', 80.00, 'Efectivo'),
(39, 3, '2026-09-07 19:00:25', 314.00, 'Yape'),
(40, 6, '2026-09-08 20:35:00', 150.00, 'Efectivo'),
(41, 4, '2026-09-09 13:55:00', 74.00, 'Tarjeta'),
(42, 3, '2026-09-10 19:30:00', 240.00, 'Efectivo'),
(43, 4, '2026-09-11 20:40:15', 77.50, 'Yape'),
(44, 4, '2026-09-12 20:05:00', 130.00, 'Efectivo'),
(45, 4, '2026-09-13 19:25:00', 163.00, 'Tarjeta'),
(46, 6, '2026-09-14 18:15:00', 110.00, 'Efectivo'),
(47, 4, '2026-09-14 20:30:30', 178.00, 'Yape'),
(48, 4, '2026-09-15 19:05:00', 260.00, 'Efectivo'),
(49, 4, '2026-09-15 21:10:00', 81.00, 'Tarjeta'),
(50, 4, '2026-09-16 20:00:00', 170.00, 'Efectivo'),
(51, 3, '2026-09-16 19:35:00', 104.00, 'Yape'),
(52, 6, '2026-09-17 20:50:10', 120.00, 'Efectivo'),
(53, 3, '2026-09-17 20:15:00', 153.50, 'Tarjeta'),
(54, 6, '2026-09-18 17:30:00', 100.00, 'Efectivo'),
(55, 3, '2026-09-18 18:55:00', 128.00, 'Yape'),
(56, 4, '2026-09-18 20:25:00', 100.00, 'Efectivo'),
(57, 6, '2026-09-19 21:00:20', 227.00, 'Tarjeta'),
(58, 4, '2026-09-19 19:10:00', 90.00, 'Efectivo'),
(59, 3, '2026-09-19 19:55:00', 118.50, 'Yape'),
(60, 6, '2026-09-20 18:50:30', 50.00, 'Efectivo'),
(61, 4, '2026-09-20 20:35:00', 126.00, 'Tarjeta'),
(62, 4, '2026-09-20 21:05:00', 120.00, 'Efectivo'),
(63, 4, '2026-09-20 19:20:00', 150.00, 'Yape'),
(64, 4, '2026-09-20 19:45:45', 130.00, 'Efectivo'),
(65, 4, '2026-09-20 21:55:00', 116.00, 'Tarjeta'),
(66, 4, '2026-09-20 19:00:00', 100.00, 'Efectivo'),
(67, 4, '2026-09-20 20:10:00', 277.50, 'Yape'),
(68, 4, '2026-09-20 20:55:00', 140.00, 'Efectivo'),
(69, 4, '2026-09-20 19:30:00', 160.00, 'Tarjeta'),
(70, 4, '2026-09-20 20:20:15', 100.00, 'Efectivo');



--Insert para la tabla COMPRAPROVEEDOR
INSERT INTO CompraProveedor (codigo_proveedor, codigo_empleado, fecha_compra, monto_total) VALUES
(1, 5, '2025-12-09 05:16:00', 479.32),
(2, 5, '2025-12-14 06:45:00', 688.20),
(3, 5, '2025-12-21 08:30:15', 698.10),
(4, 5, '2025-12-29 07:10:00', 867.48),
(5, 5, '2026-01-07 10:20:45', 356.38),
(6, 5, '2026-01-15 05:50:00', 608.28),
(7, 5, '2026-01-22 11:05:30', 362.50),
(8, 5, '2026-01-30 08:15:00', 553.33),
(9, 5, '2026-02-06 09:40:20', 945.25),
(10, 5, '2026-02-14 06:25:00', 607.10),
(11, 5, '2026-02-22 07:55:10', 772.00),
(12, 5, '2026-03-02 11:35:00', 446.65),
(13, 5, '2026-03-10 05:40:00', 884.00),
(14, 5, '2026-03-19 10:15:25', 744.74),
(15, 5, '2026-03-27 08:50:00', 617.86),
(16, 5, '2026-04-04 06:05:30', 225.10),
(17, 5, '2026-04-12 11:45:00', 478.90),
(18, 5, '2026-04-20 07:30:15', 822.65),
(19, 5, '2026-04-28 09:10:00', 612.73),
(20, 5, '2026-05-06 05:25:00', 255.55),
(2, 5, '2026-05-15 10:50:40', 870.70),
(4, 5, '2026-05-23 08:05:00', 543.24),
(7, 5, '2026-06-01 06:35:20', 464.52),
(9, 5, '2026-06-10 11:15:00', 458.84),
(11, 5, '2026-06-19 07:45:30', 808.70),
(13, 5, '2026-06-27 09:20:00', 715.75),
(15, 5, '2026-07-06 05:55:10', 318.32),
(16, 5, '2026-07-15 10:40:00', 444.70),
(18, 5, '2026-07-26 08:10:45', 854.55),
(20, 5, '2026-08-18 11:50:00', 323.65);



--Insert para la tabla DETALLECOMPRA
INSERT INTO DetalleCompra (codigo_compra, codigo_ingrediente, cantidad,precio_unitario) VALUES
(1, 1, 35, 7.50),
(1, 8, 40, 3.20),
(1, 23, 12, 0.01),
(1, 32, 14, 5.80),
(1, 45, 30, 0.25),
(2, 3, 22, 22.00),
(2, 5, 28, 1.40),
(2, 10, 30, 3.00),
(2, 31, 8, 4.50),
(2, 33, 12, 2.20),
(2, 48, 30, 0.42),
(3, 2, 25, 13.50),
(3, 18, 35, 7.00),
(3, 24, 15, 0.04),
(3, 35, 10, 11.50),
(4, 4, 30, 15.50),
(4, 7, 25, 1.20),
(4, 13, 20, 2.80),
(4, 19, 32, 4.50),
(4, 28, 14, 0.02),
(4, 36, 7, 24.00),
(4, 44, 35, 0.12),
(5, 6, 38, 2.60),
(5, 11, 24, 3.50),
(5, 20, 27, 6.00),
(5, 30, 11, 0.03),
(5, 46, 25, 0.45),
(6, 1, 28, 7.50),
(6, 9, 33, 2.50),
(6, 15, 22, 1.40),
(6, 21, 29, 3.40),
(6, 25, 10, 0.05),
(6, 32, 15, 5.80),
(6, 40, 22, 0.04),
(6, 49, 28, 3.50),
(7, 12, 21, 8.50),
(7, 17, 36, 3.20),
(7, 34, 9, 5.20),
(7, 43, 11, 2.00),
(8, 2, 30, 13.50),
(8, 14, 26, 1.30),
(8, 22, 40, 1.20),
(8, 27, 13, 0.01),
(8, 37, 8, 7.50),
(8, 47, 32, 0.20),
(9, 3, 27, 22.00),
(9, 8, 35, 3.20),
(9, 16, 20, 9.00),
(9, 26, 15, 0.05),
(9, 31, 13, 4.50),
(10, 5, 33, 1.40),
(10, 10, 25, 3.00),
(10, 18, 30, 7.00),
(10, 29, 12, 0.03),
(10, 38, 10, 26.00),
(10, 42, 28, 0.03),
(10, 48, 35, 0.42),
(11, 4, 32, 15.50),
(11, 19, 24, 4.50),
(11, 35, 14, 11.50),
(11, 45, 28, 0.25),
(12, 1, 40, 7.50),
(12, 7, 30, 1.20),
(12, 13, 26, 2.80),
(12, 23, 15, 0.01),
(12, 33, 11, 2.20),
(12, 46, 30, 0.45),
(13, 2, 28, 13.50),
(13, 11, 22, 3.50),
(13, 20, 35, 6.00),
(13, 36, 9, 24.00),
(13, 44, 25, 0.12),
(14, 6, 29, 2.60),
(14, 12, 25, 8.50),
(14, 15, 31, 1.40),
(14, 21, 40, 3.40),
(14, 24, 11, 0.04),
(14, 32, 10, 5.80),
(14, 41, 12, 9.50),
(14, 49, 30, 3.50),
(15, 3, 20, 22.00),
(15, 17, 38, 3.20),
(15, 28, 13, 0.02),
(15, 39, 7, 8.00),
(16, 8, 36, 3.20),
(16, 14, 27, 1.30),
(16, 25, 14, 0.05),
(16, 31, 15, 4.50),
(16, 40, 25, 0.04),
(16, 47, 28, 0.20),
(17, 1, 30, 7.50),
(17, 10, 29, 3.00),
(17, 18, 22, 7.00),
(17, 30, 10, 0.03),
(17, 48, 30, 0.42),
(18, 4, 26, 15.50),
(18, 9, 35, 2.50),
(18, 16, 24, 9.00),
(18, 22, 38, 1.20),
(18, 27, 15, 0.01),
(18, 34, 12, 5.20),
(18, 45, 32, 0.25),
(19, 2, 34, 13.50),
(19, 13, 28, 2.80),
(19, 29, 11, 0.03),
(19, 37, 10, 7.50),
(20, 5, 40, 1.40),
(20, 19, 31, 4.50),
(20, 26, 12, 0.05),
(20, 32, 8, 5.80),
(20, 42, 30, 0.03),
(20, 46, 27, 0.45),
(21, 3, 24, 22.00),
(21, 7, 33, 1.20),
(21, 20, 25, 6.00),
(21, 35, 13, 11.50),
(21, 44, 30, 0.12),
(22, 6, 27, 2.60),
(22, 11, 23, 3.50),
(22, 15, 36, 1.40),
(22, 23, 14, 0.01),
(22, 33, 10, 2.20),
(22, 38, 8, 26.00),
(22, 49, 32, 3.50),
(23, 1, 32, 7.50),
(23, 18, 28, 7.00),
(23, 24, 13, 0.04),
(23, 43, 14, 2.00),
(24, 8, 38, 3.20),
(24, 12, 22, 8.50),
(24, 21, 29, 3.40),
(24, 28, 11, 0.02),
(24, 31, 9, 4.50),
(24, 48, 26, 0.42),
(25, 4, 29, 15.50),
(25, 10, 34, 3.00),
(25, 17, 26, 3.20),
(25, 36, 7, 24.00),
(25, 47, 30, 0.20),
(26, 2, 37, 13.50),
(26, 9, 23, 2.50),
(26, 14, 30, 1.30),
(26, 22, 35, 1.20),
(26, 25, 12, 0.05),
(26, 34, 13, 5.20),
(26, 40, 20, 0.04),
(26, 45, 35, 0.25),
(27, 5, 31, 1.40),
(27, 16, 21, 9.00),
(27, 30, 14, 0.03),
(27, 41, 9, 9.50),
(28, 1, 26, 7.50),
(28, 7, 27, 1.20),
(28, 19, 30, 4.50),
(28, 27, 10, 0.01),
(28, 32, 12, 5.80),
(28, 46, 28, 0.45),
(29, 3, 25, 22.00),
(29, 13, 32, 2.80),
(29, 20, 22, 6.00),
(29, 29, 15, 0.03),
(29, 37, 11, 7.50),
(30, 6, 35, 2.60),
(30, 11, 26, 3.50),
(30, 15, 24, 1.40),
(30, 26, 13, 0.05),
(30, 33, 14, 2.20),
(30, 39, 8, 8.00),
(30, 48, 30, 0.42);



--Insert para la tabla HISTORIALPEDIDO
INSERT INTO HistorialEstadoPedido (codigo_pedido, codigo_tipoestado, hora_cambio) VALUES
(1, 6, '2026-07-12 18:46:10'),
(1, 7, '2026-07-12 18:55:10'),
(1, 8, '2026-07-12 18:56:10'),
(1, 9, '2026-07-12 18:58:10'),
(1, 10, '2026-07-12 19:04:10'),
(1, 11, '2026-07-12 19:30:10'),
(2, 6, '2026-07-15 19:11:00'),
(2, 7, '2026-07-15 19:20:00'),
(2, 8, '2026-07-15 19:21:00'),
(2, 9, '2026-07-15 19:23:00'),
(2, 10, '2026-07-15 19:29:00'),
(2, 11, '2026-07-15 19:55:00'),
(3, 6, '2026-07-18 20:16:30'),
(3, 7, '2026-07-18 20:25:30'),
(3, 8, '2026-07-18 20:26:30'),
(3, 9, '2026-07-18 20:28:30'),
(3, 10, '2026-07-18 20:34:30'),
(3, 11, '2026-07-18 21:00:30'),
(4, 6, '2026-07-20 18:06:00'),
(4, 7, '2026-07-20 18:15:00'),
(4, 8, '2026-07-20 18:16:00'),
(4, 9, '2026-07-20 18:18:00'),
(4, 10, '2026-07-20 18:24:00'),
(4, 11, '2026-07-20 18:50:00'),
(5, 6, '2026-07-22 13:31:00'),
(5, 7, '2026-07-22 13:40:00'),
(5, 8, '2026-07-22 13:41:00'),
(5, 9, '2026-07-22 13:43:00'),
(5, 10, '2026-07-22 13:49:00'),
(5, 11, '2026-07-22 14:15:00'),
(6, 1, '2026-07-25 19:41:22'),
(6, 2, '2026-07-25 19:50:22'),
(6, 3, '2026-07-25 19:51:22'),
(6, 4, '2026-07-25 19:52:22'),
(6, 5, '2026-07-25 20:10:22'),
(7, 6, '2026-07-28 20:01:15'),
(7, 7, '2026-07-28 20:10:15'),
(7, 8, '2026-07-28 20:11:15'),
(7, 9, '2026-07-28 20:13:15'),
(7, 10, '2026-07-28 20:19:15'),
(7, 11, '2026-07-28 20:45:15'),
(8, 1, '2026-07-30 18:16:45'),
(8, 2, '2026-07-30 18:25:45'),
(8, 3, '2026-07-30 18:26:45'),
(8, 4, '2026-07-30 18:27:45'),
(8, 5, '2026-07-30 19:15:45'),
(9, 6, '2026-08-01 19:26:00'),
(9, 7, '2026-08-01 19:35:00'),
(9, 8, '2026-08-01 19:36:00'),
(9, 9, '2026-08-01 19:38:00'),
(9, 10, '2026-08-01 19:44:00'),
(9, 11, '2026-08-01 19:55:00'),
(10, 6, '2026-08-02 20:21:10'),
(10, 7, '2026-08-02 20:30:10'),
(10, 8, '2026-08-02 20:31:10'),
(10, 9, '2026-08-02 20:33:10'),
(10, 10, '2026-08-02 20:39:10'),
(10, 11, '2026-08-02 21:05:10'),
(11, 6, '2026-08-03 14:16:00'),
(11, 7, '2026-08-03 14:25:00'),
(11, 8, '2026-08-03 14:26:00'),
(11, 9, '2026-08-03 14:28:00'),
(11, 10, '2026-08-03 14:34:00'),
(11, 11, '2026-08-03 15:00:00'),
(12, 6, '2026-08-05 18:51:30'),
(12, 7, '2026-08-05 19:00:30'),
(12, 8, '2026-08-05 19:01:30'),
(12, 9, '2026-08-05 19:03:30'),
(12, 10, '2026-08-05 19:09:30'),
(12, 11, '2026-08-05 19:35:30'),
(13, 1, '2026-08-06 19:06:00'),
(13, 2, '2026-08-06 19:15:00'),
(13, 3, '2026-08-06 19:16:00'),
(13, 4, '2026-08-06 19:17:00'),
(13, 5, '2026-08-06 19:50:00'),
(14, 1, '2026-08-08 20:11:00'),
(14, 2, '2026-08-08 20:20:00'),
(14, 3, '2026-08-08 20:21:00'),
(14, 4, '2026-08-08 20:22:00'),
(14, 5, '2026-08-08 20:40:00'),
(15, 1, '2026-08-09 18:36:20'),
(15, 2, '2026-08-09 18:45:20'),
(15, 3, '2026-08-09 18:46:20'),
(15, 4, '2026-08-09 18:47:20'),
(15, 5, '2026-08-09 19:20:20'),
(16, 1, '2026-08-11 19:16:00'),
(16, 2, '2026-08-11 19:25:00'),
(16, 3, '2026-08-11 19:26:00'),
(16, 4, '2026-08-11 19:27:00'),
(16, 5, '2026-08-11 20:15:00'),
(17, 6, '2026-08-12 21:41:00'),
(17, 7, '2026-08-12 21:50:00'),
(17, 8, '2026-08-12 21:51:00'),
(17, 9, '2026-08-12 21:53:00'),
(17, 10, '2026-08-12 21:59:00'),
(17, 11, '2026-08-12 22:25:00'),
(18, 6, '2026-08-14 18:21:10'),
(18, 7, '2026-08-14 18:30:10'),
(18, 8, '2026-08-14 18:31:10'),
(18, 9, '2026-08-14 18:33:10'),
(18, 10, '2026-08-14 18:39:10'),
(18, 11, '2026-08-14 19:05:10'),
(19, 1, '2026-08-15 19:56:00'),
(19, 2, '2026-08-15 20:05:00'),
(19, 3, '2026-08-15 20:06:00'),
(19, 4, '2026-08-15 20:07:00'),
(19, 5, '2026-08-15 20:40:00'),
(20, 1, '2026-08-17 20:06:40'),
(20, 2, '2026-08-17 20:15:40'),
(20, 3, '2026-08-17 20:16:40'),
(20, 4, '2026-08-17 20:17:40'),
(20, 5, '2026-08-17 20:35:40'),
(21, 1, '2026-08-18 18:11:00'),
(21, 2, '2026-08-18 18:20:00'),
(21, 3, '2026-08-18 18:21:00'),
(21, 4, '2026-08-18 18:22:00'),
(21, 5, '2026-08-18 19:10:00'),
(22, 1, '2026-08-20 12:46:00'),
(22, 2, '2026-08-20 12:55:00'),
(22, 3, '2026-08-20 12:56:00'),
(22, 4, '2026-08-20 12:57:00'),
(22, 5, '2026-08-20 13:30:00'),
(23, 1, '2026-08-21 19:31:15'),
(23, 2, '2026-08-21 19:40:15'),
(23, 3, '2026-08-21 19:41:15'),
(23, 4, '2026-08-21 19:42:15'),
(23, 5, '2026-08-21 20:00:15'),
(24, 1, '2026-08-22 18:41:00'),
(24, 2, '2026-08-22 18:50:00'),
(24, 3, '2026-08-22 18:51:00'),
(24, 4, '2026-08-22 18:52:00'),
(24, 5, '2026-08-22 19:25:00'),
(25, 1, '2026-08-24 20:16:00'),
(25, 2, '2026-08-24 20:25:00'),
(25, 3, '2026-08-24 20:26:00'),
(25, 4, '2026-08-24 20:27:00'),
(25, 5, '2026-08-24 21:00:00'),
(26, 1, '2026-08-25 19:01:50'),
(26, 2, '2026-08-25 19:10:50'),
(26, 3, '2026-08-25 19:11:50'),
(26, 4, '2026-08-25 19:12:50'),
(26, 5, '2026-08-25 19:45:50'),
(27, 6, '2026-08-26 18:26:00'),
(27, 7, '2026-08-26 18:35:00'),
(27, 8, '2026-08-26 18:36:00'),
(27, 9, '2026-08-26 18:38:00'),
(27, 10, '2026-08-26 18:44:00'),
(27, 11, '2026-08-26 19:10:00'),
(28, 6, '2026-08-27 15:21:00'),
(28, 7, '2026-08-27 15:30:00'),
(28, 8, '2026-08-27 15:31:00'),
(28, 9, '2026-08-27 15:33:00'),
(28, 10, '2026-08-27 15:39:00'),
(28, 11, '2026-08-27 16:05:00'),
(29, 6, '2026-08-28 20:26:30'),
(29, 7, '2026-08-28 20:35:30'),
(29, 8, '2026-08-28 20:36:30'),
(29, 9, '2026-08-28 20:38:30'),
(29, 10, '2026-08-28 20:44:30'),
(29, 11, '2026-08-28 21:10:30'),
(30, 1, '2026-08-29 18:56:00'),
(30, 2, '2026-08-29 19:05:00'),
(30, 3, '2026-08-29 19:06:00'),
(30, 4, '2026-08-29 19:07:00'),
(30, 5, '2026-08-29 19:40:00'),
(31, 1, '2026-08-30 19:11:40'),
(31, 2, '2026-08-30 19:20:40'),
(31, 3, '2026-08-30 19:21:40'),
(31, 4, '2026-08-30 19:22:40'),
(31, 5, '2026-08-30 20:10:40'),
(32, 6, '2026-08-31 18:06:00'),
(32, 7, '2026-08-31 18:15:00'),
(32, 8, '2026-08-31 18:16:00'),
(32, 9, '2026-08-31 18:18:00'),
(32, 10, '2026-08-31 18:24:00'),
(32, 11, '2026-08-31 18:35:00'),
(33, 6, '2026-09-01 20:11:00'),
(33, 7, '2026-09-01 20:20:00'),
(33, 8, '2026-09-01 20:21:00'),
(33, 9, '2026-09-01 20:23:00'),
(33, 10, '2026-09-01 20:29:00'),
(33, 11, '2026-09-01 20:55:00'),
(34, 6, '2026-09-02 22:16:00'),
(34, 7, '2026-09-02 22:25:00'),
(34, 8, '2026-09-02 22:26:00'),
(34, 9, '2026-09-02 22:28:00'),
(34, 10, '2026-09-02 22:34:00'),
(34, 11, '2026-09-02 23:00:00'),
(35, 12, '2026-09-03 19:21:10'),
(35, 13, '2026-09-03 19:30:10'),
(35, 14, '2026-09-03 19:31:10'),
(35, 15, '2026-09-03 19:32:10'),
(35, 16, '2026-09-03 20:05:10'),
(36, 6, '2026-09-04 18:46:00'),
(36, 7, '2026-09-04 18:55:00'),
(36, 8, '2026-09-04 18:56:00'),
(36, 9, '2026-09-04 18:58:00'),
(36, 10, '2026-09-04 19:04:00'),
(36, 11, '2026-09-04 19:30:00'),
(37, 6, '2026-09-05 19:36:00'),
(37, 7, '2026-09-05 19:45:00'),
(37, 8, '2026-09-05 19:46:00'),
(37, 9, '2026-09-05 19:48:00'),
(37, 10, '2026-09-05 19:54:00'),
(37, 11, '2026-09-05 20:20:00'),
(38, 1, '2026-09-06 20:01:00'),
(38, 2, '2026-09-06 20:10:00'),
(38, 3, '2026-09-06 20:11:00'),
(38, 4, '2026-09-06 20:12:00'),
(38, 5, '2026-09-06 20:45:00'),
(39, 6, '2026-09-07 18:16:25'),
(39, 7, '2026-09-07 18:25:25'),
(39, 8, '2026-09-07 18:26:25'),
(39, 9, '2026-09-07 18:28:25'),
(39, 10, '2026-09-07 18:34:25'),
(39, 11, '2026-09-07 19:00:25'),
(40, 6, '2026-09-08 19:51:00'),
(40, 7, '2026-09-08 20:00:00'),
(40, 8, '2026-09-08 20:01:00'),
(40, 9, '2026-09-08 20:03:00'),
(40, 10, '2026-09-08 20:09:00'),
(40, 11, '2026-09-08 20:35:00'),
(41, 1, '2026-09-09 13:11:00'),
(41, 2, '2026-09-09 13:20:00'),
(41, 3, '2026-09-09 13:21:00'),
(41, 4, '2026-09-09 13:22:00'),
(41, 5, '2026-09-09 13:55:00'),
(42, 6, '2026-09-10 18:31:00'),
(42, 7, '2026-09-10 18:40:00'),
(42, 8, '2026-09-10 18:41:00'),
(42, 9, '2026-09-10 18:43:00'),
(42, 10, '2026-09-10 18:49:00'),
(42, 11, '2026-09-10 19:30:00'),
(43, 1, '2026-09-11 20:11:15'),
(43, 2, '2026-09-11 20:20:15'),
(43, 3, '2026-09-11 20:21:15'),
(43, 4, '2026-09-11 20:22:15'),
(43, 5, '2026-09-11 20:40:15'),
(44, 1, '2026-09-12 19:06:00'),
(44, 2, '2026-09-12 19:15:00'),
(44, 3, '2026-09-12 19:16:00'),
(44, 4, '2026-09-12 19:17:00'),
(44, 5, '2026-09-12 20:05:00'),
(45, 1, '2026-09-13 18:41:00'),
(45, 2, '2026-09-13 18:50:00'),
(45, 3, '2026-09-13 18:51:00'),
(45, 4, '2026-09-13 18:52:00'),
(45, 5, '2026-09-13 19:25:00'),
(46, 6, '2026-09-14 17:31:00'),
(46, 7, '2026-09-14 17:40:00'),
(46, 8, '2026-09-14 17:41:00'),
(46, 9, '2026-09-14 17:43:00'),
(46, 10, '2026-09-14 17:49:00'),
(46, 11, '2026-09-14 18:15:00'),
(47, 1, '2026-09-14 19:46:30'),
(47, 2, '2026-09-14 19:55:30'),
(47, 3, '2026-09-14 19:56:30'),
(47, 4, '2026-09-14 19:57:30'),
(47, 5, '2026-09-14 20:30:30'),
(48, 1, '2026-09-15 18:21:00'),
(48, 2, '2026-09-15 18:30:00'),
(48, 3, '2026-09-15 18:31:00'),
(48, 4, '2026-09-15 18:32:00'),
(48, 5, '2026-09-15 19:05:00'),
(49, 1, '2026-09-15 20:26:00'),
(49, 2, '2026-09-15 20:35:00'),
(49, 3, '2026-09-15 20:36:00'),
(49, 4, '2026-09-15 20:37:00'),
(49, 5, '2026-09-15 21:10:00'),
(50, 12, '2026-09-16 19:16:00'),
(50, 13, '2026-09-16 19:25:00'),
(50, 14, '2026-09-16 19:26:00'),
(50, 15, '2026-09-16 19:27:00'),
(50, 16, '2026-09-16 20:00:00'),
(51, 6, '2026-09-16 18:51:00'),
(51, 7, '2026-09-16 19:00:00'),
(51, 8, '2026-09-16 19:01:00'),
(51, 9, '2026-09-16 19:03:00'),
(51, 10, '2026-09-16 19:09:00'),
(51, 11, '2026-09-16 19:35:00'),
(52, 6, '2026-09-17 20:06:10'),
(52, 7, '2026-09-17 20:15:10'),
(52, 8, '2026-09-17 20:16:10'),
(52, 9, '2026-09-17 20:18:10'),
(52, 10, '2026-09-17 20:24:10'),
(52, 11, '2026-09-17 20:50:10'),
(53, 6, '2026-09-17 19:31:00'),
(53, 7, '2026-09-17 19:40:00'),
(53, 8, '2026-09-17 19:41:00'),
(53, 9, '2026-09-17 19:43:00'),
(53, 10, '2026-09-17 19:49:00'),
(53, 11, '2026-09-17 20:15:00'),
(54, 6, '2026-09-18 16:46:00'),
(54, 7, '2026-09-18 16:55:00'),
(54, 8, '2026-09-18 16:56:00'),
(54, 9, '2026-09-18 16:58:00'),
(54, 10, '2026-09-18 17:04:00'),
(54, 11, '2026-09-18 17:30:00'),
(55, 6, '2026-09-18 18:11:00'),
(55, 7, '2026-09-18 18:20:00'),
(55, 8, '2026-09-18 18:21:00'),
(55, 9, '2026-09-18 18:23:00'),
(55, 10, '2026-09-18 18:29:00'),
(55, 11, '2026-09-18 18:55:00'),
(56, 1, '2026-09-18 19:41:00'),
(56, 2, '2026-09-18 19:50:00'),
(56, 3, '2026-09-18 19:51:00'),
(56, 4, '2026-09-18 19:52:00'),
(56, 5, '2026-09-18 20:25:00'),
(57, 6, '2026-09-19 20:16:20'),
(57, 7, '2026-09-19 20:25:20'),
(57, 8, '2026-09-19 20:26:20'),
(57, 9, '2026-09-19 20:28:20'),
(57, 10, '2026-09-19 20:34:20'),
(57, 11, '2026-09-19 21:00:20'),
(58, 1, '2026-09-19 18:26:00'),
(58, 2, '2026-09-19 18:35:00'),
(58, 3, '2026-09-19 18:36:00'),
(58, 4, '2026-09-19 18:37:00'),
(58, 5, '2026-09-19 19:10:00'),
(59, 6, '2026-09-19 19:11:00'),
(59, 7, '2026-09-19 19:20:00'),
(59, 8, '2026-09-19 19:21:00'),
(59, 9, '2026-09-19 19:23:00'),
(59, 10, '2026-09-19 19:29:00'),
(59, 11, '2026-09-19 19:55:00'),
(60, 6, '2026-09-20 18:06:30'),
(60, 7, '2026-09-20 18:15:30'),
(60, 8, '2026-09-20 18:16:30'),
(60, 9, '2026-09-20 18:18:30'),
(60, 10, '2026-09-20 18:24:30'),
(60, 11, '2026-09-20 18:50:30'),
(61, 1, '2026-09-20 19:51:00'),
(61, 2, '2026-09-20 20:00:00'),
(61, 3, '2026-09-20 20:01:00'),
(61, 4, '2026-09-20 20:02:00'),
(61, 5, '2026-09-20 20:35:00'),
(62, 1, '2026-09-20 20:21:00'),
(62, 2, '2026-09-20 20:30:00'),
(62, 3, '2026-09-20 20:31:00'),
(62, 4, '2026-09-20 20:32:00'),
(62, 5, '2026-09-20 21:05:00'),
(63, 1, '2026-09-20 18:36:00'),
(63, 2, '2026-09-20 18:45:00'),
(63, 3, '2026-09-20 18:46:00'),
(63, 4, '2026-09-20 18:47:00'),
(63, 5, '2026-09-20 19:20:00'),
(64, 1, '2026-09-20 19:01:45'),
(64, 2, '2026-09-20 19:10:45'),
(64, 3, '2026-09-20 19:11:45'),
(64, 4, '2026-09-20 19:12:45'),
(64, 5, '2026-09-20 19:45:45'),
(65, 1, '2026-09-20 21:11:00'),
(65, 2, '2026-09-20 21:20:00'),
(65, 3, '2026-09-20 21:21:00'),
(65, 4, '2026-09-20 21:22:00'),
(65, 5, '2026-09-20 21:55:00'),
(66, 1, '2026-09-20 18:16:00'),
(66, 2, '2026-09-20 18:25:00'),
(66, 3, '2026-09-20 18:26:00'),
(66, 4, '2026-09-20 18:27:00'),
(66, 5, '2026-09-20 19:00:00'),
(67, 1, '2026-09-20 19:26:00'),
(67, 2, '2026-09-20 19:35:00'),
(67, 3, '2026-09-20 19:36:00'),
(67, 4, '2026-09-20 19:37:00'),
(67, 5, '2026-09-20 20:10:00'),
(68, 1, '2026-09-20 20:11:00'),
(68, 2, '2026-09-20 20:20:00'),
(68, 3, '2026-09-20 20:21:00'),
(68, 4, '2026-09-20 20:22:00'),
(68, 5, '2026-09-20 20:55:00'),
(69, 12, '2026-09-20 18:46:00'),
(69, 13, '2026-09-20 18:55:00'),
(69, 14, '2026-09-20 18:56:00'),
(69, 15, '2026-09-20 18:57:00'),
(69, 16, '2026-09-20 19:30:00'),
(70, 1, '2026-09-20 19:36:15'),
(70, 2, '2026-09-20 19:45:15'),
(70, 3, '2026-09-20 19:46:15'),
(70, 4, '2026-09-20 19:47:15'),
(70, 5, '2026-09-20 20:20:15');
GO



/*=== PROCEDIMIENTOS ===*/
--1. REGISTRAR UN NUEVO PEDIDO
--Crearemos una TVP para manejar los detalles del pedido
CREATE TYPE TipoDetallePedido AS TABLE
(
codigo_producto INT,
cantidad INT
);
GO
--Luego otra para manejar la participacion de los empleados
CREATE TYPE TipoParticipacionPedido AS TABLE
(
codigo_empleado INT,
tipo_participacion NVARCHAR(50)
);
GO
CREATE OR ALTER PROCEDURE proce_registrar_pedido
(
@codigo_cliente INT,
@codigo_tipopedido INT,
@codigo_direccion INT,
@codigo_mesa INT,
@detalles_pedido TipoDetallePedido READONLY,
@participaciones_pedido TipoParticipacionPedido READONLY
)
AS
BEGIN
SET NOCOUNT ON;
-- VARIABLES
DECLARE @codigo_pedido INT;
DECLARE @codigo_tipoestado INT;
DECLARE @total_pagar DECIMAL(10,2);
-- El pedido se crea inicialmente con total 0
-- tri_actualiza_totalpedido lo recalculará al insertar los registros de DetallePedido
SET @total_pagar = 0;
-- VALIDACIONES INICIALES
-- Validar cliente
IF NOT EXISTS
(
SELECT 1
FROM Cliente
WHERE codigo_cliente = @codigo_cliente
)
BEGIN
RAISERROR('ERROR: El cliente no existe', 16, 1);
RETURN;
END;
-- Validar tipo de pedido
IF NOT EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
)
BEGIN
RAISERROR('ERROR: El tipo de pedido no existe', 16, 1);
RETURN;
END;
-- Validar dirección si fue proporcionada
IF @codigo_direccion IS NOT NULL
AND NOT EXISTS
(
SELECT 1
FROM Direccion
WHERE codigo_direccion = @codigo_direccion
)
BEGIN
RAISERROR('ERROR: La dirección no existe', 16, 1);
RETURN;
END;
-- Validar mesa
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
)
BEGIN
RAISERROR('ERROR: La mesa no existe', 16, 1);
RETURN;
END;
-- Debe existir al menos un detalle
IF NOT EXISTS
(
SELECT 1
FROM @detalles_pedido
)
BEGIN
RAISERROR('ERROR: El pedido debe contener al menos un producto', 16, 1);
RETURN;
END;
-- Validar existencia de productos
IF EXISTS
(
SELECT 1
FROM @detalles_pedido d
LEFT JOIN Producto p
ON d.codigo_producto = p.codigo_producto
WHERE p.codigo_producto IS NULL
)
BEGIN
RAISERROR('ERROR: Uno o más productos no existen', 16, 1);
RETURN;
END;
-- Validar cantidades
IF EXISTS
(
SELECT 1
FROM @detalles_pedido
WHERE cantidad <= 0
)
BEGIN
RAISERROR('ERROR: La cantidad de cada producto debe ser mayor a cero', 16, 1);
RETURN;
END;
-- Validar disponibilidad
IF EXISTS
(
SELECT 1
FROM @detalles_pedido d
INNER JOIN Producto p
ON d.codigo_producto = p.codigo_producto
WHERE p.disponibilidad <> 'Disponible'
)
BEGIN
RAISERROR('ERROR: Uno o más productos no están disponibles', 16, 1);
RETURN;
END;
-- VALIDACIONES SEGÚN TIPO DE PEDIDO
-- DELIVERY
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Delivery'
)
BEGIN
-- Debe tener dirección
IF @codigo_direccion IS NULL
BEGIN
RAISERROR('ERROR: Un pedido Delivery debe tener una dirección', 16, 1);
RETURN;
END;
-- La dirección debe pertenecer al cliente
IF NOT EXISTS
(
SELECT 1
FROM Direccion
WHERE codigo_direccion = @codigo_direccion
AND codigo_cliente = @codigo_cliente
)
BEGIN
RAISERROR('ERROR: La dirección no pertenece al cliente indicado', 16, 1);
RETURN;
END;
-- Debe utilizar mesa virtual 99
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND numero_mesa = 99
)
BEGIN
RAISERROR('ERROR: Los pedidos Delivery deben utilizar la mesa virtual 99', 16, 1);
RETURN;
END;
-- El distrito debe atender Delivery
IF NOT EXISTS
(
SELECT 1
FROM Direccion d
INNER JOIN Distrito dt
ON d.codigo_distrito = dt.codigo_distrito
WHERE d.codigo_direccion = @codigo_direccion
AND dt.atiende_delivery = 'Si'
)
BEGIN
RAISERROR('ERROR: El distrito de la dirección no atiende pedidos Delivery', 16, 1);
RETURN;
END;
END;
-- PRESENCIAL PARA RECOGER
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Presencial para recoger'
)
BEGIN
IF @codigo_direccion IS NOT NULL
BEGIN
RAISERROR('ERROR: Los pedidos para recoger no deben tener dirección', 16, 1);
RETURN;
END;
-- Debe utilizar mesa virtual 98
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND numero_mesa = 98
)
BEGIN
RAISERROR('ERROR: Los pedidos para recoger deben utilizar la mesa virtual 98', 16, 1);
RETURN;
END;
END;
-- PRESENCIAL EN MESA
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Presencial en mesa'
)
BEGIN
IF @codigo_direccion IS NOT NULL
BEGIN
RAISERROR('ERROR: Los pedidos en mesa no deben tener dirección', 16, 1);
RETURN;
END;
-- Debe utilizar mesa física
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND numero_mesa BETWEEN 10 AND 24
)
BEGIN
RAISERROR('ERROR: El pedido en mesa debe utilizar una mesa física', 16, 1);
RETURN;
END;
-- La mesa debe estar libre
IF EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND estado_mesa = 'Ocupada'
)
BEGIN
RAISERROR('ERROR: La mesa seleccionada está ocupada', 16, 1);
RETURN;
END;
END;
-- VALIDACIÓN DE PARTICIPACIONES
-- Debe existir al menos una participación
IF NOT EXISTS
(
SELECT 1
FROM @participaciones_pedido
)
BEGIN
RAISERROR('ERROR: El pedido debe tener empleados participantes', 16, 1);
RETURN;
END;
-- Los empleados indicados deben existir
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
LEFT JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
WHERE e.codigo_empleado IS NULL
)
BEGIN
RAISERROR('ERROR: Uno o más empleados indicados no existen', 16, 1);
RETURN;
END;
-- VALIDACIONES ESPECÍFICAS DE DELIVERY
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Delivery'
)
BEGIN
-- Delivery requiere exactamente 2 participaciones
IF (SELECT COUNT(*) FROM @participaciones_pedido) <> 2
BEGIN
RAISERROR(
'ERROR: Un pedido Delivery debe tener exactamente dos participaciones: Anfitrion y Repartidor',
16, 1
);
RETURN;
END;
-- Debe existir exactamente una participación de Anfitrión
IF
(
SELECT COUNT(*)
FROM @participaciones_pedido
WHERE tipo_participacion = 'Anota pedido delivery'
) <> 1
BEGIN
RAISERROR(
'ERROR: El Delivery debe tener exactamente una participación "Anota pedido delivery"',
16, 1
);
RETURN;
END;
-- Debe existir exactamente una participación de Repartidor
IF
(
SELECT COUNT(*)
FROM @participaciones_pedido
WHERE tipo_participacion = 'Entrega pedido delivery'
) <> 1
BEGIN
RAISERROR(
'ERROR: El Delivery debe tener exactamente una participación "Entrega pedido delivery"',
16, 1
);
RETURN;
END;
-- El que anota debe ser Anfitrión telefónico
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
INNER JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE pp.tipo_participacion = 'Anota pedido delivery'
AND r.descripcion <> 'Anfitrion telefonico'
)
BEGIN
RAISERROR(
'ERROR: Solo un Anfitrion telefonico puede tener la participación "Anota pedido delivery"',
16, 1
);
RETURN;
END;
-- El que entrega debe ser Repartidor
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
INNER JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE pp.tipo_participacion = 'Entrega pedido delivery'
AND r.descripcion <> 'Repartidor'
)
BEGIN
RAISERROR(
'ERROR: Solo un Repartidor puede tener la participación "Entrega pedido delivery"',
16, 1
);
RETURN;
END;
END;
-- VALIDACIONES ESPECÍFICAS DE PEDIDOS PRESENCIALES
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion IN ('Presencial en mesa', 'Presencial para recoger')
)
BEGIN
-- Solo debe existir un participante
IF (SELECT COUNT(*) FROM @participaciones_pedido) <> 1
BEGIN
RAISERROR(
'ERROR: Un pedido presencial debe tener exactamente un Camarero',
16, 1
);
RETURN;
END;
-- Debe ser Atiende pedido presencial
IF NOT EXISTS
(
SELECT 1
FROM @participaciones_pedido
WHERE tipo_participacion = 'Atiende pedido presencial'
)
BEGIN
RAISERROR(
'ERROR: El pedido presencial debe tener la participación "Atiende pedido presencial"',
16, 1
);
RETURN;
END;
-- El empleado debe ser Camarero
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
INNER JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE pp.tipo_participacion = 'Atiende pedido presencial'
AND r.descripcion <> 'Camarero'
)
BEGIN
RAISERROR(
'ERROR: Solo un Camarero puede tener la participación "Atiende pedido presencial"',
16, 1
);
RETURN;
END;
END;
-- TRANSACCIÓN
BEGIN TRY
BEGIN TRANSACTION;
-- OBTENER ESTADO INICIAL
SELECT @codigo_tipoestado = codigo_tipoestado
FROM TipoEstado
WHERE codigo_tipopedido = @codigo_tipopedido
AND orden_estado = 1;
IF @codigo_tipoestado IS NULL
BEGIN
RAISERROR(
'ERROR: No existe un estado inicial para este tipo de pedido',
16, 1
);
END;
-- CREAR PEDIDO
INSERT INTO Pedido
(
codigo_cliente,
codigo_tipopedido,
codigo_tipoestado,
codigo_direccion,
codigo_mesa,
total_pagar
)
VALUES
(
@codigo_cliente,
@codigo_tipopedido,
@codigo_tipoestado,
@codigo_direccion,
@codigo_mesa,
@total_pagar
);
SET @codigo_pedido = SCOPE_IDENTITY();
-- INSERTAR DETALLES
INSERT INTO DetallePedido
(
codigo_pedido,
codigo_producto,
cantidad,
precio_unitario
)
SELECT
@codigo_pedido,
d.codigo_producto,
d.cantidad,
p.precio_producto
FROM @detalles_pedido d
INNER JOIN Producto p
ON d.codigo_producto = p.codigo_producto;
-- OBTENER TOTAL ACTUALIZADO POR EL TRIGGER
SELECT @total_pagar = total_pagar
FROM Pedido
WHERE codigo_pedido = @codigo_pedido;
-- REGISTRAR PARTICIPACIONES
INSERT INTO ParticipacionPedido
(
codigo_pedido,
codigo_empleado,
tipo_participacion,
estado_participacion
)
SELECT
@codigo_pedido,
codigo_empleado,
tipo_participacion,
'Activo'
FROM @participaciones_pedido;
-- REGISTRAR HISTORIAL DEL ESTADO
INSERT INTO HistorialEstadoPedido
(
codigo_pedido,
codigo_tipoestado
)
VALUES
(
@codigo_pedido,
@codigo_tipoestado
);
-- CONFIRMAR
COMMIT TRANSACTION;
-- RESULTADO
SELECT
@codigo_pedido AS codigo_pedido,
@total_pagar AS total_pagar,
'Pedido registrado correctamente' AS mensaje;
END TRY
BEGIN CATCH
IF @@TRANCOUNT > 0
ROLLBACK TRANSACTION;
THROW;
END CATCH;
END;
GO
GO

-- PRUEBA DEL PROCEDIMIENTO - DELIVERY
DECLARE @detalles TipoDetallePedido;
DECLARE @participaciones TipoParticipacionPedido;

INSERT INTO @detalles (codigo_producto, cantidad)
VALUES (1, 2);
INSERT INTO @participaciones (codigo_empleado, tipo_participacion)
VALUES
(10, 'Anota pedido delivery'),-- Santiago Alvarez Herrera
(3, 'Entrega pedido delivery'); -- Eduardo Delgado Nuñez
EXEC proce_registrar_pedido
@codigo_cliente = 1,
@codigo_tipopedido = 2,
@codigo_direccion = 1,
@codigo_mesa = 17,
@detalles_pedido = @detalles,
@participaciones_pedido = @participaciones;

--VERIFICACIÓN DEL PROCEDIMIENTO
DECLARE @ultimo_pedido INT;
SELECT @ultimo_pedido = MAX(codigo_pedido)
FROM Pedido;
--Verificamos pedido creado
SELECT
p.codigo_pedido,
p.codigo_cliente,
p.codigo_tipopedido,
p.codigo_tipoestado,
p.codigo_direccion,
p.codigo_mesa,
p.fecha_pedido,
p.total_pagar
FROM Pedido p
WHERE p.codigo_pedido = @ultimo_pedido;
--Verificamos detalle insertado
SELECT
dp.codigo_pedido,
dp.codigo_producto,
dp.cantidad,
dp.precio_unitario,
dp.subtotal
FROM DetallePedido dp
WHERE dp.codigo_pedido = @ultimo_pedido;
--Comparamos total del Pedido contra los detalles
SELECT
p.codigo_pedido,
p.total_pagar AS TotalPedido,
SUM(dp.subtotal) AS TotalDetalles
FROM Pedido p
INNER JOIN DetallePedido dp
ON p.codigo_pedido = dp.codigo_pedido
WHERE p.codigo_pedido = @ultimo_pedido
GROUP BY
p.codigo_pedido,
p.total_pagar;
--Verificamos la participación del empleado
SELECT *
FROM ParticipacionPedido
WHERE codigo_pedido = @ultimo_pedido;
--Verificamos historial/estado inicial
SELECT *
FROM HistorialEstadoPedido
WHERE codigo_pedido = @ultimo_pedido;
GO


--2. ACTUALIZAR TIPO DE PEDIDO (Delivery -> Presencial)
CREATE OR ALTER PROCEDURE proce_actualiza_tipopedido
(
@p_codigo_pedido INT,
@p_nuevo_codigo_tipopedido INT,
@p_codigo_empleado INT
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @v_codigo_tipopedido_actual INT;
DECLARE @v_codigo_tipoestado_actual INT;
DECLARE @v_orden_estado INT;
DECLARE @v_nuevo_codigo_tipoestado INT;
DECLARE @v_codigo_mesa_nueva INT;
DECLARE @v_mensaje_error NVARCHAR(4000);
BEGIN TRY
BEGIN TRANSACTION;
-- PASO 1: VALIDAR PEDIDO
IF @p_codigo_pedido IS NULL OR @p_codigo_pedido <= 0
BEGIN
RAISERROR('ERROR: El código del pedido ingresado no es válido', 16, 1);
RETURN;
END;
SELECT
@v_codigo_tipopedido_actual = codigo_tipopedido,
@v_codigo_tipoestado_actual = codigo_tipoestado
FROM Pedido
WHERE codigo_pedido = @p_codigo_pedido;
IF @v_codigo_tipopedido_actual IS NULL
BEGIN
RAISERROR('ERROR: El pedido especificado no existe', 16, 1);
RETURN;
END;
-- PASO 2: VALIDAR TIPO ACTUAL Y NUEVO TIPO
-- El procedimiento solo permite cambiar desde Delivery
IF NOT EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @v_codigo_tipopedido_actual
AND descripcion = 'Delivery'
)
BEGIN
RAISERROR('ERROR: Solo se pueden modificar pedidos que actualmente sean Delivery', 16, 1);
RETURN;
END;
-- El nuevo tipo debe ser Presencial en mesa o para recoger
IF NOT EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @p_nuevo_codigo_tipopedido
AND descripcion IN
(
'Presencial en mesa',
'Presencial para recoger'
)
)
BEGIN
RAISERROR('ERROR: El nuevo tipo debe ser Presencial en mesa o Presencial para recoger', 16, 1);
RETURN;
END;
-- PASO 3: VALIDAR ESTADO ACTUAL
SELECT @v_orden_estado = orden_estado
FROM TipoEstado
WHERE codigo_tipoestado = @v_codigo_tipoestado_actual;
-- Delivery solo puede cambiar mientras esté en:
-- 1 = Pedido tomado
-- 2 = En preparación
-- 3 = Listo para entregar
IF @v_orden_estado >= 4
BEGIN
RAISERROR('ERROR: El pedido Delivery ya no puede cambiar de modalidad porque se encuentra en un estado avanzado', 16, 1);
RETURN;
END;
-- PASO 4: VALIDAR EMPLEADO
IF NOT EXISTS
(
SELECT 1
FROM Empleado e
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE e.codigo_empleado = @p_codigo_empleado
AND r.descripcion = 'Camarero'
)
BEGIN
RAISERROR('ERROR: El empleado indicado debe tener el rol Camarero', 16, 1);
RETURN;
END;
-- PASO 5: DETERMINAR ESTADO EQUIVALENTE
SELECT @v_nuevo_codigo_tipoestado = te.codigo_tipoestado
FROM TipoEstado te
WHERE te.codigo_tipopedido = @p_nuevo_codigo_tipopedido
AND te.orden_estado = @v_orden_estado;
IF @v_nuevo_codigo_tipoestado IS NULL
BEGIN
RAISERROR('ERROR: No existe un estado equivalente para el nuevo tipo de pedido', 16, 1);
RETURN;
END;
-- PASO 6: DETERMINAR MESA
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @p_nuevo_codigo_tipopedido
AND descripcion = 'Presencial para recoger'
)
BEGIN
-- Mesa virtual 98
SELECT @v_codigo_mesa_nueva = codigo_mesa
FROM Mesa
WHERE numero_mesa = 98;
IF @v_codigo_mesa_nueva IS NULL
BEGIN
RAISERROR('ERROR: No existe la mesa virtual 98', 16, 1);
RETURN;
END;
END
ELSE
BEGIN
-- Buscar una mesa física libre
SELECT TOP 1 @v_codigo_mesa_nueva = codigo_mesa
FROM Mesa
WHERE numero_mesa BETWEEN 10 AND 24
AND estado_mesa = 'Libre'
ORDER BY numero_mesa;
IF @v_codigo_mesa_nueva IS NULL
BEGIN
RAISERROR('ERROR: No existen mesas físicas disponibles', 16, 1);
RETURN;
END;
END;
-- PASO 7: CANCELAR PARTICIPACIONES DELIVERY
UPDATE ParticipacionPedido
SET estado_participacion = 'Cancelado',
fecha_participacion = GETDATE()
WHERE codigo_pedido = @p_codigo_pedido
AND estado_participacion = 'Activo';
-- PASO 8: ACTUALIZAR PEDIDO
UPDATE Pedido
SET codigo_tipopedido = @p_nuevo_codigo_tipopedido,
codigo_tipoestado = @v_nuevo_codigo_tipoestado,
codigo_direccion = NULL,
codigo_mesa = @v_codigo_mesa_nueva
WHERE codigo_pedido = @p_codigo_pedido;
-- PASO 9: REGISTRAR NUEVA PARTICIPACIÓN DEL CAMARERO
INSERT INTO ParticipacionPedido
(
codigo_pedido,
codigo_empleado,
tipo_participacion,
estado_participacion,
fecha_participacion
)
VALUES
(
@p_codigo_pedido,
@p_codigo_empleado,
'Atiende pedido presencial',
'Activo',
GETDATE()
);
-- PASO 10: MARCAR MESA FÍSICA COMO OCUPADA
IF EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @v_codigo_mesa_nueva
AND numero_mesa BETWEEN 10 AND 24
)
BEGIN
UPDATE Mesa
SET estado_mesa = 'Ocupada'
WHERE codigo_mesa = @v_codigo_mesa_nueva;
END;
-- PASO 11: CONFIRMAR
COMMIT TRANSACTION;
SELECT
@p_codigo_pedido AS codigo_pedido,
@p_nuevo_codigo_tipopedido AS nuevo_codigo_tipopedido,
@v_nuevo_codigo_tipoestado AS nuevo_codigo_tipoestado,
@v_codigo_mesa_nueva AS codigo_mesa,
'Pedido actualizado correctamente' AS mensaje;
END TRY
BEGIN CATCH
IF @@TRANCOUNT > 0
ROLLBACK TRANSACTION;
SET @v_mensaje_error = ERROR_MESSAGE();
RAISERROR(@v_mensaje_error, 16, 1);
END CATCH;
END;
GO
--PRUEBA DEL PROCEDIMIENTO
EXEC proce_actualiza_tipopedido
@p_codigo_pedido = 10072,
@p_nuevo_codigo_tipopedido = 1,
@p_codigo_empleado = 9;
--VERIFICACIÓN DEL PROCEDIMIENTO
--Verificamos el pedido actualizado
SELECT
p.codigo_pedido,
p.codigo_cliente,
tp.descripcion AS tipo_pedido,
te.descripcion AS estado_pedido,
p.codigo_direccion,
p.codigo_mesa,
m.numero_mesa,
p.total_pagar
FROM Pedido p
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN TipoEstado te
ON p.codigo_tipoestado = te.codigo_tipoestado
INNER JOIN Mesa m
ON p.codigo_mesa = m.codigo_mesa
WHERE p.codigo_pedido = 10072;
--Verificamos las participaciones
SELECT
codigo_pedido,
codigo_empleado,
tipo_participacion,
estado_participacion,
fecha_participacion
FROM ParticipacionPedido
WHERE codigo_pedido = 10072
ORDER BY fecha_participacion;
--Verificamos el historial de estados
SELECT
codigo_historial,
codigo_pedido,
codigo_tipoestado,
hora_cambio
FROM HistorialEstadoPedido
WHERE codigo_pedido = 10072
ORDER BY hora_cambio;
--Verificamos la auditoría
SELECT
codigo_log,
fecha_hora,
usuario_sistema,
accion,
tabla_afectada,
registro_afectado,
campo_afectado
FROM LogSistema
WHERE tabla_afectada = 'Pedido'
AND registro_afectado = '10072'
ORDER BY fecha_hora;
--Verificamos el estado de la mesa asignada
SELECT
codigo_mesa,
numero_mesa,
estado_mesa
FROM Mesa
WHERE codigo_mesa =
(
SELECT codigo_mesa
FROM Pedido
WHERE codigo_pedido = 10072
);
GO


--3. REGISTRAR CLIENTE FORMALMENTE (con correo electrónico como agregado)
CREATE OR ALTER PROCEDURE proce_registrar_cliente
(
@primer_nombre NVARCHAR(20),
@segundo_nombre NVARCHAR(20) = NULL,
@apellido_paterno NVARCHAR(20) = NULL,
@apellido_materno NVARCHAR(20) = NULL,
@telefono NVARCHAR(15),
@correo_electronico NVARCHAR(150) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRY
BEGIN TRANSACTION;
DECLARE @codigo_cliente_existente INT = NULL;
-- Buscar si el teléfono ya existe en la base de datos
SELECT @codigo_cliente_existente = codigo_cliente
FROM Cliente
WHERE telefono = @telefono AND telefono IS NOT NULL;
-- Validar que el correo electrónico no esté registrado por otro cliente
IF @correo_electronico IS NOT NULL AND EXISTS
(
SELECT 1
FROM Cliente
WHERE correo_electronico = @correo_electronico
AND (@codigo_cliente_existente IS NULL OR codigo_cliente <> @codigo_cliente_existente)
)
BEGIN
RAISERROR('ERROR: El correo electrónico proporcionado ya se encuentra registrado por otro cliente', 16, 1);
RETURN;
END;
-- Si el teléfono existe en la base de datos se actualiza
IF @codigo_cliente_existente IS NOT NULL
BEGIN
UPDATE Cliente
SET segundo_nombre = ISNULL(@segundo_nombre, segundo_nombre),
apellido_paterno = ISNULL(@apellido_paterno, apellido_paterno),
apellido_materno = ISNULL(@apellido_materno, apellido_materno),
correo_electronico = ISNULL(@correo_electronico, correo_electronico)
WHERE codigo_cliente = @codigo_cliente_existente;
END
-- Si el teléfono no existe se registra un nuevo cliente
ELSE
BEGIN
INSERT INTO Cliente
(
primer_nombre,
segundo_nombre,
apellido_paterno,
apellido_materno,
telefono,
correo_electronico,
fecha_registro
)
VALUES
(
@primer_nombre,
@segundo_nombre,
@apellido_paterno,
@apellido_materno,
@telefono,
@correo_electronico,
GETDATE()
);
END;
COMMIT TRANSACTION;
SELECT
ISNULL(@codigo_cliente_existente, SCOPE_IDENTITY()) AS codigo_cliente,
'Cliente registrado o actualizado correctamente' AS mensaje;
END TRY
BEGIN CATCH
IF @@TRANCOUNT > 0
ROLLBACK TRANSACTION;
THROW;
END CATCH;
END;
GO
--PRUEBA DEL PROCEDIMIENTO
EXEC proce_registrar_cliente
@primer_nombre = 'Juan',
@segundo_nombre = 'Carlos',
@apellido_paterno = 'Perez',
@apellido_materno = 'Gomez',
@telefono = '999111226',
@correo_electronico = 'juan.perez3@email.com';
--VERIFICACIÓN DEL PROCEDIMIENTO
SELECT
codigo_cliente,
primer_nombre,
segundo_nombre,
apellido_paterno,
apellido_materno,
telefono,
correo_electronico,
fecha_registro
FROM Cliente
WHERE telefono = '999111226';
GO



/*=== FUNCIONES ===*/
--1. CALCULAR EL GASTO POR INGREDIENTE
CREATE OR ALTER FUNCTION func_calcular_gasto_ingrediente
(@p_codigo_ingrediente INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
DECLARE @v_gasto_total DECIMAL(10,2) = 0;
--Validar que el ingrediente exista en la tabla Ingrediente
IF NOT EXISTS (SELECT 1 FROM Ingrediente WHERE codigo_ingrediente = @p_codigo_ingrediente)
BEGIN
RETURN NULL; 
END
--Buscar registros en DetalleCompra y sumar el gasto (cantidad * precio_unitario)
SELECT @v_gasto_total = ISNULL(SUM(cantidad * precio_unitario), 0)
FROM DetalleCompra
WHERE codigo_ingrediente = @p_codigo_ingrediente;
--Retornar el gasto total calculado
RETURN @v_gasto_total;
END;
GO
--PRUEBA 1: Ingrediente registrado
SELECT dbo.func_calcular_gasto_ingrediente(1) AS GastoTotalEnIngrediente;
GO
--PRUEBA 2: Ingrediente inexistente
SELECT dbo.func_calcular_gasto_ingrediente(50) AS GastoTotalEnIngrediente;
GO


--2. CALCULAR LA FRECUENCIA DE UN PRODUCTO
CREATE OR ALTER FUNCTION func_calcular_frecuencia_producto
(
@codigo_producto INT
)
RETURNS INT
AS
BEGIN
DECLARE @frecuencia INT = 0;
-- Verificar si el producto existe
IF EXISTS
(
SELECT 1
FROM Producto
WHERE codigo_producto = @codigo_producto
)
BEGIN
SELECT @frecuencia = COUNT(*)
FROM DetallePedido
WHERE codigo_producto = @codigo_producto;
END
ELSE
BEGIN
SET @frecuencia = -1;
END;
RETURN @frecuencia;
END;
GO
--PRUEBA 1: Cuántas veces se vendió el producto con código 1
SELECT dbo.func_calcular_frecuencia_producto(1) AS FrecuenciaProducto;
--PRUEBA 2 Producto inexistente
SELECT dbo.func_calcular_frecuencia_producto(99) AS FrecuenciaProducto;



/*=== CREACIÓN DE ROLES ===*/
--Creamos el Rol Administrador
CREATE USER usuario_admin
WITHOUT LOGIN;
GO
CREATE ROLE rol_administrador
GO
ALTER ROLE rol_administrador
ADD MEMBER usuario_admin;
GO
--asignamos su permiso: Acceso y modificación TOTAL a todas las tablas
GRANT SELECT, INSERT, UPDATE, DELETE
ON SCHEMA::dbo
TO rol_administrador
GO


--Creamos el Rol Operador
CREATE USER usuario_operador
WITHOUT LOGIN;
GO
CREATE ROLE rol_operador
GO
ALTER ROLE rol_operador
ADD MEMBER usuario_operador;
GO
--Asignamos sus permisos:
--Consultar, insertar y actualizar tablas relacionadas al pedido
GRANT SELECT, INSERT, UPDATE
ON dbo.Pedido
TO rol_operador
GRANT SELECT, INSERT, UPDATE
ON dbo.DetallePedido
TO rol_operador
GRANT SELECT, INSERT, UPDATE
ON dbo.Pago
TO rol_operador
GRANT SELECT, INSERT, UPDATE
ON dbo.ParticipacionPedido
TO rol_operador

--Consultar e insertar tablas relacionadas al pedido
--pero que no requieren de actualizar
GRANT SELECT, INSERT
ON dbo.Comprobante
TO rol_operador
GRANT SELECT, INSERT
ON dbo.HistorialEstadoPedido
TO rol_operador

--Solo consultar tablas necesarias para la operación de la pollería
GRANT SELECT
ON dbo.Cliente
TO rol_operador
GRANT SELECT
ON dbo.Direccion
TO rol_operador
GRANT SELECT
ON dbo.Producto
TO rol_operador
GRANT SELECT
ON dbo.TipoPedido
TO rol_operador
GRANT SELECT
ON dbo.TipoEstado
TO rol_operador
GRANT SELECT
ON dbo.Mesa
TO rol_operador
GRANT SELECT
ON dbo.Categoria
TO rol_operador



/*=== CREACIÓN DE GENERADORES DE DATOS SINTÉTICOS ===*/
--Serán datos sintéticos para la tabla Pedido, además de
--algunas tablas con las que se relaciona (DetallePedido, Pago e HistorialEstadoPedido)

--Creacion de datos sintéticos de prueba en Pedido
;WITH Numeros AS (SELECT TOP (10000)
ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS Numero
FROM sys.all_objects AS A
CROSS JOIN sys.all_objects AS B),
Pedidos AS
(
SELECT Numero,
CASE WHEN ABS(CHECKSUM(NEWID())) % 3 = 0 THEN 1
WHEN ABS(CHECKSUM(NEWID())) % 3 = 1 THEN 2
ELSE 3
END AS codigo_tipopedido,
ABS(CHECKSUM(NEWID())) % 100 + 1 AS GrupoCliente,
DATEADD(MINUTE, ABS(CHECKSUM(NEWID())) % 720,
DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 335, '2025-12-01 10:00:00')) AS fecha_pedido
FROM Numeros
),
Clientes AS
(
SELECT codigo_cliente, telefono,
ROW_NUMBER() OVER (ORDER BY codigo_cliente) AS NroCliente
FROM dbo.Cliente
),
--Se crea una clasificación adicional de los clientes, para que se generen algunos frecuentes,
--habituales u ocasionales. Esto apoyará al posterior análisis en Power BI
ClientesClasificados AS
(
SELECT codigo_cliente, telefono,
CASE WHEN NroCliente BETWEEN 1 AND 10 THEN 'Frecuente'
WHEN NroCliente BETWEEN 11 AND 30 THEN 'Habitual'
ELSE 'Ocasional'
END AS TipoCliente
FROM Clientes
),
PedidosClientes AS
(
SELECT p.Numero, p.codigo_tipopedido, p.GrupoCliente, p.fecha_pedido, c.codigo_cliente
FROM Pedidos p
CROSS APPLY
(
SELECT TOP 1
cc.codigo_cliente
FROM ClientesClasificados cc
WHERE ((p.codigo_tipopedido IN (1, 3)) OR (p.codigo_tipopedido = 2 AND cc.telefono IS NOT NULL))
AND ((p.GrupoCliente BETWEEN 1 AND 60 AND cc.TipoCliente = 'Frecuente')
OR (p.GrupoCliente BETWEEN 61 AND 90 AND cc.TipoCliente = 'Habitual')
OR (p.GrupoCliente BETWEEN 91 AND 100 AND cc.TipoCliente = 'Ocasional'))
ORDER BY NEWID()) c
)
INSERT INTO dbo.Pedido (codigo_cliente, codigo_tipopedido, codigo_tipoestado,
codigo_direccion, codigo_mesa, fecha_pedido, total_pagar)
SELECT pc.codigo_cliente, pc.codigo_tipopedido,
CASE WHEN pc.codigo_tipopedido = 1 THEN 5
WHEN pc.codigo_tipopedido = 2 THEN 11
WHEN pc.codigo_tipopedido = 3 THEN 16
END AS codigo_tipoestado,
CASE WHEN pc.codigo_tipopedido = 2
THEN
(
SELECT TOP 1 d.codigo_direccion
FROM Direccion d
WHERE d.codigo_cliente = pc.codigo_cliente
ORDER BY NEWID()
)
ELSE NULL
END AS codigo_direccion,
CASE WHEN pc.codigo_tipopedido = 1 THEN ABS(CHECKSUM(NEWID())) % 15 + 1
WHEN pc.codigo_tipopedido = 2 THEN 17
WHEN pc.codigo_tipopedido = 3 THEN 16
END AS codigo_mesa,
pc.fecha_pedido,
0 AS total_pagar
FROM PedidosClientes pc;
--Verificamos que se hayan generado correctamente, deben salir 10070 ya que 70 son los creados manualmente
SELECT COUNT(*) AS TotalPedidos
FROM Pedido;


--Generador de detalles para los pedidos sintéticos
;WITH Pedidos AS (SELECT codigo_pedido,
CASE WHEN codigo_pedido BETWEEN 71 AND 3070 THEN 4
WHEN codigo_pedido BETWEEN 3071 AND 7070 THEN 5
WHEN codigo_pedido BETWEEN 7071 AND 9070 THEN 6
ELSE 7
END AS CantidadDetalles
FROM dbo.Pedido
WHERE codigo_pedido BETWEEN 71 AND 10070),
ProductosRanking AS
(
SELECT pe.codigo_pedido, p.codigo_producto, p.precio_producto,
--Al incluir pe.codigo_pedido dentro de CHECKSUM/NEWID, forzamos a SQL Server
--a calcular un orden 100% único por cada pedido individual
ROW_NUMBER() OVER (PARTITION BY pe.codigo_pedido ORDER BY CHECKSUM(NEWID(), pe.codigo_pedido)) AS Rn,
pe.CantidadDetalles
FROM Pedidos pe
CROSS JOIN dbo.Producto p
)
INSERT INTO dbo.DetallePedido (codigo_pedido, codigo_producto, cantidad, precio_unitario)
SELECT pr.codigo_pedido, pr.codigo_producto,
-- Genera cantidad aleatoria entre 1 y 5 por cada detalle
(ABS(CHECKSUM(NEWID(), pr.codigo_pedido, pr.codigo_producto)) % 5) + 1 AS cantidad, pr.precio_producto
FROM ProductosRanking pr
WHERE pr.Rn <= pr.CantidadDetalles;
--Verificamos que se hayan generado correctamente, deben salir 51300 ya que 300 son los creados manualmente
SELECT COUNT(*) AS TotalDetalles
FROM DetallePedido;


--Generador de pagos de los pedidos sintéticos
INSERT INTO dbo.Pago (codigo_pedido, codigo_empleado, fecha_pago, monto_pago, metodo_pago)
SELECT p.codigo_pedido,
CASE WHEN p.codigo_tipopedido = 2 THEN
CASE WHEN p.codigo_pedido % 2 = 0 THEN 3 ELSE 6 END
ELSE 4
END AS codigo_empleado, DATEADD(MINUTE, 60 + ((p.codigo_pedido * 17) % 61), p.fecha_pedido) AS fecha_pago,
CASE WHEN p.codigo_pedido % 5 = 0 THEN p.total_pagar + 10
WHEN p.codigo_pedido % 5 = 1 THEN p.total_pagar + 5
ELSE p.total_pagar
END AS monto_pago,
CASE p.codigo_tipopedido
WHEN 1 THEN CASE (ABS(CHECKSUM(NEWID(), p.codigo_pedido)) % 20)
WHEN 0 THEN 'Yape' WHEN 1 THEN 'Yape' WHEN 2 THEN 'Yape'
WHEN 3 THEN 'Efectivo' WHEN 4 THEN 'Efectivo' WHEN 5 THEN 'Efectivo'
WHEN 6 THEN 'Efectivo' WHEN 7 THEN 'Efectivo' WHEN 8 THEN 'Efectivo'
WHEN 9 THEN 'Efectivo' WHEN 10 THEN 'Efectivo'
ELSE 'Tarjeta'
END
WHEN 2 THEN CASE (ABS(CHECKSUM(NEWID(), p.codigo_pedido)) % 10)
WHEN 0 THEN 'Efectivo'
WHEN 1 THEN 'Tarjeta' WHEN 2 THEN 'Tarjeta' WHEN 3 THEN 'Tarjeta'
ELSE 'Yape'
END
ELSE CASE (ABS(CHECKSUM(NEWID(), p.codigo_pedido)) % 10)
WHEN 0 THEN 'Tarjeta' WHEN 1 THEN 'Tarjeta'
WHEN 2 THEN 'Efectivo' WHEN 3 THEN 'Efectivo' WHEN 4 THEN 'Efectivo' WHEN 5 THEN 'Efectivo'
ELSE 'Yape'
END
END AS metodo_pago
FROM dbo.Pedido p
WHERE p.codigo_pedido BETWEEN 71 AND 10070;
--Verificamos que se hayan generado correctamente, deben salir 10070 ya que 70 son los creados manualmente
SELECT COUNT(*) AS TotalPagos
FROM Pago;


--Generador de historial de cambios de estado de los pedidos sintéticos
WITH TiemposBaseCategoria AS (
-- ASIGNACIÓN DE TIEMPOS POR CATEGORÍA
SELECT p.codigo_producto,CASE p.codigo_categoria
WHEN 8 THEN 3  --Bebidas
WHEN 7 THEN 8  --Porciones y acompañamientos
WHEN 2 THEN 10 --Sopas y entradas
WHEN 1 THEN 12 --Pollo a la brasa
WHEN 3 THEN 15 --Arroz chaufa
WHEN 4 THEN 16 --Aeropuertos y combinados
WHEN 5 THEN 18 --Platos chifa
WHEN 6 THEN 25 --Parrillas y carnes
ELSE 12
END AS MinutosEstandar
FROM dbo.Producto p
),
MaxTiempoPorPedido AS
(
--OBTENER EL TIEMPO DEL PLATO/CATEGORÍA MÁS COMPLEJO DE CADA PEDIDO
SELECT dp.codigo_pedido,
MAX(t.MinutosEstandar) AS TiempoCocinaPlato
FROM dbo.DetallePedido dp
INNER JOIN TiemposBaseCategoria t ON dp.codigo_producto = t.codigo_producto
GROUP BY dp.codigo_pedido
),
CalculoTiempos AS
(
--CALCULA LOS INTERVALOS AJUSTADOS SIN EXCEDER LA FECHA DE PAGO
SELECT p.codigo_pedido, p.codigo_tipopedido, p.fecha_pedido, pg.fecha_pago,
DATEDIFF(MINUTE, p.fecha_pedido, pg.fecha_pago) AS MinutosHastaPago,
--Tiempo base de cocina del plato principal + variabilidad de 0 a 4 min por pedido
(tp.TiempoCocinaPlato + (ABS(CHECKSUM(NEWID(), p.codigo_pedido)) % 5)) AS TiempoCocinaEstimado
FROM dbo.Pedido p
INNER JOIN dbo.Pago pg ON p.codigo_pedido = pg.codigo_pedido
INNER JOIN MaxTiempoPorPedido tp ON p.codigo_pedido = tp.codigo_pedido
WHERE p.codigo_pedido BETWEEN 71 AND 10070
),
TiemposFinales AS (
SELECT codigo_pedido, codigo_tipopedido, fecha_pedido, fecha_pago,
--Estado: En preparación (+2 min tras tomar el pedido)
DATEADD(MINUTE, 2, fecha_pedido) AS HoraEnPreparacion,
        -- Estado: Listo (Garantiza margen de seguridad antes de la fecha de pago)
DATEADD(MINUTE, CASE WHEN (2 + TiempoCocinaEstimado + 8) >= MinutosHastaPago THEN (MinutosHastaPago - 6)
ELSE (2 + TiempoCocinaEstimado)
END, fecha_pedido) AS HoraListo, --Estado: Entregado / Despachado (Ocurre minutos después de estar listo)
DATEADD(MINUTE, CASE WHEN (2 + TiempoCocinaEstimado + 8) >= MinutosHastaPago THEN (MinutosHastaPago - 2)
ELSE (2 + TiempoCocinaEstimado + 4)
END, fecha_pedido) AS HoraEntregado
FROM CalculoTiempos
)

-- INSERT EN LA TABLA HISTORIALESTADOPEDIDO
INSERT INTO dbo.HistorialEstadoPedido (codigo_pedido, codigo_tipoestado, hora_cambio)

-- ===================================
-- 1. PRESENCIAL EN MESA (codigo_tipopedido = 1)
-- ===================================
-- Estado 1: Pedido Tomado
SELECT codigo_pedido, 1, fecha_pedido FROM TiemposFinales WHERE codigo_tipopedido = 1
UNION ALL
-- Estado 2: En preparación
SELECT codigo_pedido, 2, HoraEnPreparacion FROM TiemposFinales WHERE codigo_tipopedido = 1
UNION ALL
-- Estado 3: Listo para servir
SELECT codigo_pedido, 3, HoraListo FROM TiemposFinales WHERE codigo_tipopedido = 1
UNION ALL
-- Estado 4: Servido en mesa
SELECT codigo_pedido, 4, HoraEntregado FROM TiemposFinales WHERE codigo_tipopedido = 1
UNION ALL
-- Estado 5: Pagado
SELECT codigo_pedido, 5, fecha_pago FROM TiemposFinales WHERE codigo_tipopedido = 1

-- ===================================
-- 2. DELIVERY (codigo_tipopedido = 2)
-- ===================================
UNION ALL
-- Estado 6: Pedido Registrado
SELECT codigo_pedido, 6, fecha_pedido FROM TiemposFinales WHERE codigo_tipopedido = 2
UNION ALL
-- Estado 7: En preparación
SELECT codigo_pedido, 7, HoraEnPreparacion FROM TiemposFinales WHERE codigo_tipopedido = 2
UNION ALL
-- Estado 8: Listo para despacho
SELECT codigo_pedido, 8, HoraListo FROM TiemposFinales WHERE codigo_tipopedido = 2
UNION ALL
-- Estado 9: En camino (Asignado a Repartidor)
SELECT codigo_pedido, 9, HoraEntregado FROM TiemposFinales WHERE codigo_tipopedido = 2
UNION ALL
-- Estado 10: Entregado a cliente
SELECT codigo_pedido, 10, DATEADD(MINUTE, -1, fecha_pago) FROM TiemposFinales WHERE codigo_tipopedido = 2
UNION ALL
-- Estado 11: Pagado
SELECT codigo_pedido, 11, fecha_pago FROM TiemposFinales WHERE codigo_tipopedido = 2

-- ===================================
-- 3. RECOJO (codigo_tipopedido = 3)
-- ===================================
UNION ALL
-- Estado 12: Pedido Registrado
SELECT codigo_pedido, 12, fecha_pedido FROM TiemposFinales WHERE codigo_tipopedido = 3
UNION ALL
-- Estado 13: En preparación
SELECT codigo_pedido, 13, HoraEnPreparacion FROM TiemposFinales WHERE codigo_tipopedido = 3
UNION ALL
-- Estado 14: Listo para recojo
SELECT codigo_pedido, 14, HoraListo FROM TiemposFinales WHERE codigo_tipopedido = 3
UNION ALL
-- Estado 15: Entregado al cliente
SELECT codigo_pedido, 15, HoraEntregado FROM TiemposFinales WHERE codigo_tipopedido = 3
UNION ALL
-- Estado 16: Pagado
SELECT codigo_pedido, 16, fecha_pago FROM TiemposFinales WHERE codigo_tipopedido = 3;
--Verificamos que se hayan generado correctamente, deben salir 52175 ya que 382 son los creados manualmente
SELECT COUNT(*) AS TotalHistoriales
FROM HistorialEstadoPedido;



/*===PRUEBA DE RENDIMIENTO Y CREACIÓN DEL INDICE===*/
--Activamos estadísticas
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

--Definiremos una consulta para la prueba
--¿En qué pedidos aparece el producto "1/4 Pollo a la brasa", es decir, el producto con código 3?
SELECT *
FROM dbo.DetallePedido
WHERE codigo_producto = 3;

--Ahora crearemos el índice
--Como actualmente DetallePedido tiene clustered index de código_pedido -> código_producto
--Crearemos un nonclustered que busque por código_producto, que incluya el resto de columnas
CREATE NONCLUSTERED INDEX IX_DetallePedido_Producto
ON dbo.DetallePedido(codigo_producto)
INCLUDE (cantidad, precio_unitario, subtotal);
GO

--Ahora volveremos a hacer la misma consulta y veremos el rendimiento
SELECT *
FROM dbo.DetallePedido
WHERE codigo_producto = 3;



/*=== IMPLEMENTACIÓN EN MONGODB ===*/
--Dado a que buscamos campos variables entre documentos, utilizaremos
--los diferentes tipos de pedidos que existen en el restaurante

--Consulta 1: Para "Presencial en mesa"
SELECT TOP 3
p.codigo_pedido AS codigoPedido,
tp.descripcion AS tipoPedido,
c.primer_nombre + ' ' + c.apellido_paterno AS cliente,
m.numero_mesa AS numeroMesa,
te.descripcion AS estado,
p.total_pagar AS totalPagar,

--Subconsulta para poder obtener el nombre del camarero
(
SELECT TOP 1
e.primer_nombre + ' ' + e.apellido_paterno
FROM ParticipacionPedido pp
JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
WHERE pp.codigo_pedido = p.codigo_pedido
AND pp.tipo_participacion = 'Atiende pedido presencial'
) AS nombreCamarero,

--Subconsulta para obtener la hora en que se sirvió el pedido
--Se extrae la hora en que el pedido pasa al estado "Servido"
--Conceptualmente, representa la hora en que se sirvió el pedido
(
SELECT TOP 1
hep.hora_cambio
FROM HistorialEstadoPedido hep
JOIN TipoEstado tes
ON hep.codigo_tipoestado = tes.codigo_tipoestado
WHERE hep.codigo_pedido = p.codigo_pedido
AND tes.descripcion = 'Servido'
) AS horaServido,

--Subconsulta para poder obtener los productos del pedido
JSON_QUERY((
SELECT
dp.codigo_producto AS codigoProducto,
pro.nombre_producto AS producto,
dp.cantidad,
dp.precio_unitario AS precio
FROM DetallePedido dp
JOIN Producto pro
ON dp.codigo_producto = pro.codigo_producto
WHERE dp.codigo_pedido = p.codigo_pedido
FOR JSON PATH
)) AS productos

FROM Pedido p
JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
JOIN Cliente c
ON p.codigo_cliente = c.codigo_cliente
JOIN Mesa m
ON p.codigo_mesa = m.codigo_mesa
JOIN TipoEstado te
ON p.codigo_tipoestado = te.codigo_tipoestado
WHERE p.codigo_tipopedido = 1
FOR JSON PATH;
GO



--Consulta 2: Para "Delivery"
SELECT TOP 3
p.codigo_pedido AS codigoPedido,
tp.descripcion AS tipoPedido,
c.primer_nombre + ' ' + c.apellido_paterno AS cliente,
te.descripcion AS estado,
p.total_pagar AS totalPagar,
d.direccion AS direccionEntrega,

--Subconsulta para obtener el nombre del Anfitrión
(
SELECT TOP 1
e.primer_nombre + ' ' + e.apellido_paterno
FROM ParticipacionPedido pp
JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
WHERE pp.codigo_pedido = p.codigo_pedido
AND pp.tipo_participacion = 'Anota pedido delivery'
) AS nombreAnfitrion,

--Subconsulta para obtener el nombre del Repartidor
(
SELECT TOP 1
e.primer_nombre + ' ' + e.apellido_paterno
FROM ParticipacionPedido pp
JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
WHERE pp.codigo_pedido = p.codigo_pedido
AND pp.tipo_participacion = 'Entrega pedido delivery'
) AS nombreRepartidor,

--Subconsulta para poder obtener la hora de entrega del pedido
--Se extrae la hora donde el pedido cambia al estado "Entregado"
(
SELECT TOP 1
hep.hora_cambio
FROM HistorialEstadoPedido hep
JOIN TipoEstado tes
ON hep.codigo_tipoestado = tes.codigo_tipoestado
WHERE hep.codigo_pedido = p.codigo_pedido
AND tes.descripcion = 'Entregado'
) AS horaEntrega,

--Subconsulta para poder obtener los productos del pedido
JSON_QUERY((
SELECT
dp.codigo_producto AS codigoProducto,
pro.nombre_producto AS producto,
dp.cantidad,
dp.precio_unitario AS precio
FROM DetallePedido dp
JOIN Producto pro
ON dp.codigo_producto = pro.codigo_producto
WHERE dp.codigo_pedido = p.codigo_pedido
FOR JSON PATH
)) AS productos

FROM Pedido p
JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
JOIN Cliente c
ON p.codigo_cliente = c.codigo_cliente
JOIN TipoEstado te
ON p.codigo_tipoestado = te.codigo_tipoestado
JOIN Direccion d
ON p.codigo_direccion = d.codigo_direccion
WHERE p.codigo_tipopedido = 2
FOR JSON PATH;
GO



--Consulta 3: Para "Presencial para recoger"
SELECT TOP 3
p.codigo_pedido AS codigoPedido,
tp.descripcion AS tipoPedido,
c.primer_nombre + ' ' + c.apellido_paterno AS cliente,
te.descripcion AS estado,
p.total_pagar AS totalPagar,

--Subconsulta para poder obtener la hora donde
--la participación del anfitrión telefónico se cancela
(
SELECT TOP 1
pp.fecha_participacion
FROM ParticipacionPedido pp
WHERE pp.codigo_pedido = p.codigo_pedido
AND pp.tipo_participacion = 'Anota pedido delivery'
AND pp.estado_participacion = 'Cancelado'
) AS horaFinAnfitrion,

--Subconsulta para poder obtener la hora donde
--la participación del repartidor se cancela
(
SELECT TOP 1
pp.fecha_participacion
FROM ParticipacionPedido pp
WHERE pp.codigo_pedido = p.codigo_pedido
AND pp.tipo_participacion = 'Entrega pedido delivery'
AND pp.estado_participacion = 'Cancelado'
) AS horaFinRepartidor,

--Subconsulta para poder obtener la hora donde
--la participación del camarero se activa
(
SELECT TOP 1
pp.fecha_participacion
FROM ParticipacionPedido pp
WHERE pp.codigo_pedido = p.codigo_pedido
AND pp.tipo_participacion = 'Atiende pedido presencial'
AND pp.estado_participacion = 'Activo'
) AS horaInicioCamarero,

--Subconsulta para poder obtener la hora de recogida del pedido
--Se extrae la hora donde el pedido cambia al estado "Recogido"
(
SELECT TOP 1
hep.hora_cambio
FROM HistorialEstadoPedido hep
JOIN TipoEstado tes
ON hep.codigo_tipoestado = tes.codigo_tipoestado
WHERE hep.codigo_pedido = p.codigo_pedido
AND tes.descripcion = 'Recogido'
) AS horaRecojo,

--Subconsulta para poder obtener los productos del pedido
JSON_QUERY((
SELECT
dp.codigo_producto AS codigoProducto,
pro.nombre_producto AS producto,
dp.cantidad,
dp.precio_unitario AS precio
FROM DetallePedido dp
JOIN Producto pro
ON dp.codigo_producto = pro.codigo_producto
WHERE dp.codigo_pedido = p.codigo_pedido
FOR JSON PATH
)) AS productos

FROM Pedido p
JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
JOIN Cliente c
ON p.codigo_cliente = c.codigo_cliente
JOIN TipoEstado te
ON p.codigo_tipoestado = te.codigo_tipoestado
WHERE p.codigo_tipopedido = 3
FOR JSON PATH;
GO




SELECT 
    FORMAT(p.fecha_pedido, 'yyyy-MM') AS MesAno,
    COUNT(DISTINCT p.codigo_pedido) AS TotalPedidos,
    SUM(dp.cantidad) AS TotalUnidadesVendidas,
    COUNT(DISTINCT dp.codigo_producto) AS VariedadProductosVendidos
FROM dbo.Pedido p
INNER JOIN dbo.DetallePedido dp ON p.codigo_pedido = dp.codigo_pedido
GROUP BY FORMAT(p.fecha_pedido, 'yyyy-MM')
ORDER BY MesAno;