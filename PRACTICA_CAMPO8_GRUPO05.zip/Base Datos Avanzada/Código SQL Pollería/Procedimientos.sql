USE El_Doradito
GO

/*=== PROCEDIMIENTOS ===*/
--1. REGISTRAR UN NUEVO PEDIDO
--Crearemos una TVP para manejar los detalles del pedido
CREATE TYPE TipoDetallePedido AS TABLE
(
codigo_producto INT,
cantidad INT
);
GO
--Luego otra para manejar la participacion de los empleados
CREATE TYPE TipoParticipacionPedido AS TABLE
(
codigo_empleado INT,
tipo_participacion NVARCHAR(50)
);
GO
CREATE OR ALTER PROCEDURE proce_registrar_pedido
(
@codigo_cliente INT,
@codigo_tipopedido INT,
@codigo_direccion INT,
@codigo_mesa INT,
@detalles_pedido TipoDetallePedido READONLY,
@participaciones_pedido TipoParticipacionPedido READONLY
)
AS
BEGIN
SET NOCOUNT ON;
-- VARIABLES
DECLARE @codigo_pedido INT;
DECLARE @codigo_tipoestado INT;
DECLARE @total_pagar DECIMAL(10,2);
-- El pedido se crea inicialmente con total 0
-- tri_actualiza_totalpedido lo recalculará al insertar los registros de DetallePedido
SET @total_pagar = 0;
-- VALIDACIONES INICIALES
-- Validar cliente
IF NOT EXISTS
(
SELECT 1
FROM Cliente
WHERE codigo_cliente = @codigo_cliente
)
BEGIN
RAISERROR('ERROR: El cliente no existe', 16, 1);
RETURN;
END;
-- Validar tipo de pedido
IF NOT EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
)
BEGIN
RAISERROR('ERROR: El tipo de pedido no existe', 16, 1);
RETURN;
END;
-- Validar dirección si fue proporcionada
IF @codigo_direccion IS NOT NULL
AND NOT EXISTS
(
SELECT 1
FROM Direccion
WHERE codigo_direccion = @codigo_direccion
)
BEGIN
RAISERROR('ERROR: La dirección no existe', 16, 1);
RETURN;
END;
-- Validar mesa
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
)
BEGIN
RAISERROR('ERROR: La mesa no existe', 16, 1);
RETURN;
END;
-- Debe existir al menos un detalle
IF NOT EXISTS
(
SELECT 1
FROM @detalles_pedido
)
BEGIN
RAISERROR('ERROR: El pedido debe contener al menos un producto', 16, 1);
RETURN;
END;
-- Validar existencia de productos
IF EXISTS
(
SELECT 1
FROM @detalles_pedido d
LEFT JOIN Producto p
ON d.codigo_producto = p.codigo_producto
WHERE p.codigo_producto IS NULL
)
BEGIN
RAISERROR('ERROR: Uno o más productos no existen', 16, 1);
RETURN;
END;
-- Validar cantidades
IF EXISTS
(
SELECT 1
FROM @detalles_pedido
WHERE cantidad <= 0
)
BEGIN
RAISERROR('ERROR: La cantidad de cada producto debe ser mayor a cero', 16, 1);
RETURN;
END;
-- Validar disponibilidad
IF EXISTS
(
SELECT 1
FROM @detalles_pedido d
INNER JOIN Producto p
ON d.codigo_producto = p.codigo_producto
WHERE p.disponibilidad <> 'Disponible'
)
BEGIN
RAISERROR('ERROR: Uno o más productos no están disponibles', 16, 1);
RETURN;
END;
-- VALIDACIONES SEGÚN TIPO DE PEDIDO
-- DELIVERY
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Delivery'
)
BEGIN
-- Debe tener dirección
IF @codigo_direccion IS NULL
BEGIN
RAISERROR('ERROR: Un pedido Delivery debe tener una dirección', 16, 1);
RETURN;
END;
-- La dirección debe pertenecer al cliente
IF NOT EXISTS
(
SELECT 1
FROM Direccion
WHERE codigo_direccion = @codigo_direccion
AND codigo_cliente = @codigo_cliente
)
BEGIN
RAISERROR('ERROR: La dirección no pertenece al cliente indicado', 16, 1);
RETURN;
END;
-- Debe utilizar mesa virtual 99
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND numero_mesa = 99
)
BEGIN
RAISERROR('ERROR: Los pedidos Delivery deben utilizar la mesa virtual 99', 16, 1);
RETURN;
END;
-- El distrito debe atender Delivery
IF NOT EXISTS
(
SELECT 1
FROM Direccion d
INNER JOIN Distrito dt
ON d.codigo_distrito = dt.codigo_distrito
WHERE d.codigo_direccion = @codigo_direccion
AND dt.atiende_delivery = 'Si'
)
BEGIN
RAISERROR('ERROR: El distrito de la dirección no atiende pedidos Delivery', 16, 1);
RETURN;
END;
END;
-- PRESENCIAL PARA RECOGER
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Presencial para recoger'
)
BEGIN
IF @codigo_direccion IS NOT NULL
BEGIN
RAISERROR('ERROR: Los pedidos para recoger no deben tener dirección', 16, 1);
RETURN;
END;
-- Debe utilizar mesa virtual 98
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND numero_mesa = 98
)
BEGIN
RAISERROR('ERROR: Los pedidos para recoger deben utilizar la mesa virtual 98', 16, 1);
RETURN;
END;
END;
-- PRESENCIAL EN MESA
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Presencial en mesa'
)
BEGIN
IF @codigo_direccion IS NOT NULL
BEGIN
RAISERROR('ERROR: Los pedidos en mesa no deben tener dirección', 16, 1);
RETURN;
END;
-- Debe utilizar mesa física
IF NOT EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND numero_mesa BETWEEN 10 AND 24
)
BEGIN
RAISERROR('ERROR: El pedido en mesa debe utilizar una mesa física', 16, 1);
RETURN;
END;
-- La mesa debe estar libre
IF EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @codigo_mesa
AND estado_mesa = 'Ocupada'
)
BEGIN
RAISERROR('ERROR: La mesa seleccionada está ocupada', 16, 1);
RETURN;
END;
END;
-- VALIDACIÓN DE PARTICIPACIONES
-- Debe existir al menos una participación
IF NOT EXISTS
(
SELECT 1
FROM @participaciones_pedido
)
BEGIN
RAISERROR('ERROR: El pedido debe tener empleados participantes', 16, 1);
RETURN;
END;
-- Los empleados indicados deben existir
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
LEFT JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
WHERE e.codigo_empleado IS NULL
)
BEGIN
RAISERROR('ERROR: Uno o más empleados indicados no existen', 16, 1);
RETURN;
END;
-- VALIDACIONES ESPECÍFICAS DE DELIVERY
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion = 'Delivery'
)
BEGIN
-- Delivery requiere exactamente 2 participaciones
IF (SELECT COUNT(*) FROM @participaciones_pedido) <> 2
BEGIN
RAISERROR(
'ERROR: Un pedido Delivery debe tener exactamente dos participaciones: Anfitrion y Repartidor',
16, 1
);
RETURN;
END;
-- Debe existir exactamente una participación de Anfitrión
IF
(
SELECT COUNT(*)
FROM @participaciones_pedido
WHERE tipo_participacion = 'Anota pedido delivery'
) <> 1
BEGIN
RAISERROR(
'ERROR: El Delivery debe tener exactamente una participación "Anota pedido delivery"',
16, 1
);
RETURN;
END;
-- Debe existir exactamente una participación de Repartidor
IF
(
SELECT COUNT(*)
FROM @participaciones_pedido
WHERE tipo_participacion = 'Entrega pedido delivery'
) <> 1
BEGIN
RAISERROR(
'ERROR: El Delivery debe tener exactamente una participación "Entrega pedido delivery"',
16, 1
);
RETURN;
END;
-- El que anota debe ser Anfitrión telefónico
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
INNER JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE pp.tipo_participacion = 'Anota pedido delivery'
AND r.descripcion <> 'Anfitrion telefonico'
)
BEGIN
RAISERROR(
'ERROR: Solo un Anfitrion telefonico puede tener la participación "Anota pedido delivery"',
16, 1
);
RETURN;
END;
-- El que entrega debe ser Repartidor
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
INNER JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE pp.tipo_participacion = 'Entrega pedido delivery'
AND r.descripcion <> 'Repartidor'
)
BEGIN
RAISERROR(
'ERROR: Solo un Repartidor puede tener la participación "Entrega pedido delivery"',
16, 1
);
RETURN;
END;
END;
-- VALIDACIONES ESPECÍFICAS DE PEDIDOS PRESENCIALES
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @codigo_tipopedido
AND descripcion IN ('Presencial en mesa', 'Presencial para recoger')
)
BEGIN
-- Solo debe existir un participante
IF (SELECT COUNT(*) FROM @participaciones_pedido) <> 1
BEGIN
RAISERROR(
'ERROR: Un pedido presencial debe tener exactamente un Camarero',
16, 1
);
RETURN;
END;
-- Debe ser Atiende pedido presencial
IF NOT EXISTS
(
SELECT 1
FROM @participaciones_pedido
WHERE tipo_participacion = 'Atiende pedido presencial'
)
BEGIN
RAISERROR(
'ERROR: El pedido presencial debe tener la participación "Atiende pedido presencial"',
16, 1
);
RETURN;
END;
-- El empleado debe ser Camarero
IF EXISTS
(
SELECT 1
FROM @participaciones_pedido pp
INNER JOIN Empleado e
ON pp.codigo_empleado = e.codigo_empleado
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE pp.tipo_participacion = 'Atiende pedido presencial'
AND r.descripcion <> 'Camarero'
)
BEGIN
RAISERROR(
'ERROR: Solo un Camarero puede tener la participación "Atiende pedido presencial"',
16, 1
);
RETURN;
END;
END;
-- TRANSACCIÓN
BEGIN TRY
BEGIN TRANSACTION;
-- OBTENER ESTADO INICIAL
SELECT @codigo_tipoestado = codigo_tipoestado
FROM TipoEstado
WHERE codigo_tipopedido = @codigo_tipopedido
AND orden_estado = 1;
IF @codigo_tipoestado IS NULL
BEGIN
RAISERROR(
'ERROR: No existe un estado inicial para este tipo de pedido',
16, 1
);
END;
-- CREAR PEDIDO
INSERT INTO Pedido
(
codigo_cliente,
codigo_tipopedido,
codigo_tipoestado,
codigo_direccion,
codigo_mesa,
total_pagar
)
VALUES
(
@codigo_cliente,
@codigo_tipopedido,
@codigo_tipoestado,
@codigo_direccion,
@codigo_mesa,
@total_pagar
);
SET @codigo_pedido = SCOPE_IDENTITY();
-- INSERTAR DETALLES
INSERT INTO DetallePedido
(
codigo_pedido,
codigo_producto,
cantidad,
precio_unitario
)
SELECT
@codigo_pedido,
d.codigo_producto,
d.cantidad,
p.precio_producto
FROM @detalles_pedido d
INNER JOIN Producto p
ON d.codigo_producto = p.codigo_producto;
-- OBTENER TOTAL ACTUALIZADO POR EL TRIGGER
SELECT @total_pagar = total_pagar
FROM Pedido
WHERE codigo_pedido = @codigo_pedido;
-- REGISTRAR PARTICIPACIONES
INSERT INTO ParticipacionPedido
(
codigo_pedido,
codigo_empleado,
tipo_participacion,
estado_participacion
)
SELECT
@codigo_pedido,
codigo_empleado,
tipo_participacion,
'Activo'
FROM @participaciones_pedido;
-- REGISTRAR HISTORIAL DEL ESTADO
INSERT INTO HistorialEstadoPedido
(
codigo_pedido,
codigo_tipoestado
)
VALUES
(
@codigo_pedido,
@codigo_tipoestado
);
-- CONFIRMAR
COMMIT TRANSACTION;
-- RESULTADO
SELECT
@codigo_pedido AS codigo_pedido,
@total_pagar AS total_pagar,
'Pedido registrado correctamente' AS mensaje;
END TRY
BEGIN CATCH
IF @@TRANCOUNT > 0
ROLLBACK TRANSACTION;
THROW;
END CATCH;
END;
GO
GO

-- PRUEBA DEL PROCEDIMIENTO - DELIVERY
DECLARE @detalles TipoDetallePedido;
DECLARE @participaciones TipoParticipacionPedido;

INSERT INTO @detalles (codigo_producto, cantidad)
VALUES (1, 2);
INSERT INTO @participaciones (codigo_empleado, tipo_participacion)
VALUES
(10, 'Anota pedido delivery'),-- Santiago Alvarez Herrera
(3, 'Entrega pedido delivery'); -- Eduardo Delgado Nuñez
EXEC proce_registrar_pedido
@codigo_cliente = 1,
@codigo_tipopedido = 2,
@codigo_direccion = 1,
@codigo_mesa = 17,
@detalles_pedido = @detalles,
@participaciones_pedido = @participaciones;

--VERIFICACIÓN DEL PROCEDIMIENTO
DECLARE @ultimo_pedido INT;
SELECT @ultimo_pedido = MAX(codigo_pedido)
FROM Pedido;
--Verificamos pedido creado
SELECT
p.codigo_pedido,
p.codigo_cliente,
p.codigo_tipopedido,
p.codigo_tipoestado,
p.codigo_direccion,
p.codigo_mesa,
p.fecha_pedido,
p.total_pagar
FROM Pedido p
WHERE p.codigo_pedido = @ultimo_pedido;
--Verificamos detalle insertado
SELECT
dp.codigo_pedido,
dp.codigo_producto,
dp.cantidad,
dp.precio_unitario,
dp.subtotal
FROM DetallePedido dp
WHERE dp.codigo_pedido = @ultimo_pedido;
--Comparamos total del Pedido contra los detalles
SELECT
p.codigo_pedido,
p.total_pagar AS TotalPedido,
SUM(dp.subtotal) AS TotalDetalles
FROM Pedido p
INNER JOIN DetallePedido dp
ON p.codigo_pedido = dp.codigo_pedido
WHERE p.codigo_pedido = @ultimo_pedido
GROUP BY
p.codigo_pedido,
p.total_pagar;
--Verificamos la participación del empleado
SELECT *
FROM ParticipacionPedido
WHERE codigo_pedido = @ultimo_pedido;
--Verificamos historial/estado inicial
SELECT *
FROM HistorialEstadoPedido
WHERE codigo_pedido = @ultimo_pedido;
GO


--2. ACTUALIZAR TIPO DE PEDIDO (Delivery -> Presencial)
CREATE OR ALTER PROCEDURE proce_actualiza_tipopedido
(
@p_codigo_pedido INT,
@p_nuevo_codigo_tipopedido INT,
@p_codigo_empleado INT
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @v_codigo_tipopedido_actual INT;
DECLARE @v_codigo_tipoestado_actual INT;
DECLARE @v_orden_estado INT;
DECLARE @v_nuevo_codigo_tipoestado INT;
DECLARE @v_codigo_mesa_nueva INT;
DECLARE @v_mensaje_error NVARCHAR(4000);
BEGIN TRY
BEGIN TRANSACTION;
-- PASO 1: VALIDAR PEDIDO
IF @p_codigo_pedido IS NULL OR @p_codigo_pedido <= 0
BEGIN
RAISERROR('ERROR: El código del pedido ingresado no es válido', 16, 1);
RETURN;
END;
SELECT
@v_codigo_tipopedido_actual = codigo_tipopedido,
@v_codigo_tipoestado_actual = codigo_tipoestado
FROM Pedido
WHERE codigo_pedido = @p_codigo_pedido;
IF @v_codigo_tipopedido_actual IS NULL
BEGIN
RAISERROR('ERROR: El pedido especificado no existe', 16, 1);
RETURN;
END;
-- PASO 2: VALIDAR TIPO ACTUAL Y NUEVO TIPO
-- El procedimiento solo permite cambiar desde Delivery
IF NOT EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @v_codigo_tipopedido_actual
AND descripcion = 'Delivery'
)
BEGIN
RAISERROR('ERROR: Solo se pueden modificar pedidos que actualmente sean Delivery', 16, 1);
RETURN;
END;
-- El nuevo tipo debe ser Presencial en mesa o para recoger
IF NOT EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @p_nuevo_codigo_tipopedido
AND descripcion IN
(
'Presencial en mesa',
'Presencial para recoger'
)
)
BEGIN
RAISERROR('ERROR: El nuevo tipo debe ser Presencial en mesa o Presencial para recoger', 16, 1);
RETURN;
END;
-- PASO 3: VALIDAR ESTADO ACTUAL
SELECT @v_orden_estado = orden_estado
FROM TipoEstado
WHERE codigo_tipoestado = @v_codigo_tipoestado_actual;
-- Delivery solo puede cambiar mientras esté en:
-- 1 = Pedido tomado
-- 2 = En preparación
-- 3 = Listo para entregar
IF @v_orden_estado >= 4
BEGIN
RAISERROR('ERROR: El pedido Delivery ya no puede cambiar de modalidad porque se encuentra en un estado avanzado', 16, 1);
RETURN;
END;
-- PASO 4: VALIDAR EMPLEADO
IF NOT EXISTS
(
SELECT 1
FROM Empleado e
INNER JOIN Rol r
ON e.codigo_rol = r.codigo_rol
WHERE e.codigo_empleado = @p_codigo_empleado
AND r.descripcion = 'Camarero'
)
BEGIN
RAISERROR('ERROR: El empleado indicado debe tener el rol Camarero', 16, 1);
RETURN;
END;
-- PASO 5: DETERMINAR ESTADO EQUIVALENTE
SELECT @v_nuevo_codigo_tipoestado = te.codigo_tipoestado
FROM TipoEstado te
WHERE te.codigo_tipopedido = @p_nuevo_codigo_tipopedido
AND te.orden_estado = @v_orden_estado;
IF @v_nuevo_codigo_tipoestado IS NULL
BEGIN
RAISERROR('ERROR: No existe un estado equivalente para el nuevo tipo de pedido', 16, 1);
RETURN;
END;
-- PASO 6: DETERMINAR MESA
IF EXISTS
(
SELECT 1
FROM TipoPedido
WHERE codigo_tipopedido = @p_nuevo_codigo_tipopedido
AND descripcion = 'Presencial para recoger'
)
BEGIN
-- Mesa virtual 98
SELECT @v_codigo_mesa_nueva = codigo_mesa
FROM Mesa
WHERE numero_mesa = 98;
IF @v_codigo_mesa_nueva IS NULL
BEGIN
RAISERROR('ERROR: No existe la mesa virtual 98', 16, 1);
RETURN;
END;
END
ELSE
BEGIN
-- Buscar una mesa física libre
SELECT TOP 1 @v_codigo_mesa_nueva = codigo_mesa
FROM Mesa
WHERE numero_mesa BETWEEN 10 AND 24
AND estado_mesa = 'Libre'
ORDER BY numero_mesa;
IF @v_codigo_mesa_nueva IS NULL
BEGIN
RAISERROR('ERROR: No existen mesas físicas disponibles', 16, 1);
RETURN;
END;
END;
-- PASO 7: CANCELAR PARTICIPACIONES DELIVERY
UPDATE ParticipacionPedido
SET estado_participacion = 'Cancelado',
fecha_participacion = GETDATE()
WHERE codigo_pedido = @p_codigo_pedido
AND estado_participacion = 'Activo';
-- PASO 8: ACTUALIZAR PEDIDO
UPDATE Pedido
SET codigo_tipopedido = @p_nuevo_codigo_tipopedido,
codigo_tipoestado = @v_nuevo_codigo_tipoestado,
codigo_direccion = NULL,
codigo_mesa = @v_codigo_mesa_nueva
WHERE codigo_pedido = @p_codigo_pedido;
-- PASO 9: REGISTRAR NUEVA PARTICIPACIÓN DEL CAMARERO
INSERT INTO ParticipacionPedido
(
codigo_pedido,
codigo_empleado,
tipo_participacion,
estado_participacion,
fecha_participacion
)
VALUES
(
@p_codigo_pedido,
@p_codigo_empleado,
'Atiende pedido presencial',
'Activo',
GETDATE()
);
-- PASO 10: MARCAR MESA FÍSICA COMO OCUPADA
IF EXISTS
(
SELECT 1
FROM Mesa
WHERE codigo_mesa = @v_codigo_mesa_nueva
AND numero_mesa BETWEEN 10 AND 24
)
BEGIN
UPDATE Mesa
SET estado_mesa = 'Ocupada'
WHERE codigo_mesa = @v_codigo_mesa_nueva;
END;
-- PASO 11: CONFIRMAR
COMMIT TRANSACTION;
SELECT
@p_codigo_pedido AS codigo_pedido,
@p_nuevo_codigo_tipopedido AS nuevo_codigo_tipopedido,
@v_nuevo_codigo_tipoestado AS nuevo_codigo_tipoestado,
@v_codigo_mesa_nueva AS codigo_mesa,
'Pedido actualizado correctamente' AS mensaje;
END TRY
BEGIN CATCH
IF @@TRANCOUNT > 0
ROLLBACK TRANSACTION;
SET @v_mensaje_error = ERROR_MESSAGE();
RAISERROR(@v_mensaje_error, 16, 1);
END CATCH;
END;
GO
--PRUEBA DEL PROCEDIMIENTO
EXEC proce_actualiza_tipopedido
@p_codigo_pedido = 10072,
@p_nuevo_codigo_tipopedido = 1,
@p_codigo_empleado = 9;
--VERIFICACIÓN DEL PROCEDIMIENTO
--Verificamos el pedido actualizado
SELECT
p.codigo_pedido,
p.codigo_cliente,
tp.descripcion AS tipo_pedido,
te.descripcion AS estado_pedido,
p.codigo_direccion,
p.codigo_mesa,
m.numero_mesa,
p.total_pagar
FROM Pedido p
INNER JOIN TipoPedido tp
ON p.codigo_tipopedido = tp.codigo_tipopedido
INNER JOIN TipoEstado te
ON p.codigo_tipoestado = te.codigo_tipoestado
INNER JOIN Mesa m
ON p.codigo_mesa = m.codigo_mesa
WHERE p.codigo_pedido = 10072;
--Verificamos las participaciones
SELECT
codigo_pedido,
codigo_empleado,
tipo_participacion,
estado_participacion,
fecha_participacion
FROM ParticipacionPedido
WHERE codigo_pedido = 10072
ORDER BY fecha_participacion;
--Verificamos el historial de estados
SELECT
codigo_historial,
codigo_pedido,
codigo_tipoestado,
hora_cambio
FROM HistorialEstadoPedido
WHERE codigo_pedido = 10072
ORDER BY hora_cambio;
--Verificamos la auditoría
SELECT
codigo_log,
fecha_hora,
usuario_sistema,
accion,
tabla_afectada,
registro_afectado,
campo_afectado
FROM LogSistema
WHERE tabla_afectada = 'Pedido'
AND registro_afectado = '10072'
ORDER BY fecha_hora;
--Verificamos el estado de la mesa asignada
SELECT
codigo_mesa,
numero_mesa,
estado_mesa
FROM Mesa
WHERE codigo_mesa =
(
SELECT codigo_mesa
FROM Pedido
WHERE codigo_pedido = 10072
);
GO


--3. REGISTRAR CLIENTE FORMALMENTE (con correo electrónico como agregado)
CREATE OR ALTER PROCEDURE proce_registrar_cliente
(
@primer_nombre NVARCHAR(20),
@segundo_nombre NVARCHAR(20) = NULL,
@apellido_paterno NVARCHAR(20) = NULL,
@apellido_materno NVARCHAR(20) = NULL,
@telefono NVARCHAR(15),
@correo_electronico NVARCHAR(150) = NULL
)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRY
BEGIN TRANSACTION;
DECLARE @codigo_cliente_existente INT = NULL;
-- Buscar si el teléfono ya existe en la base de datos
SELECT @codigo_cliente_existente = codigo_cliente
FROM Cliente
WHERE telefono = @telefono AND telefono IS NOT NULL;
-- Validar que el correo electrónico no esté registrado por otro cliente
IF @correo_electronico IS NOT NULL AND EXISTS
(
SELECT 1
FROM Cliente
WHERE correo_electronico = @correo_electronico
AND (@codigo_cliente_existente IS NULL OR codigo_cliente <> @codigo_cliente_existente)
)
BEGIN
RAISERROR('ERROR: El correo electrónico proporcionado ya se encuentra registrado por otro cliente', 16, 1);
RETURN;
END;
-- Si el teléfono existe en la base de datos se actualiza
IF @codigo_cliente_existente IS NOT NULL
BEGIN
UPDATE Cliente
SET segundo_nombre = ISNULL(@segundo_nombre, segundo_nombre),
apellido_paterno = ISNULL(@apellido_paterno, apellido_paterno),
apellido_materno = ISNULL(@apellido_materno, apellido_materno),
correo_electronico = ISNULL(@correo_electronico, correo_electronico)
WHERE codigo_cliente = @codigo_cliente_existente;
END
-- Si el teléfono no existe se registra un nuevo cliente
ELSE
BEGIN
INSERT INTO Cliente
(
primer_nombre,
segundo_nombre,
apellido_paterno,
apellido_materno,
telefono,
correo_electronico,
fecha_registro
)
VALUES
(
@primer_nombre,
@segundo_nombre,
@apellido_paterno,
@apellido_materno,
@telefono,
@correo_electronico,
GETDATE()
);
END;
COMMIT TRANSACTION;
SELECT
ISNULL(@codigo_cliente_existente, SCOPE_IDENTITY()) AS codigo_cliente,
'Cliente registrado o actualizado correctamente' AS mensaje;
END TRY
BEGIN CATCH
IF @@TRANCOUNT > 0
ROLLBACK TRANSACTION;
THROW;
END CATCH;
END;
GO
--PRUEBA DEL PROCEDIMIENTO
EXEC proce_registrar_cliente
@primer_nombre = 'Juan',
@segundo_nombre = 'Carlos',
@apellido_paterno = 'Perez',
@apellido_materno = 'Gomez',
@telefono = '999111226',
@correo_electronico = 'juan.perez3@email.com';
--VERIFICACIÓN DEL PROCEDIMIENTO
SELECT
codigo_cliente,
primer_nombre,
segundo_nombre,
apellido_paterno,
apellido_materno,
telefono,
correo_electronico,
fecha_registro
FROM Cliente
WHERE telefono = '999111226';