CREATE DATABASE DW_El_Doradito
GO

USE DW_El_Doradito
GO

/*=== DIMENSIONES ===*/

CREATE TABLE DimCliente
(
    ClienteKey INT PRIMARY KEY IDENTITY(1,1),
    NombreCliente NVARCHAR(150) NOT NULL,
    FechaRegistro DATE NOT NULL,
    CodigoClienteOrigen INT NOT NULL
);

CREATE TABLE DimFecha
(
    FechaKey INT PRIMARY KEY,
    Fecha DATE NOT NULL,
    Dia INT NOT NULL,
    Mes INT NOT NULL,
    NombreMes NVARCHAR(20) NOT NULL,
    Anio INT NOT NULL
);

CREATE TABLE DimTipoPedido
(
    TipoPedidoKey INT PRIMARY KEY IDENTITY(1,1),
    Descripcion NVARCHAR(100) NOT NULL
);

CREATE TABLE DimUbicacion
(
    UbicacionKey INT PRIMARY KEY IDENTITY(1,1),
    Distrito NVARCHAR(100) NOT NULL,
    AtiendeDelivery NVARCHAR(10) NOT NULL
);

CREATE TABLE DimPago
(
    PagoKey INT PRIMARY KEY IDENTITY(1,1),
    MetodoPago NVARCHAR(50) NOT NULL
);

CREATE TABLE DimCategoria
(
    CategoriaKey INT PRIMARY KEY IDENTITY(1,1),
    NombreCategoria NVARCHAR(100) NOT NULL,
    CodigoCategoriaOriginal INT NOT NULL
);

CREATE TABLE DimProducto
(
    ProductoKey INT PRIMARY KEY IDENTITY(1,1),
    NombreProducto NVARCHAR(150) NOT NULL,
    PrecioProducto DECIMAL(10,2) NOT NULL,
    CostoProducto DECIMAL(10,2) NOT NULL,
    CategoriaKey INT NOT NULL,
    CodigoProductoOriginal INT NOT NULL,
    FOREIGN KEY (CategoriaKey) REFERENCES DimCategoria(CategoriaKey)
);



/*=== HECHOS ===*/
CREATE TABLE FactPedido
(
    PedidoKey INT PRIMARY KEY IDENTITY(1,1),
    CodigoPedidoOriginal INT NOT NULL,
    ClienteKey INT NOT NULL,
    FechaKey INT NOT NULL,
    TipoPedidoKey INT NOT NULL,
    UbicacionKey INT,
    PagoKey INT NOT NULL,
    TotalPagar DECIMAL(10,2) NOT NULL,
    TiempoPreparacionMinutos INT NOT NULL,
    FOREIGN KEY (ClienteKey) REFERENCES DimCliente(ClienteKey),
    FOREIGN KEY (FechaKey) REFERENCES DimFecha(FechaKey),
    FOREIGN KEY (TipoPedidoKey) REFERENCES DimTipoPedido(TipoPedidoKey),
    FOREIGN KEY (UbicacionKey) REFERENCES DimUbicacion(UbicacionKey),
    FOREIGN KEY (PagoKey) REFERENCES DimPago(PagoKey)
);

CREATE TABLE FactDetallePedido
(
    DetalleKey INT PRIMARY KEY IDENTITY(1,1),
    PedidoKey INT NOT NULL,
    ProductoKey INT NOT NULL,
    ClienteKey INT NOT NULL,
    Cantidad INT NOT NULL,
    PrecioUnitario DECIMAL(10,2) NOT NULL,
    Subtotal DECIMAL(10,2) NOT NULL,
    FechaKey INT NOT NULL,
    FOREIGN KEY (ProductoKey) REFERENCES DimProducto(ProductoKey),
    FOREIGN KEY (ClienteKey) REFERENCES DimCliente(ClienteKey),
    FOREIGN KEY (FechaKey) REFERENCES DimFecha(FechaKey)
);



--Agregaremos un registro comodín adicional a DimUbicacion, que aplica para pedidos presenciales en mesa
--O para recoger, es decir, "No aplica"
INSERT INTO DimUbicacion (Distrito, AtiendeDelivery)
VALUES ('No Aplica', 'No');




