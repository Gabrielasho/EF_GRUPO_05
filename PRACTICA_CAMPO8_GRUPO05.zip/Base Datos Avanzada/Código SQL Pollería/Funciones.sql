USE El_Doradito
GO

/*=== FUNCIONES ===*/
--1. CALCULAR EL GASTO POR INGREDIENTE
CREATE OR ALTER FUNCTION func_calcular_gasto_ingrediente
(@p_codigo_ingrediente INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
DECLARE @v_gasto_total DECIMAL(10,2) = 0;
--Validar que el ingrediente exista en la tabla Ingrediente
IF NOT EXISTS (SELECT 1 FROM Ingrediente WHERE codigo_ingrediente = @p_codigo_ingrediente)
BEGIN
RETURN NULL; 
END
--Buscar registros en DetalleCompra y sumar el gasto (cantidad * precio_unitario)
SELECT @v_gasto_total = ISNULL(SUM(cantidad * precio_unitario), 0)
FROM DetalleCompra
WHERE codigo_ingrediente = @p_codigo_ingrediente;
--Retornar el gasto total calculado
RETURN @v_gasto_total;
END;
GO
--PRUEBA 1: Ingrediente registrado
SELECT dbo.func_calcular_gasto_ingrediente(1) AS GastoTotalEnIngrediente;
GO
--PRUEBA 2: Ingrediente inexistente
SELECT dbo.func_calcular_gasto_ingrediente(50) AS GastoTotalEnIngrediente;
GO


--2. CALCULAR LA FRECUENCIA DE UN PRODUCTO
CREATE OR ALTER FUNCTION func_calcular_frecuencia_producto
(
@codigo_producto INT
)
RETURNS INT
AS
BEGIN
DECLARE @frecuencia INT = 0;
-- Verificar si el producto existe
IF EXISTS
(
SELECT 1
FROM Producto
WHERE codigo_producto = @codigo_producto
)
BEGIN
SELECT @frecuencia = COUNT(*)
FROM DetallePedido
WHERE codigo_producto = @codigo_producto;
END
ELSE
BEGIN
SET @frecuencia = -1;
END;
RETURN @frecuencia;
END;
GO
--PRUEBA 1: Cuántas veces se vendió el producto con código 1
SELECT dbo.func_calcular_frecuencia_producto(1) AS FrecuenciaProducto;
--PRUEBA 2 Producto inexistente
SELECT dbo.func_calcular_frecuencia_producto(99) AS FrecuenciaProducto;

