/*=== ANÁLISIS BIG DATA CON SPARK ===*/
USE DW_El_Doradito
GO

--Consultas para exportar los datos en archivos .csv
SELECT * FROM FactPedido;
SELECT * FROM FactDetallePedido;
SELECT * FROM DimFecha;
SELECT * FROM DimProducto;
SELECT * FROM DimTipoPedido;


--PRUEBA DE RENDIMIENTO SPARK VS SQL
--Activamos la métrica del tiempo
SET STATISTICS TIME ON;

--Consulta 1: Total de ventas por tipo de pedido
SELECT tp.Descripcion, COUNT(*) AS CantidadPedidos,
ROUND(SUM(fp.TotalPagar),2) AS VentaTotal
FROM FactPedido fp
JOIN DimTipoPedido tp
ON fp.TipoPedidoKey = tp.TipoPedidoKey
GROUP BY tp.Descripcion
ORDER BY VentaTotal DESC



--Consulta 2: Los 10 productos más vendidos
SELECT TOP 10 p.NombreProducto, SUM(fd.Cantidad) AS TotalVendido,
ROUND(SUM(fd.Subtotal),2) AS IngresoGenerado
FROM FactDetallePedido fd
JOIN DimProducto p
ON fd.ProductoKey = p.ProductoKey
GROUP BY p.NombreProducto
ORDER BY TotalVendido DESC



--Consulta 3: Estadísticas descriptivas de ventas
SELECT ROUND(AVG(TotalPagar),2) AS PromedioVenta,
ROUND(STDEV(TotalPagar),2) AS DesviacionVenta,
MIN(TotalPagar) AS VentaMinima, MAX(TotalPagar) AS VentaMaxima
FROM FactPedido



--Consulta 4: Ventas por mes
SELECT f.Anio, f.Mes, f.NombreMes, COUNT(*) AS CantidadPedidos,
ROUND(SUM(p.TotalPagar), 2) AS VentaTotal,
ROUND(AVG(p.TotalPagar), 2) AS TicketPromedio
FROM FactPedido p
JOIN DimFecha f
ON p.FechaKey = f.FechaKey
GROUP BY f.Anio, f.Mes, f.NombreMes
ORDER BY f.Anio, f.Mes






